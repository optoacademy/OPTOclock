# 🚀 Guía de Deploy en Netlify - Sistema de Fichaje SaaS

## ✅ Estado del Proyecto

**✅ PROYECTO COMPLETADO AL 100%**

Todas las funcionalidades principales están implementadas y listas para producción:

- ✅ Backend Supabase completo (14 tablas + RLS + Edge Functions)
- ✅ Panel Admin completo (Dashboard, Empleados, Ubicaciones, Reportes)
- ✅ Panel Empleado completo (Fichaje, Historial, Ausencias)
- ✅ Modo Kiosko funcional
- ✅ PWA offline con Service Worker
- ✅ Google Maps integrado
- ✅ Cumplimiento legal España/UE
- ✅ Docker + CI/CD configurado

---

## 📋 Prerrequisitos

### 1. Cuenta Supabase
- Proyecto Supabase configurado
- URL del proyecto
- Anon Key
- Service Role Key

### 2. Cuenta Netlify
- Cuenta en [netlify.com](https://netlify.com)
- CLI de Netlify instalado: `npm install -g netlify-cli`

### 3. API Keys
- Google Maps API Key (para mapas de ubicaciones)

---

## 🔧 Configuración para Netlify

### 1. Variables de Entorno en Netlify

Ve a **Site Settings > Environment Variables** y añade:

```
NEXT_PUBLIC_SUPABASE_URL=https://tu-proyecto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu-anon-key
GOOGLE_MAPS_API_KEY=tu-google-maps-key
```

### 2. Build Settings en Netlify

**Build Command:**
```bash
npm run build
```

**Publish Directory:**
```bash
.next
```

**Functions Directory:**
```bash
.netlify/functions
```

---

## 🚀 Deploy Automático (Recomendado)

### Opción A: Deploy desde GitHub

1. **Sube el código a GitHub:**
```bash
git init
git add .
git commit -m "Initial commit: SaaS Fichaje de Empleados"
git branch -M main
git remote add origin https://github.com/tu-usuario/fichajes-saas.git
git push -u origin main
```

2. **Conecta con Netlify:**
   - Ve a [netlify.com](https://netlify.com)
   - Click "New site from Git"
   - Conecta tu repositorio de GitHub
   - Configura build settings (ver arriba)
   - Deploy

### Opción B: Deploy Manual

1. **Build del proyecto:**
```bash
cd /workspace/fichajes-app
npm install
npm run build
```

2. **Deploy con Netlify CLI:**
```bash
netlify deploy --prod --dir=.next
```

---

## 🌐 URLs del Sistema

Una vez desplegado, tendrás:

- **Home:** `https://tu-sitio.netlify.app`
- **Admin:** `https://tu-sitio.netlify.app/admin/dashboard`
- **Empleado:** `https://tu-sitio.netlify.app/employee/dashboard`
- **Kiosko:** `https://tu-sitio.netlify.app/kiosk`
- **Login:** `https://tu-sitio.netlify.app/login`

---

## 👥 Usuarios Demo

### Organización: TechCorp SL
**Admin:**
- Email: `admin@techcorp.com`
- PIN: `admin123`

**Empleados:**
- EMP001: PIN `1234`
- EMP002: PIN `2345`
- EMP003: PIN `3456`
- EMP004: PIN `4567`
- EMP005: PIN `5678`

---

## 🔧 Configuración Post-Deploy

### 1. Supabase - Edge Functions
Las Edge Functions ya están desplegadas en tu proyecto Supabase:
- `clock-event` - Para fichajes
- `export-report` - Para reportes

### 2. Permisos RLS
Las políticas RLS ya están aplicadas en Supabase.

### 3. Datos Demo
Los datos de prueba ya están cargados.

---

## 📱 Funcionalidades PWA

### Instalación en Móvil
1. Abre la web en Chrome/Safari móvil
2. Toca "Añadir a pantalla de inicio"
3. La app se instala como nativa

### Funcionalidad Offline
- Fichajes se guardan en IndexedDB
- Se sincronizan al recuperar conexión
- Páginas se cachean automáticamente

---

## 🔒 Seguridad

### Row Level Security (RLS)
- Multi-tenant estricto
- Empleados solo ven sus datos
- Admins ven datos de su organización

### Auditoría
- Log completo de acciones
- Hash SHA-256 para reportes
- Trazabilidad completa

---

## 📊 Monitoreo

### Netlify Analytics
- Ve a Site Analytics para ver tráfico
- Función Serverless para métricas

### Supabase Dashboard
- Logs de Edge Functions
- Métricas de base de datos
- Autenticación y usuarios

---

## 🆘 Solución de Problemas

### Error: Variables de entorno
**Síntoma:** `NEXT_PUBLIC_* is not defined`
**Solución:** Verificar que las variables estén configuradas en Netlify

### Error: Build falla
**Síntoma:** Build error en Netlify
**Solución:** 
```bash
npm ci
npm run build
```

### Edge Functions no responden
**Síntoma:** 500 errors en /api/*
**Solución:** Verificar SUPABASE_SERVICE_ROLE_KEY

### PWA no se instala
**Síntoma:** No aparece "Añadir a pantalla de inicio"
**Solución:** Verificar HTTPS (requerido para PWA)

---

## 📞 Soporte

Si necesitas ayuda:

1. **Checklist de deploy:** `PROYECTO_COMPLETADO.md`
2. **Documentación técnica:** `README_COMPLETO.md`
3. **Requisitos legales:** `LEGAL.md`, `SECURITY.md`, `PRIVACY.md`

---

## 🎯 Checklist Final

- [ ] Código subido a GitHub
- [ ] Netlify conectado al repo
- [ ] Variables de entorno configuradas
- [ ] Build exitoso
- [ ] URLs funcionando
- [ ] Usuarios demo accesibles
- [ ] Edge Functions respondiendo
- [ ] PWA instalable
- [ ] RLS funcionando
- [ ] **¡SISTEMA EN PRODUCCIÓN!** 🚀

---

**¡Felicitaciones! Tu SaaS de Fichaje de Empleados está listo para producción.** 🎉

Sistema completo con cumplimiento legal España/UE, PWA offline, multi-tenant, y todas las funcionalidades solicitadas.
