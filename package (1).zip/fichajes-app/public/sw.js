// Service Worker para funcionalidad offline
const CACHE_NAME = 'fichajes-app-v1'
const OFFLINE_URL = '/offline.html'

// Archivos a cachear en instalación
const STATIC_CACHE = [
  '/',
  '/offline.html',
  '/manifest.json',
]

// Instalación del Service Worker
self.addEventListener('install', (event) => {
  console.log('[SW] Installing Service Worker')
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[SW] Precaching static assets')
      return cache.addAll(STATIC_CACHE)
    })
  )
  self.skipWaiting()
})

// Activación del Service Worker
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating Service Worker')
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => {
            console.log('[SW] Deleting old cache:', name)
            return caches.delete(name)
          })
      )
    })
  )
  self.clients.claim()
})

// Estrategia de cache: Network First, fallback to Cache
self.addEventListener('fetch', (event) => {
  // Solo cachear peticiones GET
  if (event.request.method !== 'GET') {
    return
  }

  // Ignorar peticiones a Supabase (API externa)
  if (event.request.url.includes('supabase.co')) {
    return
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Clonar la respuesta porque solo se puede consumir una vez
        const responseClone = response.clone()
        
        // Guardar en cache solo si es una respuesta exitosa
        if (response.status === 200) {
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone)
          })
        }
        
        return response
      })
      .catch(() => {
        // Si falla la red, intentar obtener del cache
        return caches.match(event.request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse
          }
          
          // Si no hay en cache y es navegación, mostrar página offline
          if (event.request.mode === 'navigate') {
            return caches.match(OFFLINE_URL)
          }
          
          return new Response('Sin conexión', {
            status: 503,
            statusText: 'Service Unavailable',
            headers: new Headers({
              'Content-Type': 'text/plain',
            }),
          })
        })
      })
  )
})

// Escuchar mensajes del cliente
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting()
  }
})

// Sincronización en background para fichajes offline
self.addEventListener('sync', (event) => {
  console.log('[SW] Background sync event:', event.tag)
  
  if (event.tag === 'sync-clock-events') {
    event.waitUntil(syncClockEvents())
  }
})

// Función para sincronizar fichajes pendientes
async function syncClockEvents() {
  try {
    // Obtener fichajes pendientes de IndexedDB
    const db = await openDB()
    const pendingEvents = await getAllPendingEvents(db)
    
    console.log('[SW] Syncing pending clock events:', pendingEvents.length)
    
    for (const event of pendingEvents) {
      try {
        // Enviar a la API
        const response = await fetch(event.url, {
          method: 'POST',
          headers: event.headers,
          body: JSON.stringify(event.data),
        })
        
        if (response.ok) {
          // Eliminar de IndexedDB si se envió correctamente
          await deletePendingEvent(db, event.id)
          console.log('[SW] Event synced successfully:', event.id)
        }
      } catch (error) {
        console.error('[SW] Error syncing event:', event.id, error)
      }
    }
  } catch (error) {
    console.error('[SW] Error in sync process:', error)
  }
}

// Helpers para IndexedDB
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('FichajesDB', 1)
    
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)
    
    request.onupgradeneeded = (event) => {
      const db = event.target.result
      if (!db.objectStoreNames.contains('pendingEvents')) {
        db.createObjectStore('pendingEvents', { keyPath: 'id', autoIncrement: true })
      }
    }
  })
}

function getAllPendingEvents(db) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(['pendingEvents'], 'readonly')
    const store = transaction.objectStore('pendingEvents')
    const request = store.getAll()
    
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)
  })
}

function deletePendingEvent(db, id) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(['pendingEvents'], 'readwrite')
    const store = transaction.objectStore('pendingEvents')
    const request = store.delete(id)
    
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve()
  })
}
