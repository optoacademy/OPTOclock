# Medidas de Seguridad

## Arquitectura de Seguridad

### 1. Autenticación y Autorización

#### Supabase Auth
- **JWT (JSON Web Tokens)** con expiración configurable
- **Refresh tokens** para sesiones persistentes
- **MFA opcional** (Multi-Factor Authentication)
- **Políticas de contraseña**: Mínimo 8 caracteres, complejidad configurable

#### Roles y Permisos
```
ORG_ADMIN
  ├─ Gestión completa de organización
  ├─ CRUD empleados, ubicaciones, turnos
  ├─ Visualización de todos los fichajes
  ├─ Exportación de reportes
  └─ Configuración de webhooks

MANAGER
  ├─ Visualización de empleados asignados
  ├─ Aprobación de ausencias
  └─ Reportes de su área

EMPLOYEE
  ├─ Fichaje IN/OUT/BREAK
  ├─ Visualización de sus propios fichajes
  └─ Solicitud de ausencias

REPRESENTATIVE
  ├─ Visualización de datos agregados
  └─ Acceso de solo lectura
```

### 2. Row Level Security (RLS)

#### Políticas Implementadas

**Multi-Tenant Estricto**:
```sql
-- Ejemplo: Empleados solo ven sus datos
CREATE POLICY "Employees can view own clock events"
ON clock_events FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM employees
    WHERE employees.id = clock_events.employee_id
      AND employees.user_id = auth.uid()
  )
);
```

**Aislamiento por Organización**:
- Cada consulta filtra por `organization_id`
- Helper function `get_user_organization_id()`
- RLS aplicado en TODAS las tablas

### 3. Encriptación

#### En Tránsito
- **TLS 1.3** para todas las comunicaciones
- **HTTPS obligatorio** en producción
- **HSTS habilitado** (HTTP Strict Transport Security)

#### En Reposo
- **Supabase**: Encriptación AES-256 de base de datos
- **Backups**: Encriptados automáticamente
- **PINs**: Hasheados con bcrypt (costo 10)

```typescript
// Ejemplo: Hashing de PIN
const pinHash = await bcrypt.hash(pin, 10);
```

#### Datos Sensibles
- **PINs**: Nunca almacenados en texto plano
- **IPs**: Hasheadas opcionalmente
- **Geolocalización**: Truncada a 6 decimales (±10m)

### 4. Validaciones de Seguridad

#### Geofencing
```typescript
// Cálculo de distancia Haversine
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371000; // metros
  // ... fórmula Haversine
  return distance;
}

// Validación
if (distance > location.geofence_radius_m) {
  throw new Error('OUT_OF_GEOFENCE');
}
```

#### IP Whitelisting
```typescript
const clientIP = req.headers.get('x-forwarded-for');
if (!location.ip_whitelist.includes(clientIP)) {
  throw new Error('IP_NOT_ALLOWED');
}
```

#### Secuencia de Fichajes
```sql
CREATE FUNCTION validate_clock_sequence(
  p_employee_id UUID,
  p_type clock_event_type,
  p_timestamp TIMESTAMPTZ
) RETURNS BOOLEAN
-- Valida: IN -> OUT -> IN (no permite IN -> IN)
```

### 5. Rate Limiting

#### Endpoints Críticos
```
/api/clock         -> 60 req/min por IP
/api/login         -> 5 req/min por IP
/api/export-report -> 10 req/hour por organización
/functions/v1/*    -> 100 req/min por usuario
```

**Implementación**: Supabase Edge Functions + Redis (opcional)

### 6. Prevención de Ataques

#### SQL Injection
- **Prepared Statements**: Supabase usa parameterización
- **ORM validación**: TypeScript types

#### XSS (Cross-Site Scripting)
- **React auto-escaping**: Variables escapadas por defecto
- **CSP Headers**: Content Security Policy configurado
```
Content-Security-Policy: 
  default-src 'self';
  script-src 'self' 'unsafe-inline' 'unsafe-eval';
  style-src 'self' 'unsafe-inline';
```

#### CSRF (Cross-Site Request Forgery)
- **SameSite cookies**: Configurado en producción
- **CORS restrictivo**: Solo dominios autorizados

#### Clickjacking
```
X-Frame-Options: DENY
```

### 7. Auditoría y Monitorización

#### Logs de Auditoría
Tabla `audit_logs` registra:
- Usuario (actor_user_id)
- Acción (INSERT, UPDATE, DELETE, EXPORT)
- Entidad (tabla afectada)
- Antes/Después (JSONB)
- IP, User Agent, Timestamp

**Retención**: Indefinida (cumplimiento legal)

#### Eventos Críticos Monitorizados
- Inicios de sesión fallidos (3 intentos = bloqueo temporal)
- Cambios en configuración de organización
- Exportaciones de datos
- Fichajes fuera de geovalla
- Modificaciones masivas

### 8. Gestión de Secretos

#### Variables de Entorno
```bash
# NUNCA commitear en Git
SUPABASE_SERVICE_ROLE_KEY=***
ENCRYPTION_KEY=***
GOOGLE_MAPS_API_KEY=***

# Solo en servidor
DATABASE_URL=***
WEBHOOK_SECRET=***
```

#### Rotación de Claves
- **API Keys**: Rotación semestral recomendada
- **JWT Secrets**: Rotación anual
- **Encryption Keys**: Rotación con migración de datos

### 9. Gestión de Vulnerabilidades

#### Actualizaciones
```bash
# Verificar vulnerabilidades
npm audit

# Aplicar parches automáticos
npm audit fix
```

#### Dependencias
- **Dependabot**: Alertas automáticas de GitHub
- **Snyk**: Escaneo continuo
- **Updates frecuentes**: Mensuales

### 10. Backup y Recuperación

#### Estrategia 3-2-1
- **3 copias** de datos
- **2 medios** diferentes
- **1 copia** offsite

#### Supabase Backups
- **Automáticos**: Diarios (retención 7 días)
- **Point-in-Time Recovery**: Hasta 7 días atrás
- **Manuales**: Antes de cambios críticos

#### Procedimiento de Recuperación
```bash
# 1. Exportar backup
supabase db dump > backup_YYYYMMDD.sql

# 2. Restaurar
supabase db reset
psql $DATABASE_URL < backup_YYYYMMDD.sql
```

### 11. Protección de Datos Biométricos

#### Medidas Específicas (si biometría activa)
- **Consentimiento explícito** registrado
- **Encriptación adicional** (AES-256)
- **Acceso restringido**: Solo admin con justificación
- **Logs detallados**: Cada acceso registrado
- **DPIA obligatoria**: Ver DPIA.example.md
- **Alternativa siempre disponible**: PIN

### 12. Seguridad en Desarrollo

#### Pre-Deployment Checklist
- [ ] Variables secretas en `.env`, NO en código
- [ ] RLS habilitado en todas las tablas
- [ ] Tests de seguridad ejecutados
- [ ] Dependencias actualizadas
- [ ] HTTPS habilitado
- [ ] CORS configurado correctamente
- [ ] Rate limiting activo
- [ ] Logs de auditoría funcionando
- [ ] Backup automático configurado

### 13. Respuesta a Incidentes

#### Procedimiento
1. **Detección**: Monitorización continua
2. **Contención**: Bloqueo de acceso afectado
3. **Erradicación**: Eliminar vulnerabilidad
4. **Recuperación**: Restaurar servicio
5. **Lecciones**: Post-mortem documentado

#### Notificación de Brechas (RGPD)
- **72 horas** para notificar a AEPD
- **Inmediato** si afecta a derechos/libertades
- **Contacto**: dpo@techcorp.es

### 14. Formación y Concienciación

#### Usuarios Administradores
- Uso correcto de permisos
- No compartir credenciales
- Reportar actividad sospechosa
- Verificar fichajes antes de export

#### Empleados
- Protección de PIN
- No fichar por otros
- Reportar anomalías

### 15. Compliance y Certificaciones

#### Estándares Aplicados
- **ISO 27001**: Gestión de Seguridad de la Información (recomendado)
- **ENS**: Esquema Nacional de Seguridad (si sector público)
- **GDPR**: Cumplimiento completo

#### Auditorías
- **Interna**: Trimestral
- **Externa**: Anual (recomendado)
- **Pentesting**: Anual

### Contacto Seguridad

Para reportar vulnerabilidades:
- **Email**: security@techcorp.es
- **PGP Key**: [Publicar clave pública]
- **Bug Bounty**: Considerar programa de recompensas

---

**Actualizado**: 2025-10-30  
**Versión**: 1.0  
**Próxima auditoría**: 2026-01-30
