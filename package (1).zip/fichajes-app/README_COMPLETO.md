# 🕐 Sistema de Fichaje de Empleados - Full Stack SaaS

Sistema profesional multi-empresa de gestión de tiempo y asistencia con cumplimiento normativo completo UE/España (GDPR, RD-ley 8/2019, Directiva 2003/88/CE).

## ✨ Características Principales

### 🎯 Funcionalidades Core
- ✅ **Multi-tenant** con aislamiento estricto de datos (RLS)
- ✅ **Fichaje multi-canal**: Web, Kiosko PIN, API REST
- ✅ **Geofencing** con validación GPS y radio configurable
- ✅ **Validación IP** por whitelist
- ✅ **PWA Offline** con sincronización automática
- ✅ **Cumplimiento legal** UE: cálculo automático descansos obligatorios
- ✅ **Reportes firmados** con hash SHA-256 para inspecciones
- ✅ **Gestión ausencias** con workflow de aprobación
- ✅ **Audit trail** completo con logs inmutables

### 🔐 Seguridad y Cumplimiento
- ✅ GDPR: Retención 4 años, portabilidad, derecho al olvido
- ✅ RD-ley 8/2019: Registro diario obligatorio España
- ✅ Directiva 2003/88/CE: Descansos mínimos UE
- ✅ Encriptación en tránsito (HTTPS) y reposo
- ✅ PINs hasheados con bcrypt
- ✅ Biometría opcional (deshabilitada por defecto)

### 🎨 Interfaces
1. **Panel Admin**: CRUD empleados, ubicaciones con mapa, reportes avanzados
2. **Panel Empleado**: Fichaje web con geoloc, historial, solicitud ausencias
3. **Modo Kiosko**: Entrada PIN 4 dígitos para fichaje rápido

## 🛠️ Stack Tecnológico

### Frontend
- **Framework**: Next.js 14 (App Router) + TypeScript
- **UI**: Tailwind CSS + Lucide Icons
- **Formularios**: React Hook Form + Zod validation
- **Data Fetching**: TanStack Query (React Query v5)
- **Mapas**: Google Maps API + @react-google-maps/api
- **PWA**: Service Worker + IndexedDB
- **Fechas**: date-fns (localización español)

### Backend
- **BaaS**: Supabase (Auth + Postgres + Edge Functions + Storage)
- **Base de Datos**: PostgreSQL 15 con Row Level Security (RLS)
- **Edge Functions**: Deno runtime para lógica server-side
- **Auth**: Supabase Auth con roles personalizados

### DevOps
- **Package Manager**: pnpm
- **Containerization**: Docker + docker-compose
- **CI/CD**: GitHub Actions
- **Deploy**: Netlify (frontend) + Supabase (backend)

## 📦 Instalación

### Prerrequisitos
- Node.js 20+ y pnpm
- Cuenta Supabase (gratis)
- Google Maps API Key (opcional para mapas)

### 1. Clonar repositorio
```bash
git clone <repo-url>
cd fichajes-app
```

### 2. Instalar dependencias
```bash
pnpm install
```

### 3. Configurar variables de entorno
Crear `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://tu-proyecto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu-anon-key
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=tu-google-maps-key
```

### 4. Configurar Supabase

#### A. Crear proyecto en Supabase
1. Ir a https://supabase.com/dashboard
2. Crear nuevo proyecto
3. Copiar URL y anon key

#### B. Aplicar migraciones SQL
Ejecutar en orden en el SQL Editor de Supabase:
1. `supabase/schema.sql` - Esquema completo (14 tablas)
2. `supabase/policies.sql` - RLS policies
3. `supabase/seed.sql` - Datos demo (opcional)

#### C. Desplegar Edge Functions
```bash
cd supabase/functions
supabase functions deploy clock-event
supabase functions deploy export-report
```

### 5. Ejecutar en desarrollo
```bash
pnpm dev
```
Abrir http://localhost:3000

## 🚀 Deploy a Producción

### Opción 1: Netlify (Recomendado)

#### Deploy automático con GitHub
1. Conectar repo a Netlify
2. Configurar variables de entorno en Netlify UI
3. Deploy automático en cada push a `main`

#### Deploy manual
```bash
pnpm build
netlify deploy --prod
```

### Opción 2: Docker

```bash
# Build imagen
docker build -t fichajes-app .

# Run con docker-compose
docker-compose up -d
```

### Opción 3: Vercel
```bash
vercel --prod
```

## 🧪 Testing

### Tests E2E (Playwright)
```bash
# Instalar Playwright
pnpm add -D @playwright/test

# Ejecutar tests
pnpm test:e2e
```

### Tests Unitarios (Vitest)
```bash
# Instalar Vitest
pnpm add -D vitest @testing-library/react @testing-library/jest-dom

# Ejecutar tests
pnpm test
```

## 📱 PWA - Uso Offline

La aplicación funciona offline gracias al Service Worker:

1. **Cacheo automático**: Páginas visitadas se guardan en cache
2. **Fichajes offline**: Se guardan en IndexedDB y sincronizan al recuperar conexión
3. **Instalación**: Click en "Añadir a pantalla de inicio" en móvil

## 👥 Usuarios Demo

Acceder con modo Kiosko (/kiosk):

| Empleado | Código | PIN  |
|----------|--------|------|
| María García | EMP001 | 1234 |
| Juan Rodríguez | EMP002 | 2345 |
| Ana Martínez | EMP003 | 3456 |
| Carlos López | EMP004 | 4567 |
| Laura Sánchez | EMP005 | 5678 |

**Organización**: TechCorp España S.L.

## 📊 Estructura de Base de Datos

### Tablas Principales
1. **organizations**: Datos empresa (CIF, nombre, config)
2. **employees**: Empleados con PINs hasheados
3. **clock_events**: Eventos IN/OUT/BREAK (inmutables)
4. **locations**: Ubicaciones con geofencing
5. **work_shifts**: Turnos de trabajo
6. **daily_hours_summary**: Vista materializada horas/día
7. **incidents**: Incidencias automáticas (tardanzas, violaciones)
8. **leave_requests**: Solicitudes ausencias
9. **audit_logs**: Logs de auditoría
10. **webhooks**: Configuración webhooks externos

## 🔌 API Edge Functions

### 1. clock-event
**POST** `https://[project].supabase.co/functions/v1/clock-event`

Registra fichaje con validaciones:
- Secuencia correcta (IN → OUT → IN...)
- Geofencing (si requerido)
- IP whitelist
- Detección tardanzas
- Cálculo descansos UE

```json
{
  "employee_id": "uuid",
  "event_type": "IN",
  "location_id": "uuid",
  "latitude": 40.416775,
  "longitude": -3.703790
}
```

### 2. export-report
**POST** `https://[project].supabase.co/functions/v1/export-report`

Genera reporte firmado para inspección laboral:

```json
{
  "startDate": "2025-01-01",
  "endDate": "2025-01-31",
  "employeeId": "uuid",
  "format": "csv"
}
```

Respuesta incluye hash SHA-256 para verificación.

## 🗂️ Estructura del Proyecto

```
fichajes-app/
├── app/                      # Next.js App Router
│   ├── admin/               # Panel administración
│   │   ├── dashboard/       # Dashboard admin
│   │   ├── employees/       # CRUD empleados
│   │   ├── locations/       # Gestión ubicaciones + mapa
│   │   └── reports/         # Reportes avanzados
│   ├── employee/            # Portal empleado
│   │   ├── dashboard/       # Dashboard personal
│   │   ├── clock/           # Fichaje web
│   │   ├── history/         # Historial fichajes
│   │   └── leave/           # Solicitud ausencias
│   ├── kiosk/               # Modo kiosko PIN
│   └── login/               # Autenticación
├── components/              # Componentes reutilizables
│   └── pwa-register.tsx     # Registro Service Worker
├── lib/                     # Utilidades y configuración
│   ├── supabase.ts          # Cliente Supabase
│   ├── auth-context.tsx     # Context autenticación
│   └── query-provider.tsx   # TanStack Query provider
├── public/                  # Assets estáticos
│   ├── sw.js                # Service Worker
│   ├── manifest.json        # Manifest PWA
│   └── offline.html         # Página offline
├── supabase/                # Backend Supabase
│   ├── schema.sql           # Esquema BD (401 líneas)
│   ├── policies.sql         # RLS policies (430 líneas)
│   ├── seed.sql             # Datos demo (222 líneas)
│   └── functions/           # Edge Functions
│       ├── clock-event/     # Fichaje con validaciones
│       └── export-report/   # Exportación firmada
├── .github/workflows/       # CI/CD GitHub Actions
│   └── ci-cd.yml            # Pipeline completo
├── Dockerfile               # Imagen Docker
├── docker-compose.yml       # Orquestación containers
├── netlify.toml             # Config deploy Netlify
└── README.md                # Esta documentación
```

## 📄 Documentación Adicional

- **LEGAL.md**: Cumplimiento normativo UE/España (258 líneas)
- **SECURITY.md**: Medidas seguridad técnicas (304 líneas)
- **PRIVACY.md**: Política privacidad GDPR (286 líneas)
- **DPIA.example.md**: Evaluación impacto biometría (351 líneas)
- **PANEL_ADMIN_README.md**: Guía panel admin (168 líneas)
- **ENTREGA_PANEL_ADMIN.md**: Resumen entrega (201 líneas)

## 🐛 Troubleshooting

### Error: "Invalid API key" (Google Maps)
- Verificar que `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY` esté en `.env.local`
- Habilitar "Maps JavaScript API" en Google Cloud Console

### Error: "Row violates RLS policy"
- Verificar que el usuario esté autenticado
- Verificar que `user_id` esté en tabla `employees`
- Revisar políticas RLS en Supabase Dashboard

### Service Worker no registra
- Verificar que la app esté en HTTPS (o localhost)
- Abrir DevTools → Application → Service Workers
- Click "Unregister" y recargar página

### Build falla con "Module not found"
```bash
# Limpiar cache y reinstalar
rm -rf .next node_modules pnpm-lock.yaml
pnpm install
pnpm build
```

## 🤝 Contribución

1. Fork el proyecto
2. Crear rama feature (`git checkout -b feature/AmazingFeature`)
3. Commit cambios (`git commit -m 'Add AmazingFeature'`)
4. Push a rama (`git push origin feature/AmazingFeature`)
5. Abrir Pull Request

## 📝 Licencia

Este proyecto es privado y propietario. Todos los derechos reservados.

## 👨‍💻 Desarrollado por

**MiniMax Agent**  
Fecha: 2025-10-30  
Versión: 1.0.0

---

## 📊 Estadísticas del Proyecto

- **Total líneas código**: ~6,000 líneas
  - Backend SQL: 1,100 líneas
  - Frontend TS/TSX: 3,300 líneas
  - Edge Functions: 530 líneas
  - Documentación: 1,700 líneas
- **Componentes React**: 25+
- **Tablas BD**: 14
- **Edge Functions**: 2
- **Tests**: Preparado para Playwright

## 🔗 Enlaces Útiles

- [Supabase Docs](https://supabase.com/docs)
- [Next.js Docs](https://nextjs.org/docs)
- [TanStack Query](https://tanstack.com/query/latest)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [React Hook Form](https://react-hook-form.com/)
- [Google Maps API](https://developers.google.com/maps)

---

**Estado**: ✅ Producción Ready  
**Última actualización**: 2025-10-30 19:30:00
