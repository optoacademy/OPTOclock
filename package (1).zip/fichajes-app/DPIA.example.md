# DPIA - Evaluación de Impacto en Protección de Datos (Biometría)

**Data Protection Impact Assessment - DPIA**

**EJEMPLO - SOLO APLICABLE SI SE ACTIVA BIOMETRÍA**

---

## Información General

**Organización**: [NOMBRE EMPRESA]  
**Responsable del Tratamiento**: [NOMBRE Y CARGO]  
**DPO**: [NOMBRE DPO]  
**Fecha**: [FECHA EVALUACIÓN]  
**Versión**: 1.0

## 1. Descripción del Tratamiento

### 1.1 Contexto y Finalidad

**Finalidad principal**: Control de presencia mediante reconocimiento biométrico (huella dactilar o facial).

**Contexto**:
- Sistema de fichaje de empleados
- Alternativa al PIN tradicional
- Uso voluntario con consentimiento explícito

### 1.2 Datos Tratados

**Categoría especial de datos (Art. 9 RGPD)**:
- **Plantillas biométricas** derivadas de:
  - Huella dactilar (fingerprint template)
  - Reconocimiento facial (facial template)

**Características**:
- Dato irreversible (hash biométrico)
- Único por persona
- NO se almacenan imágenes originales
- Template cifrado AES-256

**Otros datos asociados**:
- ID empleado
- Timestamp del fichaje
- Ubicación del dispositivo

### 1.3 Base Legal

**Artículo 9.2.a RGPD**: Consentimiento explícito del interesado

**Requisitos**:
- Consentimiento libre (alternativa PIN disponible)
- Específico (solo para fichaje)
- Informado (información clara)
- Inequívoco (acción afirmativa)

### 1.4 Alcance

**Usuarios afectados**: Empleados que opten voluntariamente  
**Ubicaciones**: Dispositivos biométricos en centros de trabajo  
**Duración**: Mientras dure relación laboral + período retención (4 años)

## 2. Necesidad y Proporcionalidad

### 2.1 Necesidad del Tratamiento

**¿Es necesario el tratamiento biométrico?**

**NO es estrictamente necesario**:
- Alternativa: PIN de 4 dígitos
- Alternativa: Tarjeta RFID
- Alternativa: Usuario/contraseña

**Ventajas biometría**:
- Mayor seguridad (no transferible)
- Evita suplantación de identidad
- Rapidez de fichaje
- No olvidar PIN

**Conclusión**: Biometría es una **mejora opcional**, NO obligatoria.

### 2.2 Proporcionalidad

**Minimización de datos**:
- ✅ Solo template (hash), NO imagen completa
- ✅ No se almacena huella real
- ✅ Template de tamaño reducido (<1KB)
- ✅ Cifrado en reposo y tránsito

**Limitación de finalidad**:
- ✅ Solo fichaje de jornada
- ✅ NO para otros controles
- ✅ NO compartido con otras aplicaciones

## 3. Riesgos para Derechos y Libertades

### 3.1 Identificación de Riesgos

| Riesgo | Probabilidad | Impacto | Nivel |
|--------|--------------|---------|-------|
| **Acceso no autorizado a templates** | Baja | Alto | MEDIO |
| **Suplantación de identidad** | Muy Baja | Alto | BAJO |
| **Uso indebido de datos biométricos** | Baja | Muy Alto | MEDIO-ALTO |
| **Fuga de datos biométricos** | Baja | Muy Alto | MEDIO-ALTO |
| **Discriminación por no uso biometría** | Media | Medio | MEDIO |
| **Fallo técnico que impide fichaje** | Media | Bajo | BAJO |

### 3.2 Análisis Detallado de Riesgos

#### Riesgo 1: Acceso No Autorizado
**Descripción**: Un tercero accede a los templates biométricos almacenados.

**Consecuencias**:
- Identificación única de personas
- Posible tracking en otros sistemas
- Pérdida de privacidad permanente (no se puede cambiar huella)

**Probabilidad**: Baja
- Cifrado AES-256
- RLS multi-tenant
- Logs de acceso

**Impacto**: Alto
- Dato sensible irreversible

#### Riesgo 2: Discriminación
**Descripción**: Empleados que no usan biometría son tratados de forma diferente.

**Consecuencias**:
- Presión para usar biometría
- Estigmatización

**Probabilidad**: Media
- Depende de cultura organizacional

**Impacto**: Medio
- Afecta derechos laborales

#### Riesgo 3: Fuga de Datos
**Descripción**: Brecha de seguridad expone templates biométricos.

**Consecuencias**:
- Dato irreversible comprometido
- Posible uso en otros sistemas
- Daño reputacional permanente

**Probabilidad**: Baja
- Medidas de seguridad robustas

**Impacto**: Muy Alto
- No se puede "resetear" huella

## 4. Medidas de Mitigación

### 4.1 Medidas Técnicas

#### Encriptación Avanzada
```typescript
// Template biométrico cifrado
const encryptedTemplate = await AES256.encrypt(
  biometricTemplate,
  ENCRYPTION_KEY
);
```

#### Aislamiento de Datos
- Base de datos separada para biometría
- RLS estricto (solo admin con justificación)
- No mezclar con otros datos

#### Auditoría Exhaustiva
```sql
-- Log cada acceso a datos biométricos
INSERT INTO audit_logs (
  action,
  entity,
  actor_user_id,
  ip_address,
  justification
) VALUES (
  'BIOMETRIC_ACCESS',
  'biometric_templates',
  $1, $2, $3
);
```

### 4.2 Medidas Organizativas

#### Consentimiento Explícito
```
[X] He sido informado sobre el tratamiento de mis datos biométricos
[X] Comprendo que puedo usar PIN como alternativa
[X] Consiento el uso de biometría ÚNICAMENTE para fichaje
[X] Puedo retirar mi consentimiento en cualquier momento

Firma: ________________  Fecha: __________
```

#### Formación Personal Autorizado
- Solo admin con formación DPO
- Acceso con doble autenticación
- Justificación obligatoria por escrito

#### Alternativa Siempre Disponible
- **PIN 4 dígitos**: Funcionando en paralelo
- **Sin penalización**: Mismo trato
- **Retirada consentimiento**: Borrado inmediato de template

### 4.3 Medidas Legales

#### Contratos con Proveedores
- **DPA firmado** con proveedor de sensores biométricos
- **Certificación ISO 27001** del proveedor
- **Cláusulas de borrado** al finalizar contrato

#### Información Transparente
- **Folleto informativo** entregado a empleados
- **FAQ biometría** en intranet
- **Sesión informativa** antes de activación

## 5. Consulta a Interesados

### 5.1 Representantes de los Trabajadores
**Fecha consulta**: [FECHA]  
**Resultado**: [APROBACIÓN/RECHAZO/CONDICIONES]

**Acuerdos alcanzados**:
- Uso voluntario
- No penalización por no uso
- Auditoría trimestral

### 5.2 DPO
**Opinión del DPO**: [FAVORABLE/DESFAVORABLE]  
**Recomendaciones**:
- [LISTA DE RECOMENDACIONES]

## 6. Medidas Adoptadas

| Medida | Estado | Responsable | Fecha Implementación |
|--------|--------|-------------|----------------------|
| Cifrado AES-256 templates | ✅ Implementado | CTO | [FECHA] |
| RLS estricto | ✅ Implementado | DBA | [FECHA] |
| Auditoría exhaustiva | ✅ Implementado | Backend Dev | [FECHA] |
| Formulario consentimiento | ✅ Listo | RRHH | [FECHA] |
| Formación personal | 🔄 Planificado | DPO | [FECHA] |
| Política de borrado | ✅ Documentada | Legal | [FECHA] |
| Pruebas seguridad | 🔄 Trimestral | CISO | Continuo |

## 7. Evaluación Residual de Riesgos

Tras aplicar medidas:

| Riesgo | Nivel Inicial | Nivel Residual |
|--------|---------------|----------------|
| Acceso no autorizado | MEDIO | **BAJO** |
| Suplantación | BAJO | **MUY BAJO** |
| Uso indebido | MEDIO-ALTO | **BAJO** |
| Fuga de datos | MEDIO-ALTO | **BAJO** |
| Discriminación | MEDIO | **BAJO** |

**Conclusión**: Riesgos **ACEPTABLES** tras implementación de medidas.

## 8. Supervisión y Revisión

### 8.1 Revisión Periódica
**Frecuencia**: Trimestral

**Aspectos a revisar**:
- Efectividad de medidas
- Nuevos riesgos identificados
- Cambios normativos
- Incidentes de seguridad

### 8.2 Indicadores (KPIs)
- % empleados usan biometría vs PIN
- Nº accesos a templates biométricos
- Nº incidentes seguridad biometría
- Nº retiradas de consentimiento

### 8.3 Auditoría Externa
**Frecuencia**: Anual  
**Auditor**: [NOMBRE EMPRESA AUDITORA]  
**Próxima auditoría**: [FECHA]

## 9. Registro de Decisiones

### 9.1 Decisión Final

**¿Se implementa biometría?**: [SÍ/NO]

**Justificación**:
[ARGUMENTOS]

**Condiciones**:
- Uso voluntario
- Alternativa PIN siempre disponible
- Consentimiento informado y libre
- Auditoría trimestral
- Revisión DPIA anual

### 9.2 Aprobaciones

**Responsable del Tratamiento**: _______________ Fecha: _______  
**DPO**: _______________ Fecha: _______  
**Comité de Empresa** (si aplica): _______________ Fecha: _______

## 10. Documentación Anexa

- [Anexo I] Formulario de consentimiento biométrico
- [Anexo II] Información a empleados sobre biometría
- [Anexo III] Procedimiento de borrado de templates
- [Anexo IV] Especificaciones técnicas del sistema biométrico
- [Anexo V] Acta reunión con representantes de trabajadores

## 11. Consulta Previa a Autoridad (si necesario)

**Artículo 36 RGPD**: Consulta previa a la autoridad de control si el DPIA indica un alto riesgo residual.

**¿Alto riesgo residual tras medidas?**: NO  
**¿Consulta a AEPD necesaria?**: NO

Si fuera necesario:
- **Fecha consulta**: [FECHA]
- **Respuesta AEPD**: [REFERENCIA]
- **Decisión**: [APROBACIÓN/CONDICIONES/RECHAZO]

---

## Resumen Ejecutivo

**Conclusión DPIA**: El tratamiento de datos biométricos para fichaje de jornada laboral, con las medidas implementadas, presenta un **nivel de riesgo BAJO-ACEPTABLE** para los derechos y libertades de los empleados.

**Requisitos clave**:
✅ Uso voluntario (alternativa PIN)  
✅ Consentimiento explícito  
✅ Cifrado AES-256  
✅ RLS estricto  
✅ Auditoría completa  
✅ Información transparente  
✅ Derecho de retirada  

**Próxima revisión**: [FECHA + 12 MESES]

---

**Fecha de aprobación**: __________  
**Firma Responsable del Tratamiento**: __________  
**Firma DPO**: __________

---

**IMPORTANTE**: Este documento es un EJEMPLO. Debe ser adaptado a cada organización específica y revisado por un DPO cualificado antes de implementar biometría.
