# Cumplimiento Legal y Normativo

## Marco Legal Aplicable

Este sistema cumple con la normativa laboral española y europea en materia de registro de jornada y protección de datos.

### Normativa Española

#### 1. Real Decreto-ley 8/2019
**Registro de jornada obligatorio**

Artículo 34.9 del Estatuto de los Trabajadores:
> "La empresa garantizará el registro diario de jornada, que deberá incluir el horario concreto de inicio y finalización de la jornada de trabajo de cada persona trabajadora."

**Implementación**:
- Tabla `clock_events` con timestamp preciso de entrada/salida
- Fuente registrada (web, móvil, kiosko)
- Geolocalización opcional
- Inmutabilidad mediante hash diario

#### 2. Ley Orgánica 3/2018 (LOPDGDD)
**Protección de Datos Personales y garantía de los derechos digitales**

**Artículo 22**: Tratamiento de datos en el ámbito laboral
- Base legal: Ejecución del contrato laboral + cumplimiento obligación legal
- Finalidad: Control de jornada laboral
- Legitimación: Art. 6.1.b y 6.1.c RGPD

**Implementación**:
- Consentimiento NO requerido (obligación legal)
- Política de privacidad clara (ver PRIVACY.md)
- Derechos ARCO implementados
- DPO designable

#### 3. Retención de Datos
**Plazo mínimo**: 4 años (Ley General Tributaria + Estatuto de los Trabajadores)

**Implementación**:
- NO borrado físico antes de 4 años
- Soft delete con flag `is_active`
- Anonimización post-retención (si aplica)
- Backup automático

### Normativa Europea

#### 1. RGPD (Reglamento 2016/679)
**Protección de Datos**

**Principios aplicados**:
- **Licitud**: Base legal clara (contrato + obligación legal)
- **Limitación de finalidad**: Solo control horario
- **Minimización**: Datos estrictamente necesarios
- **Exactitud**: Posibilidad de corrección
- **Limitación de plazo**: Retención definida
- **Integridad**: Medidas técnicas y organizativas

**Implementación**:
- RLS multi-tenant estricto
- Encriptación en tránsito (TLS) y reposo
- Logs de auditoría
- Derecho al olvido (post-retención)
- Portabilidad de datos (export CSV/JSON)

#### 2. Directiva 2003/88/CE
**Ordenación del tiempo de trabajo**

**Obligaciones**:
- **11 horas** de descanso entre jornadas
- **Pausa** si jornada > 6 horas
- **24 horas** de descanso semanal
- **48 horas** máximo semanal (promedio 4 meses)

**Implementación**:
- Función `validate_eu_rest_rules()` (a implementar)
- Incidencias automáticas por violación
- Alertas preventivas
- Bloqueo opcional de fichajes

### Derechos de los Trabajadores

#### 1. Derecho de Acceso
**Artículo 15 RGPD**

Los trabajadores pueden:
- Ver sus propios fichajes (panel empleado)
- Solicitar copia completa (export CSV)
- Verificar exactitud de datos

**Implementación**:
- Endpoint `/api/employee/my-data`
- Dashboard empleado con historial completo
- Export automático

#### 2. Derecho de Rectificación
**Artículo 16 RGPD**

Los trabajadores pueden:
- Solicitar corrección de fichajes erróneos
- Admin puede modificar con auditoría

**Implementación**:
- Tabla `audit_logs` registra cambios
- Antes/después en JSONB
- No borrado, solo corrección

#### 3. Representantes de los Trabajadores
**Artículo 64 del Estatuto de los Trabajadores**

Los representantes tienen derecho a:
- Conocer modelos de control de presencia
- Acceso a datos agregados de plantilla

**Implementación**:
- Tabla `representatives`
- RLS permite lectura a representantes
- Dashboard específico

### Inspección de Trabajo

#### 1. Acceso a Registros
**Ley 23/2015 de Ordenación del Sistema de Inspección de Trabajo**

La Inspección puede:
- Solicitar registros de cualquier período
- Verificar cumplimiento normativo
- Sancionar incumplimientos

**Implementación**:
- Endpoint `/api/export-report` con autenticación
- Export firmado con hash SHA-256
- Metadatos incluidos (organización, período, total registros)
- Formato CSV estándar

#### 2. Sanciones
**Infracciones graves**: 626€ - 6.250€
- No llevar registro de jornada
- Registro incompleto o inexacto

**Infracciones muy graves**: 6.251€ - 187.515€
- Obstaculización a la Inspección
- Datos falseados

### Biometría (Opcional)

#### 1. Condiciones de Uso
**Artículo 9 RGPD**: Categoría especial de datos

**Requisitos**:
- Consentimiento explícito del trabajador
- Alternativa NO biométrica (PIN)
- DPIA obligatoria (ver DPIA.example.md)
- Registro en AEPD (si > 5.000 trabajadores)

**Implementación**:
- Desactivada por defecto (`biometric_enabled=false`)
- Consentimiento individual registrado
- PIN siempre disponible como alternativa

### Transmisiones Internacionales

#### 1. Ubicación de Servidores
**Artículo 44-49 RGPD**

Supabase (backend):
- Región: EU (Frankfurt, Alemania)
- Cumple RGPD por diseño
- Cláusulas contractuales tipo

Netlify (frontend):
- CDN global con nodos EU
- DPA firmado

### Retención y Borrado

#### 1. Plazos
- **Activos**: Conservación indefinida mientras relación laboral
- **Finalizados**: 4 años desde fin de relación
- **Post-retención**: Anonimización o borrado

#### 2. Procedimiento de Borrado
```sql
-- Anonimización (NO borrado físico)
UPDATE clock_events 
SET 
  notes = NULL,
  ip_address = NULL,
  user_agent = NULL,
  lat = NULL,
  lng = NULL
WHERE employee_id IN (
  SELECT id FROM employees 
  WHERE termination_date < NOW() - INTERVAL '4 years'
);
```

### Auditoría y Trazabilidad

#### 1. Registro de Actividad
**Artículo 30 RGPD**: Registro de actividades de tratamiento

**Implementación**:
- Tabla `audit_logs` con:
  - Actor (quién)
  - Acción (qué)
  - Entidad (sobre qué)
  - Antes/después (cambios)
  - IP, user agent, timestamp

#### 2. Inmutabilidad
Hash SHA-256 del parte diario:
```
hash = SHA256(
  event1.id + event1.type + event1.timestamp_utc + "|" +
  event2.id + event2.type + event2.timestamp_utc + "|" +
  ...
)
```

Almacenado en `daily_hours_summary.daily_hash`

### Responsabilidades

#### 1. Responsable del Tratamiento
- Empresa empleadora (cada organización)
- Determina fines y medios

#### 2. Encargado del Tratamiento
- Proveedor del sistema (Supabase, Netlify)
- Contrato de encargado firmado

#### 3. DPO (Delegado de Protección de Datos)
Obligatorio si:
- Sector público
- Tratamiento a gran escala de categorías especiales (biometría)
- Seguimiento habitual y sistemático a gran escala

### Documentos Obligatorios

- [x] Política de Privacidad (PRIVACY.md)
- [x] Información sobre tratamiento de datos
- [x] Medidas de seguridad (SECURITY.md)
- [x] Procedimiento derechos ARCO
- [x] DPIA (si biometría) (DPIA.example.md)
- [ ] Cláusulas informativas contratos
- [ ] Registro de actividades de tratamiento

### Contacto Legal

Para consultas legales o ejercicio de derechos:
- **Email**: dpo@techcorp.es
- **Autoridad competente**: Agencia Española de Protección de Datos (AEPD)
- **Web AEPD**: https://www.aepd.es

---

**Actualizado**: 2025-10-30  
**Versión**: 1.0  
**Próxima revisión**: 2026-10-30
