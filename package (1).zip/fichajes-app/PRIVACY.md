# Política de Privacidad

**Última actualización**: 30 de octubre de 2025  
**Versión**: 1.0

## 1. Responsable del Tratamiento

Cada organización que utiliza este sistema es responsable del tratamiento de los datos de sus empleados:

**Nombre**: [NOMBRE DE TU EMPRESA]  
**CIF**: [TU CIF]  
**Dirección**: [TU DIRECCIÓN]  
**Email**: [TU EMAIL DE CONTACTO]  
**DPO** (si aplica): [EMAIL DPO]

## 2. Datos Personales Tratados

### 2.1 Datos Básicos
- Nombre completo
- Email corporativo
- Teléfono (opcional)
- Código de empleado

### 2.2 Datos de Fichaje
- Fecha y hora de entrada/salida
- Tipo de evento (IN, OUT, BREAK_START, BREAK_END)
- Ubicación (geolocalización opcional)
- IP de origen
- Dispositivo utilizado (web, móvil, kiosko)

### 2.3 Datos Opcionales
- Fotografía (si ubicación lo requiere)
- Datos biométricos (solo si se activa y con consentimiento explícito)

### 2.4 Datos NO Tratados
- Datos de salud (salvo baja médica con justificante)
- Afiliación sindical
- Orientación sexual
- Creencias religiosas

## 3. Finalidad del Tratamiento

### Finalidad Principal
**Control de jornada laboral** conforme al artículo 34.9 del Estatuto de los Trabajadores modificado por RD-ley 8/2019.

### Finalidades Específicas
- Registro diario de horario de trabajo
- Cálculo de horas trabajadas y horas extra
- Gestión de ausencias y permisos
- Cumplimiento de normativa laboral
- Generación de reportes para Inspección de Trabajo
- Prevención de incumplimientos contractuales

## 4. Base Legal

### Legitimación del Tratamiento
**Artículo 6.1 RGPD**:

a) **Cumplimiento de obligación legal** (Art. 6.1.c RGPD)
   - Real Decreto-ley 8/2019
   - Estatuto de los Trabajadores
   - Directiva 2003/88/CE (ordenación tiempo de trabajo)

b) **Ejecución de contrato laboral** (Art. 6.1.b RGPD)
   - Gestión de relación laboral
   - Cumplimiento de obligaciones contractuales

**NO se requiere consentimiento** del trabajador para el registro de jornada (es obligación legal del empleador).

### Tratamiento de Datos Biométricos
Si se activa biometría:
- **Base legal**: Consentimiento explícito (Art. 9.2.a RGPD)
- **Consentimiento**: Libre, específico, informado e inequívoco
- **Alternativa**: PIN siempre disponible
- **DPIA**: Evaluación de impacto obligatoria

## 5. Destinatarios de los Datos

### 5.1 Encargados del Tratamiento
**Supabase Inc.** (Backend y base de datos)
- **Servicio**: Alojamiento de base de datos
- **Ubicación**: Unión Europea (Frankfurt, Alemania)
- **Garantías**: Cláusulas contractuales tipo, cumplimiento RGPD
- **Contrato**: DPA firmado

**Netlify Inc.** (Frontend y CDN)
- **Servicio**: Alojamiento de aplicación web
- **Ubicación**: Global con nodos en UE
- **Garantías**: DPA firmado, certificación ISO 27001
- **Transferencias**: Cláusulas contractuales tipo

### 5.2 Comunicación de Datos
Los datos pueden ser comunicados a:
- **Inspección de Trabajo y Seguridad Social** (obligación legal)
- **Juzgados y Tribunales** (cumplimiento de orden judicial)
- **Representantes de los trabajadores** (datos agregados, no individualizados sin consentimiento)

### 5.3 NO se Ceden Datos a Terceros
Salvo obligación legal, los datos NO se venden, alquilan ni ceden a terceros con fines comerciales.

## 6. Plazo de Conservación

### 6.1 Durante la Relación Laboral
**Conservación indefinida** mientras dure el contrato de trabajo.

### 6.2 Finalización de la Relación Laboral
**Mínimo 4 años** desde la finalización del contrato:
- Ley General Tributaria (conservación documentos fiscales)
- Normativa de Seguridad Social
- Prescripción de infracciones laborales

### 6.3 Tras el Plazo de Retención
- **Anonimización** de datos personales
- **Conservación estadística** de datos agregados
- **Borrado seguro** de información no necesaria

## 7. Derechos de los Trabajadores

Conforme al RGPD, tienes derecho a:

### 7.1 Derecho de Acceso (Art. 15 RGPD)
**Qué puedes hacer**:
- Solicitar copia de tus datos personales
- Conocer qué datos se tratan sobre ti
- Ver tus fichajes y reportes

**Cómo ejercerlo**:
- Panel empleado: Ver historial completo
- Email a: [EMAIL DPO/CONTACTO]
- Formulario web: [ENLACE SI APLICA]

**Plazo de respuesta**: 1 mes (ampliable 2 meses si complejidad)

### 7.2 Derecho de Rectificación (Art. 16 RGPD)
**Qué puedes hacer**:
- Corregir datos personales inexactos
- Solicitar modificación de fichajes erróneos

**Cómo ejercerlo**:
- Contactar a tu responsable directo
- Email a: [EMAIL DPO/CONTACTO]

**Importante**: Las correcciones quedan registradas en auditoría para cumplimiento legal.

### 7.3 Derecho de Supresión/Olvido (Art. 17 RGPD)
**Limitado por obligación legal**:
- NO aplicable mientras dure relación laboral
- NO aplicable durante período de retención legal (4 años)
- Aplicable tras período de retención si no hay otra base legal

### 7.4 Derecho de Limitación (Art. 18 RGPD)
**Qué puedes hacer**:
- Solicitar bloqueo temporal de datos si:
  - Impugnas la exactitud de los datos
  - El tratamiento es ilícito
  - Necesitas los datos para reclamación judicial

### 7.5 Derecho de Portabilidad (Art. 20 RGPD)
**Qué puedes hacer**:
- Recibir tus datos en formato estructurado (CSV, JSON)
- Transmitir datos a otro responsable

**Cómo ejercerlo**:
- Export automático desde panel empleado
- Solicitud por email: [EMAIL CONTACTO]

### 7.6 Derecho de Oposición (Art. 21 RGPD)
**Limitado**:
- NO aplicable al registro de jornada (obligación legal)
- Aplicable a tratamientos basados en interés legítimo (si los hubiera)

### 7.7 Derecho a No ser Objeto de Decisiones Automatizadas (Art. 22 RGPD)
**No aplica**: Este sistema NO toma decisiones automatizadas que produzcan efectos jurídicos (como despidos o sanciones).

Las incidencias detectadas automáticamente (llegadas tarde, ausencia de fichaje) son meramente informativas y requieren revisión humana.

## 8. Medidas de Seguridad

Ver documento completo [SECURITY.md](./SECURITY.md).

**Resumen**:
- Encriptación TLS/SSL
- Row Level Security (RLS) multi-tenant
- Autenticación robusta
- Backups automáticos
- Logs de auditoría
- PIN hasheado (bcrypt)
- Acceso por roles

## 9. Transferencias Internacionales

### 9.1 Ubicación de Datos
**Dentro de la UE**:
- Base de datos: Alemania (Frankfurt)
- Backups: Dentro UE

### 9.2 Proveedores No-UE
**Netlify** (USA):
- Garantías: Cláusulas contractuales tipo aprobadas por Comisión Europea
- Certificación: Privacy Shield (invalidado) sustituido por SCCs

## 10. Cookies y Tecnologías de Seguimiento

### 10.1 Cookies Técnicas (Obligatorias)
- **Sesión autenticación**: JWT en localStorage
- **Preferencias**: Idioma, zona horaria

**NO requieren consentimiento** (estrictamente necesarias).

### 10.2 Cookies Analíticas
**NO utilizamos** Google Analytics ni similares con datos personales.

Si se implementan en futuro: Consentimiento previo requerido.

## 11. Menores de Edad

Este sistema está diseñado para entornos laborales.

**NO permitido** el tratamiento de datos de menores de 16 años salvo:
- Contrato de formación (con autorización padres/tutores)
- Cumplimiento de normativa laboral específica

## 12. Reclamaciones

Si consideras que tus derechos no han sido atendidos:

### 12.1 Contacto Interno
**Email**: [EMAIL DPO/CONTACTO]  
**Teléfono**: [TELÉFONO]  
**Plazo de respuesta**: 1 mes

### 12.2 Autoridad de Control
**Agencia Española de Protección de Datos (AEPD)**
- **Web**: https://www.aepd.es
- **Sede electrónica**: https://sedeagpd.gob.es
- **Teléfono**: 901 100 099 / 912 663 517
- **Dirección**: C/ Jorge Juan, 6, 28001 Madrid

## 13. Modificaciones de la Política

### 13.1 Actualizaciones
Nos reservamos el derecho de modificar esta política para:
- Adaptarnos a cambios normativos
- Mejorar claridad informativa
- Incluir nuevas funcionalidades

### 13.2 Notificación de Cambios
**Cambios sustanciales**:
- Notificación por email corporativo
- Aviso en panel empleado
- Publicación en web

**Cambios menores**:
- Actualización de fecha y versión
- Publicación en web

## 14. Contacto y Ejercicio de Derechos

**Delegado de Protección de Datos (DPO)**:
- Email: dpo@techcorp.es
- Dirección: [DIRECCIÓN POSTAL]

**Formularios**:
- Acceso: [ENLACE]
- Rectificación: [ENLACE]
- Portabilidad: [ENLACE]

**Documentación adjunta**:
- [Formulario ejercicio de derechos](./FORMULARIO_DERECHOS.pdf)
- [Información adicional RGPD](./INFO_RGPD.pdf)

---

**He leído y comprendo la Política de Privacidad.**

Al utilizar el sistema de fichaje, confirmas haber sido informado sobre el tratamiento de tus datos personales conforme a esta política.

---

**Información adicional**:
- [LEGAL.md](./LEGAL.md) - Marco legal y cumplimiento normativo
- [SECURITY.md](./SECURITY.md) - Medidas de seguridad técnicas
- [DPIA.example.md](./DPIA.example.md) - Evaluación de impacto (biometría)

**Fecha efectiva**: 30 de octubre de 2025  
**Versión**: 1.0
