import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://cfzlqrwezvasadjfjudd.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNmemxxcndlenZhc2FkamZqdWRkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE4MTcxMjYsImV4cCI6MjA3NzM5MzEyNn0.XdTSP5a175C6kkxPeG4Y7sLjlWwsR4motNpYpeHpII0';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
