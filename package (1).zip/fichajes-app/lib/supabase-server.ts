import { createServerClient, type CookieOptions } from '@supabase/ssr'
import { cookies } from 'next/headers'

export function createClient() {
  const cookieStore = cookies()

  return createServerClient(
    'https://cfzlqrwezvasadjfjudd.supabase.co',
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNmemxxcndlenZhc2FkamZqdWRkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE4MTcxMjYsImV4cCI6MjA3NzM5MzEyNn0.XdTSP5a175C6kkxPeG4Y7sLjlWwsR4motNpYpeHpII0',
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value
        },
        set(name: string, value: string, options: CookieOptions) {
          cookieStore.set({ name, value, ...options })
        },
        remove(name: string, options: CookieOptions) {
          cookieStore.set({ name, value: '', ...options })
        },
      },
    }
  )
}
