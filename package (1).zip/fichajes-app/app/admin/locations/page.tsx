'use client'

import React, { useState, useCallback, useRef, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { GoogleMap, LoadScript, Marker, Circle } from '@react-google-maps/api'
import { supabase } from '@/lib/supabase'
import { Plus, Edit2, Trash2, MapPin, Save, X } from 'lucide-react'

type Location = {
  id: string
  name: string
  address: string | null
  latitude: number
  longitude: number
  geofence_radius_m: number
  ip_whitelist: string[] | null
  require_geofence: boolean
  require_photo: boolean
}

const mapContainerStyle = {
  width: '100%',
  height: '500px',
}

const defaultCenter = {
  lat: 40.416775,
  lng: -3.703790, // Madrid, España
}

export default function LocationsPage() {
  const queryClient = useQueryClient()
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [mapCenter, setMapCenter] = useState(defaultCenter)
  const [mapZoom, setMapZoom] = useState(6)

  // Estado del formulario
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    latitude: 0,
    longitude: 0,
    geofence_radius_m: 100,
    ip_whitelist: '',
    require_geofence: true,
    require_photo: false,
  })

  const GOOGLE_MAPS_API_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || 'AIzaSyCO0kKndUNlmQi3B5mxy4dblg_8WYcuKuk'

  // Obtener ubicaciones
  const { data: locations, isLoading } = useQuery({
    queryKey: ['locations'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('locations')
        .select('*')
        .order('name')
      if (error) throw error
      return data as Location[]
    },
  })

  // Eliminar ubicación
  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('locations')
        .delete()
        .eq('id', id)
      if (error) throw error
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['locations'] })
      alert('Ubicación eliminada correctamente')
    },
    onError: (error) => {
      console.error('Error al eliminar:', error)
      alert('Error al eliminar la ubicación')
    },
  })

  // Guardar ubicación
  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const locationData = {
        name: data.name,
        address: data.address || null,
        latitude: data.latitude,
        longitude: data.longitude,
        geofence_radius_m: data.geofence_radius_m,
        ip_whitelist: data.ip_whitelist ? data.ip_whitelist.split('\n').filter(ip => ip.trim()) : null,
        require_geofence: data.require_geofence,
        require_photo: data.require_photo,
      }

      if (selectedLocation) {
        const { error } = await supabase
          .from('locations')
          .update(locationData)
          .eq('id', selectedLocation.id)
        if (error) throw error
      } else {
        const { error } = await supabase
          .from('locations')
          .insert(locationData)
        if (error) throw error
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['locations'] })
      alert(selectedLocation ? 'Ubicación actualizada' : 'Ubicación creada')
      closeForm()
    },
    onError: (error) => {
      console.error('Error al guardar:', error)
      alert('Error al guardar la ubicación')
    },
  })

  const openForm = (location?: Location) => {
    if (location) {
      setSelectedLocation(location)
      setFormData({
        name: location.name,
        address: location.address || '',
        latitude: location.latitude,
        longitude: location.longitude,
        geofence_radius_m: location.geofence_radius_m,
        ip_whitelist: location.ip_whitelist?.join('\n') || '',
        require_geofence: location.require_geofence,
        require_photo: location.require_photo,
      })
      setMapCenter({ lat: location.latitude, lng: location.longitude })
      setMapZoom(15)
    } else {
      setSelectedLocation(null)
      setFormData({
        name: '',
        address: '',
        latitude: defaultCenter.lat,
        longitude: defaultCenter.lng,
        geofence_radius_m: 100,
        ip_whitelist: '',
        require_geofence: true,
        require_photo: false,
      })
      setMapCenter(defaultCenter)
      setMapZoom(6)
    }
    setIsFormOpen(true)
  }

  const closeForm = () => {
    setIsFormOpen(false)
    setSelectedLocation(null)
  }

  const handleMapClick = useCallback((e: google.maps.MapMouseEvent) => {
    if (e.latLng && isFormOpen) {
      const lat = e.latLng.lat()
      const lng = e.latLng.lng()
      setFormData(prev => ({
        ...prev,
        latitude: lat,
        longitude: lng,
      }))
      setMapCenter({ lat, lng })
      setMapZoom(15)
    }
  }, [isFormOpen])

  const handleDelete = (id: string, name: string) => {
    if (confirm(`¿Estás seguro de eliminar la ubicación "${name}"?`)) {
      deleteMutation.mutate(id)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name.trim()) {
      alert('El nombre es obligatorio')
      return
    }
    if (!formData.latitude || !formData.longitude) {
      alert('Debes seleccionar una ubicación en el mapa')
      return
    }
    saveMutation.mutate(formData)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Ubicaciones</h1>
              <p className="mt-1 text-sm text-gray-500">
                Gestiona las ubicaciones de trabajo y sus geovallas
              </p>
            </div>
            <button
              onClick={() => openForm()}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Nueva Ubicación
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Mapa */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="p-4 border-b bg-gray-50">
                <h2 className="font-semibold text-gray-900">
                  {isFormOpen ? 'Selecciona ubicación en el mapa' : 'Mapa de ubicaciones'}
                </h2>
                {isFormOpen && (
                  <p className="text-sm text-gray-500 mt-1">
                    Haz clic en el mapa para establecer las coordenadas
                  </p>
                )}
              </div>
              <LoadScript googleMapsApiKey={GOOGLE_MAPS_API_KEY}>
                <GoogleMap
                  mapContainerStyle={mapContainerStyle}
                  center={mapCenter}
                  zoom={mapZoom}
                  onClick={handleMapClick}
                  options={{
                    streetViewControl: false,
                    mapTypeControl: true,
                  }}
                >
                  {/* Marcadores de ubicaciones existentes */}
                  {!isFormOpen && locations?.map((loc) => (
                    <React.Fragment key={loc.id}>
                      <Marker
                        position={{ lat: loc.latitude, lng: loc.longitude }}
                        title={loc.name}
                        onClick={() => openForm(loc)}
                      />
                      <Circle
                        center={{ lat: loc.latitude, lng: loc.longitude }}
                        radius={loc.geofence_radius_m}
                        options={{
                          fillColor: '#3B82F6',
                          fillOpacity: 0.2,
                          strokeColor: '#3B82F6',
                          strokeOpacity: 0.8,
                          strokeWeight: 2,
                        }}
                      />
                    </React.Fragment>
                  ))}

                  {/* Marcador de ubicación en edición */}
                  {isFormOpen && formData.latitude !== 0 && formData.longitude !== 0 && (
                    <>
                      <Marker
                        position={{ lat: formData.latitude, lng: formData.longitude }}
                        title={formData.name || 'Nueva ubicación'}
                      />
                      <Circle
                        center={{ lat: formData.latitude, lng: formData.longitude }}
                        radius={formData.geofence_radius_m}
                        options={{
                          fillColor: '#10B981',
                          fillOpacity: 0.3,
                          strokeColor: '#10B981',
                          strokeOpacity: 1,
                          strokeWeight: 2,
                        }}
                      />
                    </>
                  )}
                </GoogleMap>
              </LoadScript>
            </div>
          </div>

          {/* Panel lateral */}
          <div className="lg:col-span-1">
            {isFormOpen ? (
              /* Formulario */
              <div className="bg-white rounded-lg shadow">
                <div className="p-4 border-b flex items-center justify-between">
                  <h2 className="font-semibold text-gray-900">
                    {selectedLocation ? 'Editar Ubicación' : 'Nueva Ubicación'}
                  </h2>
                  <button
                    onClick={closeForm}
                    className="p-1 hover:bg-gray-100 rounded"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <form onSubmit={handleSubmit} className="p-4 space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nombre <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Oficina Central Madrid"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Dirección
                    </label>
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      placeholder="Calle Mayor 1, Madrid"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Latitud
                      </label>
                      <input
                        type="number"
                        step="any"
                        value={formData.latitude}
                        onChange={(e) => setFormData({ ...formData, latitude: parseFloat(e.target.value) })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Longitud
                      </label>
                      <input
                        type="number"
                        step="any"
                        value={formData.longitude}
                        onChange={(e) => setFormData({ ...formData, longitude: parseFloat(e.target.value) })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        readOnly
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Radio Geovalla (metros)
                    </label>
                    <input
                      type="range"
                      min="10"
                      max="500"
                      step="10"
                      value={formData.geofence_radius_m}
                      onChange={(e) => setFormData({ ...formData, geofence_radius_m: parseInt(e.target.value) })}
                      className="w-full"
                    />
                    <div className="text-sm text-gray-600 text-center mt-1">
                      {formData.geofence_radius_m} metros
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      IPs Permitidas (una por línea)
                    </label>
                    <textarea
                      value={formData.ip_whitelist}
                      onChange={(e) => setFormData({ ...formData, ip_whitelist: e.target.value })}
                      placeholder="192.168.1.1&#10;10.0.0.1"
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.require_geofence}
                        onChange={(e) => setFormData({ ...formData, require_geofence: e.target.checked })}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700">
                        Requerir geolocalización
                      </span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.require_photo}
                        onChange={(e) => setFormData({ ...formData, require_photo: e.target.checked })}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700">
                        Requerir fotografía
                      </span>
                    </label>
                  </div>

                  <div className="pt-4 flex gap-2">
                    <button
                      type="button"
                      onClick={closeForm}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      disabled={saveMutation.isPending}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                    >
                      <Save className="w-4 h-4" />
                      {saveMutation.isPending ? 'Guardando...' : 'Guardar'}
                    </button>
                  </div>
                </form>
              </div>
            ) : (
              /* Lista de ubicaciones */
              <div className="bg-white rounded-lg shadow">
                <div className="p-4 border-b">
                  <h2 className="font-semibold text-gray-900">Ubicaciones</h2>
                </div>
                <div className="divide-y max-h-[500px] overflow-y-auto">
                  {isLoading ? (
                    <div className="p-4 text-center text-gray-500">
                      Cargando...
                    </div>
                  ) : locations?.length === 0 ? (
                    <div className="p-4 text-center text-gray-500">
                      No hay ubicaciones
                    </div>
                  ) : (
                    locations?.map((location) => (
                      <div key={location.id} className="p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <MapPin className="w-4 h-4 text-blue-600" />
                              <h3 className="font-medium text-gray-900">{location.name}</h3>
                            </div>
                            {location.address && (
                              <p className="text-sm text-gray-500 mt-1">{location.address}</p>
                            )}
                            <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                              <span>Radio: {location.geofence_radius_m}m</span>
                              {location.require_geofence && (
                                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded">Geoloc.</span>
                              )}
                              {location.require_photo && (
                                <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded">Foto</span>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-1 ml-2">
                            <button
                              onClick={() => openForm(location)}
                              className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                              title="Editar"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(location.id, location.name)}
                              className="p-1 text-red-600 hover:bg-red-50 rounded"
                              title="Eliminar"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
