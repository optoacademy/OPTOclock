'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { supabase } from '@/lib/supabase';
import { Users, Clock, AlertCircle, TrendingUp, LogOut } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function AdminDashboard() {
  const { user, role, organizationId, signOut } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState({
    totalEmployees: 0,
    currentlyWorking: 0,
    todayEvents: 0,
    pendingIncidents: 0
  });
  const [recentEvents, setRecentEvents] = useState<any[]>([]);

  useEffect(() => {
    if (!user || !organizationId) {
      router.push('/login');
      return;
    }
    if (role !== 'ORG_ADMIN' && role !== 'MANAGER') {
      router.push('/employee/clock');
      return;
    }
    loadDashboard();
  }, [user, role, organizationId]);

  const loadDashboard = async () => {
    if (!organizationId) return;

    // Total empleados
    const { count: empCount } = await supabase
      .from('employees')
      .select('*', { count: 'exact', head: true })
      .eq('organization_id', organizationId)
      .eq('is_active', true);

    // Eventos de hoy
    const today = new Date().toISOString().split('T')[0];
    const { data: todayEvents } = await supabase
      .from('clock_events')
      .select('*, employees(full_name)')
      .eq('organization_id', organizationId)
      .gte('timestamp_local', `${today}T00:00:00`)
      .order('timestamp_local', { ascending: false })
      .limit(10);

    // Incidencias pendientes
    const { count: incidentCount } = await supabase
      .from('incidents')
      .select('*', { count: 'exact', head: true })
      .eq('organization_id', organizationId)
      .eq('resolved', false);

    // Empleados actualmente trabajando (último evento IN)
    const { data: lastEvents } = await supabase
      .from('clock_events')
      .select('employee_id, type')
      .eq('organization_id', organizationId)
      .gte('timestamp_local', `${today}T00:00:00`)
      .order('timestamp_utc', { ascending: false });

    const currentlyWorking = new Set();
    const processed = new Set();
    
    lastEvents?.forEach(event => {
      if (!processed.has(event.employee_id)) {
        if (event.type === 'IN') {
          currentlyWorking.add(event.employee_id);
        }
        processed.add(event.employee_id);
      }
    });

    setStats({
      totalEmployees: empCount || 0,
      currentlyWorking: currentlyWorking.size,
      todayEvents: todayEvents?.length || 0,
      pendingIncidents: incidentCount || 0
    });

    setRecentEvents(todayEvents || []);
  };

  const handleSignOut = async () => {
    await signOut();
    router.push('/login');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Clock className="w-8 h-8 text-indigo-600 mr-3" />
              <span className="text-xl font-bold text-gray-900">Panel Admin</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">{user?.email}</span>
              <button
                onClick={handleSignOut}
                className="flex items-center text-gray-600 hover:text-gray-900"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Dashboard</h1>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Empleados Activos</p>
                <p className="text-3xl font-bold text-gray-900">{stats.totalEmployees}</p>
              </div>
              <Users className="w-12 h-12 text-blue-500" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Trabajando Ahora</p>
                <p className="text-3xl font-bold text-gray-900">{stats.currentlyWorking}</p>
              </div>
              <TrendingUp className="w-12 h-12 text-green-500" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Fichajes Hoy</p>
                <p className="text-3xl font-bold text-gray-900">{stats.todayEvents}</p>
              </div>
              <Clock className="w-12 h-12 text-indigo-500" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Incidencias Pendientes</p>
                <p className="text-3xl font-bold text-gray-900">{stats.pendingIncidents}</p>
              </div>
              <AlertCircle className="w-12 h-12 text-red-500" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Fichajes Recientes</h2>
          </div>
          <div className="divide-y divide-gray-200">
            {recentEvents.length === 0 ? (
              <p className="px-6 py-4 text-gray-500">No hay fichajes hoy</p>
            ) : (
              recentEvents.map((event) => (
                <div key={event.id} className="px-6 py-4 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900">
                      {event.employees?.full_name || 'Empleado'}
                    </p>
                    <p className="text-sm text-gray-500">
                      {new Date(event.timestamp_local).toLocaleString('es-ES')}
                    </p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    event.type === 'IN' ? 'bg-green-100 text-green-800' :
                    event.type === 'OUT' ? 'bg-red-100 text-red-800' :
                    'bg-blue-100 text-blue-800'
                  }`}>
                    {event.type}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <a href="/admin/employees" className="block p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow">
            <Users className="w-8 h-8 text-indigo-600 mb-2" />
            <h3 className="text-lg font-semibold text-gray-900">Gestionar Empleados</h3>
            <p className="text-sm text-gray-600 mt-2">CRUD de empleados, asignar turnos y ubicaciones</p>
          </a>

          <a href="/admin/reports" className="block p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow">
            <Clock className="w-8 h-8 text-green-600 mb-2" />
            <h3 className="text-lg font-semibold text-gray-900">Reportes</h3>
            <p className="text-sm text-gray-600 mt-2">Asistencia, horas extra, exportación legal</p>
          </a>

          <a href="/admin/settings" className="block p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow">
            <AlertCircle className="w-8 h-8 text-purple-600 mb-2" />
            <h3 className="text-lg font-semibold text-gray-900">Configuración</h3>
            <p className="text-sm text-gray-600 mt-2">Políticas, geofencing, webhooks</p>
          </a>
        </div>
      </div>
    </div>
  );
}
