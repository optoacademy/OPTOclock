'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { format, parseISO, differenceInMinutes } from 'date-fns'
import { es } from 'date-fns/locale'
import { Download, Filter, AlertCircle, Clock, MapPin, Calendar } from 'lucide-react'

type ClockEvent = {
  id: string
  employee_id: string
  event_type: string
  event_timestamp: string
  latitude: number | null
  longitude: number | null
  location_id: string | null
  employee: { full_name: string; external_code: string | null }
  location: { name: string } | null
}

type Incident = {
  id: string
  employee_id: string
  incident_type: string
  incident_timestamp: string
  description: string | null
  employee: { full_name: string; external_code: string | null }
}

type DailyHours = {
  date: string
  employee_id: string
  total_hours: number
  overtime_hours: number
  employee: { full_name: string; external_code: string | null }
}

export default function ReportsPage() {
  const today = new Date().toISOString().split('T')[0]
  const [startDate, setStartDate] = useState(today)
  const [endDate, setEndDate] = useState(today)
  const [selectedEmployee, setSelectedEmployee] = useState<string>('')
  const [selectedLocation, setSelectedLocation] = useState<string>('')
  const [activeTab, setActiveTab] = useState<'attendance' | 'hours' | 'incidents'>('attendance')

  // Obtener empleados
  const { data: employees } = useQuery({
    queryKey: ['employees'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name, external_code')
        .eq('is_active', true)
        .order('full_name')
      if (error) throw error
      return data
    },
  })

  // Obtener ubicaciones
  const { data: locations } = useQuery({
    queryKey: ['locations'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('locations')
        .select('id, name')
        .order('name')
      if (error) throw error
      return data
    },
  })

  // Obtener eventos de fichaje
  const { data: clockEvents, isLoading: loadingEvents } = useQuery({
    queryKey: ['clock-events', startDate, endDate, selectedEmployee, selectedLocation],
    queryFn: async () => {
      let query = supabase
        .from('clock_events')
        .select(`
          *,
          employee:employees!employee_id(full_name, external_code),
          location:locations!location_id(name)
        `)
        .gte('event_timestamp', `${startDate}T00:00:00`)
        .lte('event_timestamp', `${endDate}T23:59:59`)
        .order('event_timestamp', { ascending: false })

      if (selectedEmployee) {
        query = query.eq('employee_id', selectedEmployee)
      }
      if (selectedLocation) {
        query = query.eq('location_id', selectedLocation)
      }

      const { data, error } = await query
      if (error) throw error
      return data as ClockEvent[]
    },
    enabled: activeTab === 'attendance',
  })

  // Obtener resumen de horas
  const { data: dailyHours, isLoading: loadingHours } = useQuery({
    queryKey: ['daily-hours', startDate, endDate, selectedEmployee],
    queryFn: async () => {
      let query = supabase
        .from('daily_hours_summary')
        .select(`
          *,
          employee:employees!employee_id(full_name, external_code)
        `)
        .gte('date', startDate)
        .lte('date', endDate)
        .order('date', { ascending: false })

      if (selectedEmployee) {
        query = query.eq('employee_id', selectedEmployee)
      }

      const { data, error } = await query
      if (error) throw error
      return data as DailyHours[]
    },
    enabled: activeTab === 'hours',
  })

  // Obtener incidencias
  const { data: incidents, isLoading: loadingIncidents } = useQuery({
    queryKey: ['incidents', startDate, endDate, selectedEmployee],
    queryFn: async () => {
      let query = supabase
        .from('incidents')
        .select(`
          *,
          employee:employees!employee_id(full_name, external_code)
        `)
        .gte('incident_timestamp', `${startDate}T00:00:00`)
        .lte('incident_timestamp', `${endDate}T23:59:59`)
        .order('incident_timestamp', { ascending: false })

      if (selectedEmployee) {
        query = query.eq('employee_id', selectedEmployee)
      }

      const { data, error } = await query
      if (error) throw error
      return data as Incident[]
    },
    enabled: activeTab === 'incidents',
  })

  const exportToCSV = () => {
    let csvContent = ''
    let filename = ''

    if (activeTab === 'attendance' && clockEvents) {
      filename = `asistencia_${startDate}_${endDate}.csv`
      csvContent = 'Empleado,Código,Fecha/Hora,Tipo,Ubicación,Latitud,Longitud\n'
      clockEvents.forEach(event => {
        const row = [
          event.employee.full_name,
          event.employee.external_code || '',
          format(parseISO(event.event_timestamp), 'dd/MM/yyyy HH:mm:ss', { locale: es }),
          event.event_type,
          event.location?.name || '',
          event.latitude || '',
          event.longitude || '',
        ].join(',')
        csvContent += row + '\n'
      })
    } else if (activeTab === 'hours' && dailyHours) {
      filename = `horas_${startDate}_${endDate}.csv`
      csvContent = 'Empleado,Código,Fecha,Horas Totales,Horas Extra\n'
      dailyHours.forEach(day => {
        const row = [
          day.employee.full_name,
          day.employee.external_code || '',
          format(parseISO(day.date), 'dd/MM/yyyy', { locale: es }),
          day.total_hours.toFixed(2),
          day.overtime_hours.toFixed(2),
        ].join(',')
        csvContent += row + '\n'
      })
    } else if (activeTab === 'incidents' && incidents) {
      filename = `incidencias_${startDate}_${endDate}.csv`
      csvContent = 'Empleado,Código,Fecha/Hora,Tipo,Descripción\n'
      incidents.forEach(incident => {
        const row = [
          incident.employee.full_name,
          incident.employee.external_code || '',
          format(parseISO(incident.incident_timestamp), 'dd/MM/yyyy HH:mm:ss', { locale: es }),
          incident.incident_type,
          incident.description || '',
        ].join(',')
        csvContent += row + '\n'
      })
    }

    // Descargar archivo
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = filename
    link.click()
  }

  const exportOfficialReport = async () => {
    try {
      const response = await fetch(
        'https://cfzlqrwezvasadjfjudd.supabase.co/functions/v1/export-report',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            startDate,
            endDate,
            employeeId: selectedEmployee || undefined,
            format: 'csv',
          }),
        }
      )

      if (!response.ok) {
        throw new Error('Error al generar reporte oficial')
      }

      const data = await response.json()
      
      // Descargar el archivo
      const blob = new Blob([data.data], { type: 'text/csv' })
      const link = document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = `reporte_oficial_${startDate}_${endDate}.csv`
      link.click()

      alert(`Reporte generado con hash: ${data.hash}`)
    } catch (error) {
      console.error('Error:', error)
      alert('Error al generar el reporte oficial')
    }
  }

  const getIncidentColor = (type: string) => {
    switch (type) {
      case 'LATE_ARRIVAL': return 'bg-yellow-100 text-yellow-800'
      case 'OUTSIDE_GEOFENCE': return 'bg-orange-100 text-orange-800'
      case 'REST_VIOLATION': return 'bg-red-100 text-red-800'
      case 'MISSING_OUT': return 'bg-purple-100 text-purple-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getIncidentLabel = (type: string) => {
    const labels: Record<string, string> = {
      'LATE_ARRIVAL': 'Llegada tarde',
      'OUTSIDE_GEOFENCE': 'Fuera de geovalla',
      'REST_VIOLATION': 'Violación descanso UE',
      'MISSING_OUT': 'Sin salida',
    }
    return labels[type] || type
  }

  const isLoading = loadingEvents || loadingHours || loadingIncidents

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Reportes</h1>
              <p className="mt-1 text-sm text-gray-500">
                Genera y exporta reportes de asistencia, horas e incidencias
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={exportToCSV}
                className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <Download className="w-4 h-4" />
                Exportar CSV
              </button>
              <button
                onClick={exportOfficialReport}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Download className="w-4 h-4" />
                Reporte Oficial Firmado
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Filtros */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="w-5 h-5 text-gray-400" />
            <h2 className="font-semibold text-gray-900">Filtros</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fecha Inicio
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fecha Fin
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Empleado
              </label>
              <select
                value={selectedEmployee}
                onChange={(e) => setSelectedEmployee(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Todos los empleados</option>
                {employees?.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.full_name} {emp.external_code ? `(${emp.external_code})` : ''}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Ubicación
              </label>
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={activeTab !== 'attendance'}
              >
                <option value="">Todas las ubicaciones</option>
                {locations?.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow mb-6">
          <div className="border-b">
            <nav className="flex -mb-px">
              <button
                onClick={() => setActiveTab('attendance')}
                className={`px-6 py-3 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === 'attendance'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Asistencia
                </div>
              </button>
              <button
                onClick={() => setActiveTab('hours')}
                className={`px-6 py-3 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === 'hours'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Horas Trabajadas
                </div>
              </button>
              <button
                onClick={() => setActiveTab('incidents')}
                className={`px-6 py-3 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === 'incidents'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  Incidencias
                </div>
              </button>
            </nav>
          </div>

          <div className="p-6">
            {isLoading ? (
              <div className="text-center py-8 text-gray-500">Cargando datos...</div>
            ) : (
              <>
                {/* Tabla de Asistencia */}
                {activeTab === 'attendance' && (
                  <div className="overflow-x-auto">
                    {clockEvents && clockEvents.length > 0 ? (
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Empleado
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Fecha/Hora
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Tipo
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Ubicación
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Coordenadas
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {clockEvents.map((event) => (
                            <tr key={event.id} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                {event.employee.full_name}
                                {event.employee.external_code && (
                                  <span className="ml-2 text-gray-500">({event.employee.external_code})</span>
                                )}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {format(parseISO(event.event_timestamp), 'dd/MM/yyyy HH:mm:ss', { locale: es })}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`px-2 py-1 text-xs font-medium rounded ${
                                  event.event_type === 'IN' ? 'bg-green-100 text-green-800' :
                                  event.event_type === 'OUT' ? 'bg-red-100 text-red-800' :
                                  'bg-blue-100 text-blue-800'
                                }`}>
                                  {event.event_type}
                                </span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {event.location?.name || '-'}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {event.latitude && event.longitude
                                  ? `${event.latitude.toFixed(6)}, ${event.longitude.toFixed(6)}`
                                  : '-'}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        No hay eventos de fichaje en el rango seleccionado
                      </div>
                    )}
                  </div>
                )}

                {/* Tabla de Horas */}
                {activeTab === 'hours' && (
                  <div className="overflow-x-auto">
                    {dailyHours && dailyHours.length > 0 ? (
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Empleado
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Fecha
                            </th>
                            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                              Horas Totales
                            </th>
                            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                              Horas Extra
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {dailyHours.map((day, idx) => (
                            <tr key={idx} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                {day.employee.full_name}
                                {day.employee.external_code && (
                                  <span className="ml-2 text-gray-500">({day.employee.external_code})</span>
                                )}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {format(parseISO(day.date), 'dd/MM/yyyy', { locale: es })}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-medium">
                                {day.total_hours.toFixed(2)}h
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-right">
                                {day.overtime_hours > 0 ? (
                                  <span className="text-orange-600 font-medium">
                                    +{day.overtime_hours.toFixed(2)}h
                                  </span>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        No hay datos de horas en el rango seleccionado
                      </div>
                    )}
                  </div>
                )}

                {/* Tabla de Incidencias */}
                {activeTab === 'incidents' && (
                  <div className="overflow-x-auto">
                    {incidents && incidents.length > 0 ? (
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Empleado
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Fecha/Hora
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Tipo
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                              Descripción
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {incidents.map((incident) => (
                            <tr key={incident.id} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                {incident.employee.full_name}
                                {incident.employee.external_code && (
                                  <span className="ml-2 text-gray-500">({incident.employee.external_code})</span>
                                )}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {format(parseISO(incident.incident_timestamp), 'dd/MM/yyyy HH:mm:ss', { locale: es })}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`px-2 py-1 text-xs font-medium rounded ${getIncidentColor(incident.incident_type)}`}>
                                  {getIncidentLabel(incident.incident_type)}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-sm text-gray-500">
                                {incident.description || '-'}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        No hay incidencias en el rango seleccionado
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
