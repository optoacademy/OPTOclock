'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { useQuery, useMutation } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { supabase } from '@/lib/supabase'
import { ArrowLeft, Save, RefreshCw } from 'lucide-react'

// Schema de validación
const employeeSchema = z.object({
  external_code: z.string().optional(),
  full_name: z.string().min(2, 'El nombre debe tener al menos 2 caracteres'),
  email: z.string().email('Email inválido').optional().or(z.literal('')),
  phone: z.string().optional(),
  default_location_id: z.string().optional(),
  default_shift_id: z.string().optional(),
  hire_date: z.string().optional(),
  pin: z.string().length(4, 'El PIN debe tener 4 dígitos').regex(/^\d+$/, 'El PIN debe contener solo números'),
  is_active: z.boolean(),
})

type EmployeeForm = z.infer<typeof employeeSchema>

export default function EmployeeFormPage() {
  const router = useRouter()
  const params = useParams()
  const employeeId = params?.id as string | undefined
  const isEditing = !!employeeId

  const [pinGenerated, setPinGenerated] = useState(false)

  // Obtener ubicaciones
  const { data: locations } = useQuery({
    queryKey: ['locations'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('locations')
        .select('id, name')
        .order('name')
      if (error) throw error
      return data
    },
  })

  // Obtener turnos
  const { data: shifts } = useQuery({
    queryKey: ['shifts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('work_shifts')
        .select('id, name')
        .order('name')
      if (error) throw error
      return data
    },
  })

  // Obtener empleado si está editando
  const { data: employee, isLoading } = useQuery({
    queryKey: ['employee', employeeId],
    queryFn: async () => {
      if (!employeeId) return null
      const { data, error } = await supabase
        .from('employees')
        .select('*')
        .eq('id', employeeId)
        .single()
      if (error) throw error
      return data
    },
    enabled: isEditing,
  })

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<EmployeeForm>({
    resolver: zodResolver(employeeSchema),
    defaultValues: {
      is_active: true,
      pin: '',
    },
  })

  // Cargar datos del empleado al editar
  useEffect(() => {
    if (employee && isEditing) {
      setValue('external_code', employee.external_code || '')
      setValue('full_name', employee.full_name)
      setValue('email', employee.email || '')
      setValue('phone', employee.phone || '')
      setValue('default_location_id', employee.default_location_id || '')
      setValue('default_shift_id', employee.default_shift_id || '')
      setValue('hire_date', employee.hire_date || '')
      setValue('is_active', employee.is_active)
      // No cargamos el PIN por seguridad
    }
  }, [employee, isEditing, setValue])

  // Guardar empleado
  const saveMutation = useMutation({
    mutationFn: async (data: EmployeeForm) => {
      const employeeData: any = {
        external_code: data.external_code || null,
        full_name: data.full_name,
        email: data.email || null,
        phone: data.phone || null,
        default_location_id: data.default_location_id || null,
        default_shift_id: data.default_shift_id || null,
        hire_date: data.hire_date || null,
        is_active: data.is_active,
      }

      // Solo agregar PIN si se proporcionó uno nuevo
      if (data.pin) {
        // Hashear el PIN usando pgcrypto en el servidor
        employeeData.pin_hash = data.pin // Se hasheará en el trigger de la BD
      }

      if (isEditing && employeeId) {
        const { error } = await supabase
          .from('employees')
          .update(employeeData)
          .eq('id', employeeId)
        if (error) throw error
      } else {
        const { error } = await supabase
          .from('employees')
          .insert(employeeData)
        if (error) throw error
      }
    },
    onSuccess: () => {
      alert(isEditing ? 'Empleado actualizado correctamente' : 'Empleado creado correctamente')
      router.push('/admin/employees')
    },
    onError: (error) => {
      console.error('Error al guardar:', error)
      alert('Error al guardar el empleado')
    },
  })

  const onSubmit = (data: EmployeeForm) => {
    saveMutation.mutate(data)
  }

  const generatePin = () => {
    const pin = Math.floor(1000 + Math.random() * 9000).toString()
    setValue('pin', pin)
    setPinGenerated(true)
    setTimeout(() => setPinGenerated(false), 2000)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-500">Cargando...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.back()}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {isEditing ? 'Editar Empleado' : 'Nuevo Empleado'}
              </h1>
              <p className="mt-1 text-sm text-gray-500">
                {isEditing ? 'Modifica los datos del empleado' : 'Completa el formulario para crear un nuevo empleado'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Formulario */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <form onSubmit={handleSubmit(onSubmit)} className="bg-white rounded-lg shadow">
          <div className="p-6 space-y-6">
            {/* Información básica */}
            <div>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Información Básica</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Código Externo
                  </label>
                  <input
                    {...register('external_code')}
                    type="text"
                    placeholder="EMP-001"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  {errors.external_code && (
                    <p className="mt-1 text-sm text-red-600">{errors.external_code.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nombre Completo <span className="text-red-500">*</span>
                  </label>
                  <input
                    {...register('full_name')}
                    type="text"
                    placeholder="Juan Pérez García"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  {errors.full_name && (
                    <p className="mt-1 text-sm text-red-600">{errors.full_name.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    {...register('email')}
                    type="email"
                    placeholder="juan.perez@example.com"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  {errors.email && (
                    <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Teléfono
                  </label>
                  <input
                    {...register('phone')}
                    type="tel"
                    placeholder="+34 600 000 000"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  {errors.phone && (
                    <p className="mt-1 text-sm text-red-600">{errors.phone.message}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Configuración de trabajo */}
            <div>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Configuración de Trabajo</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Ubicación por Defecto
                  </label>
                  <select
                    {...register('default_location_id')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Sin ubicación asignada</option>
                    {locations?.map((loc) => (
                      <option key={loc.id} value={loc.id}>
                        {loc.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Turno por Defecto
                  </label>
                  <select
                    {...register('default_shift_id')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Sin turno asignado</option>
                    {shifts?.map((shift) => (
                      <option key={shift.id} value={shift.id}>
                        {shift.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Fecha de Contratación
                  </label>
                  <input
                    {...register('hire_date')}
                    type="date"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="flex items-center">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      {...register('is_active')}
                      type="checkbox"
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span className="text-sm font-medium text-gray-700">
                      Empleado activo
                    </span>
                  </label>
                </div>
              </div>
            </div>

            {/* PIN */}
            <div>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">PIN de Acceso</h2>
              <div className="max-w-md">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  PIN (4 dígitos) <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    {...register('pin')}
                    type="text"
                    placeholder="1234"
                    maxLength={4}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-lg"
                  />
                  <button
                    type="button"
                    onClick={generatePin}
                    className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                    title="Generar PIN aleatorio"
                  >
                    <RefreshCw className={`w-4 h-4 ${pinGenerated ? 'text-green-600' : ''}`} />
                    Generar
                  </button>
                </div>
                {errors.pin && (
                  <p className="mt-1 text-sm text-red-600">{errors.pin.message}</p>
                )}
                <p className="mt-1 text-xs text-gray-500">
                  {isEditing ? 'Deja vacío para mantener el PIN actual' : 'PIN para acceso al modo kiosko'}
                </p>
              </div>
            </div>
          </div>

          {/* Acciones */}
          <div className="px-6 py-4 bg-gray-50 border-t flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => router.back()}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saveMutation.isPending}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="w-4 h-4" />
              {saveMutation.isPending ? 'Guardando...' : isEditing ? 'Actualizar' : 'Crear Empleado'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
