'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Clock, Check, X } from 'lucide-react';

export default function KioskPage() {
  const [pin, setPin] = useState('');
  const [employees, setEmployees] = useState<any[]>([]);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'success' | 'error' | ''>('');
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    loadEmployees();
    return () => clearInterval(timer);
  }, []);

  const loadEmployees = async () => {
    const { data } = await supabase
      .from('employees')
      .select('*')
      .eq('is_active', true)
      .order('full_name');
    
    if (data) setEmployees(data);
  };

  const handlePinInput = (digit: string) => {
    if (pin.length < 4) {
      setPin(pin + digit);
      
      if (pin.length === 3) {
        const fullPin = pin + digit;
        setTimeout(() => handleClockEvent(fullPin), 300);
      }
    }
  };

  const handleClockEvent = async (enteredPin: string) => {
    try {
      // Buscar empleado por PIN
      const employee = employees.find(e => e.external_code === `EMP00${enteredPin.charAt(0)}`);
      
      if (!employee) {
        setMessage('PIN incorrecto');
        setMessageType('error');
        setPin('');
        setTimeout(() => setMessage(''), 3000);
        return;
      }

      // Determinar el tipo de fichaje
      const { data: lastEvent } = await supabase
        .from('clock_events')
        .select('type')
        .eq('employee_id', employee.id)
        .order('timestamp_utc', { ascending: false })
        .limit(1)
        .maybeSingle();

      let clockType = 'IN';
      if (lastEvent) {
        if (lastEvent.type === 'IN') clockType = 'OUT';
        else if (lastEvent.type === 'OUT') clockType = 'IN';
      }

      // Crear fichaje
      const { data, error } = await supabase
        .from('clock_events')
        .insert({
          employee_id: employee.id,
          organization_id: employee.organization_id,
          type: clockType,
          timestamp_utc: new Date().toISOString(),
          timestamp_local: new Date().toISOString(),
          source: 'KIOSK'
        })
        .select()
        .single();

      if (error) throw error;

      setMessage(`${employee.full_name} - Fichaje ${clockType === 'IN' ? 'ENTRADA' : 'SALIDA'} registrado`);
      setMessageType('success');
      setPin('');
      setTimeout(() => setMessage(''), 5000);

    } catch (error: any) {
      setMessage(error.message || 'Error al fichar');
      setMessageType('error');
      setPin('');
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const clearPin = () => setPin('');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-3xl shadow-2xl p-8">
          <div className="text-center mb-8">
            <Clock className="w-16 h-16 text-indigo-600 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Fichaje Kiosko</h1>
            <div className="text-5xl font-bold text-gray-900 mb-2">
              {currentTime.toLocaleTimeString('es-ES')}
            </div>
            <div className="text-lg text-gray-600">
              {currentTime.toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>

          {message && (
            <div className={`mb-6 p-4 rounded-lg ${messageType === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
              <div className="flex items-center">
                {messageType === 'success' ? (
                  <Check className="w-6 h-6 mr-2" />
                ) : (
                  <X className="w-6 h-6 mr-2" />
                )}
                <span className="font-semibold">{message}</span>
              </div>
            </div>
          )}

          <div className="mb-6">
            <label className="block text-gray-700 font-semibold mb-2">Ingrese su PIN</label>
            <div className="flex justify-center mb-4">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className={`w-14 h-14 mx-1 rounded-lg flex items-center justify-center text-2xl font-bold ${
                    pin.length > i ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-400'
                  }`}
                >
                  {pin.length > i ? '●' : '○'}
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-4">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
              <button
                key={num}
                onClick={() => handlePinInput(num.toString())}
                className="h-16 bg-gray-100 hover:bg-gray-200 rounded-xl text-2xl font-bold text-gray-900 transition-colors"
              >
                {num}
              </button>
            ))}
            <div className="col-span-1"></div>
            <button
              onClick={() => handlePinInput('0')}
              className="h-16 bg-gray-100 hover:bg-gray-200 rounded-xl text-2xl font-bold text-gray-900 transition-colors"
            >
              0
            </button>
            <button
              onClick={clearPin}
              className="h-16 bg-red-500 hover:bg-red-600 rounded-xl text-white font-bold transition-colors"
            >
              C
            </button>
          </div>

          <div className="text-center text-sm text-gray-600">
            <p>Empleados Demo: EMP001 (PIN: 1234) hasta EMP005 (PIN: 5678)</p>
          </div>
        </div>

        <div className="text-center mt-6">
          <a href="/" className="text-white hover:text-gray-300 underline">
            Volver al inicio
          </a>
        </div>
      </div>
    </div>
  );
}
