'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Clock, Users, Building2, MapPin } from 'lucide-react';

export default function HomePage() {
  const [stats, setStats] = useState({
    totalEmployees: 0,
    activeToday: 0,
    totalLocations: 0
  });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      // Obtener total de empleados
      const { count: empCount } = await supabase
        .from('employees')
        .select('*', { count: 'exact', head: true })
        .eq('is_active', true);

      // Obtener total de ubicaciones
      const { count: locCount } = await supabase
        .from('locations')
        .select('*', { count: 'exact', head: true })
        .eq('is_active', true);

      // Obtener fichajes de hoy
      const today = new Date().toISOString().split('T')[0];
      const { data: todayEvents } = await supabase
        .from('clock_events')
        .select('employee_id')
        .gte('timestamp_local', `${today}T00:00:00`)
        .lte('timestamp_local', `${today}T23:59:59`);

      const uniqueEmployees = new Set(todayEvents?.map(e => e.employee_id) || []);

      setStats({
        totalEmployees: empCount || 0,
        activeToday: uniqueEmployees.size,
        totalLocations: locCount || 0
      });
    } catch (error) {
      console.error('Error cargando estadísticas:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-12">
        <header className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Clock className="w-16 h-16 text-indigo-600" />
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Sistema de Fichaje de Empleados
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Solución profesional de gestión de tiempo multi-empresa con cumplimiento legal UE/España
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <Users className="w-12 h-12 text-blue-600 mx-auto mb-4" />
            <div className="text-4xl font-bold text-gray-900 mb-2">{stats.totalEmployees}</div>
            <div className="text-gray-600">Empleados Activos</div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <Clock className="w-12 h-12 text-green-600 mx-auto mb-4" />
            <div className="text-4xl font-bold text-gray-900 mb-2">{stats.activeToday}</div>
            <div className="text-gray-600">Fichajes Hoy</div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <MapPin className="w-12 h-12 text-purple-600 mx-auto mb-4" />
            <div className="text-4xl font-bold text-gray-900 mb-2">{stats.totalLocations}</div>
            <div className="text-gray-600">Ubicaciones</div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Accesos Rápidos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <a
              href="/employee/dashboard"
              className="block p-6 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition-colors"
            >
              <div className="flex items-center">
                <Users className="w-8 h-8 mr-4" />
                <div>
                  <div className="font-semibold text-lg">Portal Empleado</div>
                  <div className="text-indigo-200 text-sm">Fichar entrada/salida</div>
                </div>
              </div>
            </a>

            <a
              href="/kiosk"
              className="block p-6 bg-green-600 hover:bg-green-700 text-white rounded-xl transition-colors"
            >
              <div className="flex items-center">
                <Clock className="w-8 h-8 mr-4" />
                <div>
                  <div className="font-semibold text-lg">Modo Kiosko</div>
                  <div className="text-green-200 text-sm">Fichaje con PIN</div>
                </div>
              </div>
            </a>

            <a
              href="/admin/dashboard"
              className="block p-6 bg-purple-600 hover:bg-purple-700 text-white rounded-xl transition-colors"
            >
              <div className="flex items-center">
                <Building2 className="w-8 h-8 mr-4" />
                <div>
                  <div className="font-semibold text-lg">Panel Admin</div>
                  <div className="text-purple-200 text-sm">Gestión completa</div>
                </div>
              </div>
            </a>

            <div className="block p-6 bg-gray-100 rounded-xl">
              <div className="flex items-center">
                <MapPin className="w-8 h-8 mr-4 text-gray-600" />
                <div>
                  <div className="font-semibold text-lg text-gray-900">Documentación</div>
                  <div className="text-gray-600 text-sm">Guías y ayuda</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Funcionalidades Principales</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-start">
              <div className="bg-indigo-100 rounded-lg p-3 mr-4">
                <Clock className="w-6 h-6 text-indigo-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Fichaje Multi-Canal</h3>
                <p className="text-gray-600 text-sm">Web, móvil, kiosko y API</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="bg-green-100 rounded-lg p-3 mr-4">
                <MapPin className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Geofencing</h3>
                <p className="text-gray-600 text-sm">Validación por ubicación GPS</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="bg-purple-100 rounded-lg p-3 mr-4">
                <Building2 className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Multi-Empresa</h3>
                <p className="text-gray-600 text-sm">Aislamiento total de datos</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="bg-blue-100 rounded-lg p-3 mr-4">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Cumplimiento Legal</h3>
                <p className="text-gray-600 text-sm">Normativa UE y España</p>
              </div>
            </div>
          </div>
        </div>

        <footer className="text-center mt-12 text-gray-600">
          <p>Sistema de Fichaje de Empleados v1.0 - Cumplimiento GDPR</p>
          <p className="text-sm mt-2">
            Usuarios demo: Organización: TechCorp España S.L. | Empleados: EMP001-EMP005 (PIN: 1234-5678)
          </p>
        </footer>
      </div>
    </div>
  );
}
