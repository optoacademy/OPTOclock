'use client'

import { useEffect, useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { format, startOfMonth, endOfMonth } from 'date-fns'
import { es } from 'date-fns/locale'
import { Clock, Calendar, TrendingUp, AlertCircle } from 'lucide-react'

export default function EmployeeDashboard() {
  const { user } = useAuth()
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  // Obtener datos del empleado
  const { data: employee } = useQuery({
    queryKey: ['employee-profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null
      const { data, error } = await supabase
        .from('employees')
        .select('*, location:locations(name), shift:work_shifts(name)')
        .eq('user_id', user.id)
        .single()
      if (error) throw error
      return data
    },
    enabled: !!user?.id,
  })

  // Último evento de fichaje
  const { data: lastEvent } = useQuery({
    queryKey: ['last-clock-event', employee?.id],
    queryFn: async () => {
      if (!employee?.id) return null
      const { data, error } = await supabase
        .from('clock_events')
        .select('*')
        .eq('employee_id', employee.id)
        .order('event_timestamp', { ascending: false })
        .limit(1)
        .maybeSingle()
      if (error) throw error
      return data
    },
    enabled: !!employee?.id,
  })

  // Estadísticas del mes actual
  const { data: monthStats } = useQuery({
    queryKey: ['month-stats', employee?.id],
    queryFn: async () => {
      if (!employee?.id) return null
      const start = format(startOfMonth(new Date()), 'yyyy-MM-dd')
      const end = format(endOfMonth(new Date()), 'yyyy-MM-dd')

      const { data, error } = await supabase
        .from('daily_hours_summary')
        .select('*')
        .eq('employee_id', employee.id)
        .gte('date', start)
        .lte('date', end)

      if (error) throw error

      const totalHours = data?.reduce((sum, day) => sum + (day.total_hours || 0), 0) || 0
      const overtimeHours = data?.reduce((sum, day) => sum + (day.overtime_hours || 0), 0) || 0
      const daysWorked = data?.length || 0

      return { totalHours, overtimeHours, daysWorked }
    },
    enabled: !!employee?.id,
  })

  // Incidencias recientes
  const { data: recentIncidents } = useQuery({
    queryKey: ['recent-incidents', employee?.id],
    queryFn: async () => {
      if (!employee?.id) return []
      const { data, error } = await supabase
        .from('incidents')
        .select('*')
        .eq('employee_id', employee.id)
        .order('incident_timestamp', { ascending: false })
        .limit(5)
      if (error) throw error
      return data || []
    },
    enabled: !!employee?.id,
  })

  const getStatusBadge = () => {
    if (!lastEvent) return { text: 'Sin fichajes', color: 'bg-gray-100 text-gray-800' }
    if (lastEvent.event_type === 'IN') return { text: 'Trabajando', color: 'bg-green-100 text-green-800' }
    if (lastEvent.event_type === 'OUT') return { text: 'Fuera', color: 'bg-red-100 text-red-800' }
    return { text: 'En descanso', color: 'bg-blue-100 text-blue-800' }
  }

  const status = getStatusBadge()

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900">
              ¡Hola, {employee?.full_name || 'Empleado'}!
            </h1>
            <p className="mt-2 text-lg text-gray-600">
              {format(currentTime, "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })}
            </p>
            <p className="mt-1 text-4xl font-bold text-blue-600">
              {format(currentTime, 'HH:mm:ss')}
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Estado actual */}
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Estado Actual</h2>
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${status.color}`}>
              {status.text}
            </span>
          </div>
          {lastEvent && (
            <div className="text-sm text-gray-600">
              <p>Último fichaje: <span className="font-medium">{lastEvent.event_type}</span></p>
              <p className="mt-1">
                {format(new Date(lastEvent.event_timestamp), "dd/MM/yyyy 'a las' HH:mm:ss", { locale: es })}
              </p>
            </div>
          )}
          {employee?.location && (
            <p className="mt-3 text-sm text-gray-600">
              Ubicación asignada: <span className="font-medium">{employee.location.name}</span>
            </p>
          )}
        </div>

        {/* Estadísticas del mes */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center gap-3 mb-2">
              <Clock className="w-8 h-8 text-blue-600" />
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {monthStats?.totalHours.toFixed(1) || 0}h
                </div>
                <div className="text-sm text-gray-600">Horas totales</div>
              </div>
            </div>
            <div className="text-xs text-gray-500 mt-2">Este mes</div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-8 h-8 text-green-600" />
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {monthStats?.overtimeHours.toFixed(1) || 0}h
                </div>
                <div className="text-sm text-gray-600">Horas extra</div>
              </div>
            </div>
            <div className="text-xs text-gray-500 mt-2">Este mes</div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center gap-3 mb-2">
              <Calendar className="w-8 h-8 text-purple-600" />
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {monthStats?.daysWorked || 0}
                </div>
                <div className="text-sm text-gray-600">Días trabajados</div>
              </div>
            </div>
            <div className="text-xs text-gray-500 mt-2">Este mes</div>
          </div>
        </div>

        {/* Incidencias recientes */}
        {recentIncidents && recentIncidents.length > 0 && (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-600" />
                <h2 className="text-lg font-semibold text-gray-900">Incidencias Recientes</h2>
              </div>
            </div>
            <div className="divide-y">
              {recentIncidents.map((incident) => (
                <div key={incident.id} className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className={`inline-block px-2 py-1 text-xs font-medium rounded ${
                        incident.incident_type === 'LATE_ARRIVAL' ? 'bg-yellow-100 text-yellow-800' :
                        incident.incident_type === 'OUTSIDE_GEOFENCE' ? 'bg-orange-100 text-orange-800' :
                        incident.incident_type === 'REST_VIOLATION' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {incident.incident_type === 'LATE_ARRIVAL' ? 'Llegada tarde' :
                         incident.incident_type === 'OUTSIDE_GEOFENCE' ? 'Fuera de geovalla' :
                         incident.incident_type === 'REST_VIOLATION' ? 'Violación descanso' :
                         incident.incident_type}
                      </span>
                      <p className="mt-1 text-sm text-gray-600">{incident.description}</p>
                    </div>
                    <span className="text-xs text-gray-500">
                      {format(new Date(incident.incident_timestamp), 'dd/MM/yy', { locale: es })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Accesos rápidos */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <a
            href="/employee/clock"
            className="block p-6 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-lg shadow transition-colors"
          >
            <Clock className="w-10 h-10 mb-3" />
            <h3 className="text-xl font-semibold mb-1">Fichar Ahora</h3>
            <p className="text-blue-100 text-sm">Registra tu entrada o salida</p>
          </a>

          <a
            href="/employee/history"
            className="block p-6 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white rounded-lg shadow transition-colors"
          >
            <Calendar className="w-10 h-10 mb-3" />
            <h3 className="text-xl font-semibold mb-1">Ver Historial</h3>
            <p className="text-green-100 text-sm">Consulta tus fichajes anteriores</p>
          </a>
        </div>
      </div>
    </div>
  )
}
