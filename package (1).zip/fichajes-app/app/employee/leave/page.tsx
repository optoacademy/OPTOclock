'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { supabase } from '@/lib/supabase'
import { format, parseISO } from 'date-fns'
import { es } from 'date-fns/locale'
import { Calendar, Plus, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react'

const leaveSchema = z.object({
  leave_type: z.enum(['VACATION', 'SICK', 'PERSONAL', 'OTHER']),
  start_date: z.string().min(1, 'Fecha de inicio requerida'),
  end_date: z.string().min(1, 'Fecha de fin requerida'),
  reason: z.string().min(10, 'La razón debe tener al menos 10 caracteres'),
})

type LeaveForm = z.infer<typeof leaveSchema>

export default function LeavePage() {
  const { user } = useAuth()
  const queryClient = useQueryClient()
  const [isFormOpen, setIsFormOpen] = useState(false)

  // Obtener datos del empleado
  const { data: employee } = useQuery({
    queryKey: ['employee-profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null
      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name')
        .eq('user_id', user.id)
        .single()
      if (error) throw error
      return data
    },
    enabled: !!user?.id,
  })

  // Obtener solicitudes de ausencia
  const { data: leaveRequests, isLoading } = useQuery({
    queryKey: ['leave-requests', employee?.id],
    queryFn: async () => {
      if (!employee?.id) return []
      const { data, error } = await supabase
        .from('leave_requests')
        .select('*')
        .eq('employee_id', employee.id)
        .order('created_at', { ascending: false })
      if (error) throw error
      return data
    },
    enabled: !!employee?.id,
  })

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<LeaveForm>({
    resolver: zodResolver(leaveSchema),
  })

  // Crear solicitud
  const createMutation = useMutation({
    mutationFn: async (data: LeaveForm) => {
      if (!employee?.id) throw new Error('No se encontró el empleado')
      
      const { error } = await supabase
        .from('leave_requests')
        .insert({
          employee_id: employee.id,
          leave_type: data.leave_type,
          start_date: data.start_date,
          end_date: data.end_date,
          reason: data.reason,
          status: 'PENDING',
        })
      
      if (error) throw error
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leave-requests'] })
      alert('Solicitud enviada correctamente')
      setIsFormOpen(false)
      reset()
    },
    onError: (error) => {
      console.error('Error:', error)
      alert('Error al enviar la solicitud')
    },
  })

  const onSubmit = (data: LeaveForm) => {
    createMutation.mutate(data)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'PENDING':
        return { text: 'Pendiente', color: 'bg-yellow-100 text-yellow-800', icon: Clock }
      case 'APPROVED':
        return { text: 'Aprobada', color: 'bg-green-100 text-green-800', icon: CheckCircle }
      case 'REJECTED':
        return { text: 'Rechazada', color: 'bg-red-100 text-red-800', icon: XCircle }
      default:
        return { text: status, color: 'bg-gray-100 text-gray-800', icon: AlertCircle }
    }
  }

  const getLeaveTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      'VACATION': 'Vacaciones',
      'SICK': 'Enfermedad',
      'PERSONAL': 'Personal',
      'OTHER': 'Otro',
    }
    return labels[type] || type
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Ausencias</h1>
              <p className="mt-1 text-sm text-gray-500">
                Solicita y gestiona tus días de ausencia
              </p>
            </div>
            <button
              onClick={() => setIsFormOpen(!isFormOpen)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Nueva Solicitud
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Formulario */}
        {isFormOpen && (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b">
              <h2 className="font-semibold text-gray-900">Nueva Solicitud de Ausencia</h2>
            </div>
            <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tipo de Ausencia <span className="text-red-500">*</span>
                </label>
                <select
                  {...register('leave_type')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Selecciona un tipo</option>
                  <option value="VACATION">Vacaciones</option>
                  <option value="SICK">Enfermedad</option>
                  <option value="PERSONAL">Personal</option>
                  <option value="OTHER">Otro</option>
                </select>
                {errors.leave_type && (
                  <p className="mt-1 text-sm text-red-600">{errors.leave_type.message}</p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Fecha Inicio <span className="text-red-500">*</span>
                  </label>
                  <input
                    {...register('start_date')}
                    type="date"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  {errors.start_date && (
                    <p className="mt-1 text-sm text-red-600">{errors.start_date.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Fecha Fin <span className="text-red-500">*</span>
                  </label>
                  <input
                    {...register('end_date')}
                    type="date"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  {errors.end_date && (
                    <p className="mt-1 text-sm text-red-600">{errors.end_date.message}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Motivo <span className="text-red-500">*</span>
                </label>
                <textarea
                  {...register('reason')}
                  rows={4}
                  placeholder="Describe el motivo de tu ausencia..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {errors.reason && (
                  <p className="mt-1 text-sm text-red-600">{errors.reason.message}</p>
                )}
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsFormOpen(false)
                    reset()
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {createMutation.isPending ? 'Enviando...' : 'Enviar Solicitud'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Lista de solicitudes */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h2 className="font-semibold text-gray-900">Mis Solicitudes</h2>
          </div>

          {isLoading ? (
            <div className="p-8 text-center text-gray-500">Cargando solicitudes...</div>
          ) : !leaveRequests || leaveRequests.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              No tienes solicitudes de ausencia
            </div>
          ) : (
            <div className="divide-y">
              {leaveRequests.map((request: any) => {
                const statusBadge = getStatusBadge(request.status)
                const StatusIcon = statusBadge.icon
                return (
                  <div key={request.id} className="p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-gray-400" />
                        <h3 className="font-semibold text-gray-900">
                          {getLeaveTypeLabel(request.leave_type)}
                        </h3>
                      </div>
                      <span className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${statusBadge.color}`}>
                        <StatusIcon className="w-4 h-4" />
                        {statusBadge.text}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                      <div className="text-sm">
                        <span className="text-gray-600">Desde:</span>{' '}
                        <span className="font-medium text-gray-900">
                          {format(parseISO(request.start_date), "d 'de' MMMM 'de' yyyy", { locale: es })}
                        </span>
                      </div>
                      <div className="text-sm">
                        <span className="text-gray-600">Hasta:</span>{' '}
                        <span className="font-medium text-gray-900">
                          {format(parseISO(request.end_date), "d 'de' MMMM 'de' yyyy", { locale: es })}
                        </span>
                      </div>
                    </div>

                    <div className="text-sm text-gray-600 mb-3">
                      <span className="font-medium">Motivo:</span> {request.reason}
                    </div>

                    {request.reviewed_by_name && (
                      <div className="text-xs text-gray-500 border-t pt-3">
                        Revisado por {request.reviewed_by_name} el{' '}
                        {format(parseISO(request.reviewed_at), "d 'de' MMMM 'a las' HH:mm", { locale: es })}
                        {request.reviewer_notes && (
                          <div className="mt-1">
                            <span className="font-medium">Notas:</span> {request.reviewer_notes}
                          </div>
                        )}
                      </div>
                    )}

                    <div className="text-xs text-gray-400 mt-2">
                      Solicitado el {format(parseISO(request.created_at), "d 'de' MMMM 'a las' HH:mm", { locale: es })}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
