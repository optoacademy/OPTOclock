'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { format, parseISO, startOfMonth, endOfMonth } from 'date-fns'
import { es } from 'date-fns/locale'
import { Calendar, Clock, MapPin, Filter } from 'lucide-react'

export default function HistoryPage() {
  const { user } = useAuth()
  const today = new Date()
  const [startDate, setStartDate] = useState(format(startOfMonth(today), 'yyyy-MM-dd'))
  const [endDate, setEndDate] = useState(format(endOfMonth(today), 'yyyy-MM-dd'))

  // Obtener datos del empleado
  const { data: employee } = useQuery({
    queryKey: ['employee-profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null
      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name')
        .eq('user_id', user.id)
        .single()
      if (error) throw error
      return data
    },
    enabled: !!user?.id,
  })

  // Obtener fichajes
  const { data: clockEvents, isLoading } = useQuery({
    queryKey: ['clock-events', employee?.id, startDate, endDate],
    queryFn: async () => {
      if (!employee?.id) return []
      const { data, error } = await supabase
        .from('clock_events')
        .select('*, location:locations(name)')
        .eq('employee_id', employee.id)
        .gte('event_timestamp', `${startDate}T00:00:00`)
        .lte('event_timestamp', `${endDate}T23:59:59`)
        .order('event_timestamp', { ascending: false })
      if (error) throw error
      return data
    },
    enabled: !!employee?.id,
  })

  // Obtener resumen de horas
  const { data: dailyHours } = useQuery({
    queryKey: ['daily-hours', employee?.id, startDate, endDate],
    queryFn: async () => {
      if (!employee?.id) return []
      const { data, error } = await supabase
        .from('daily_hours_summary')
        .select('*')
        .eq('employee_id', employee.id)
        .gte('date', startDate)
        .lte('date', endDate)
        .order('date', { ascending: false })
      if (error) throw error
      return data
    },
    enabled: !!employee?.id,
  })

  // Calcular totales
  const totalHours = dailyHours?.reduce((sum, day) => sum + (day.total_hours || 0), 0) || 0
  const totalOvertime = dailyHours?.reduce((sum, day) => sum + (day.overtime_hours || 0), 0) || 0

  // Agrupar eventos por día
  const eventsByDay = clockEvents?.reduce((acc: any, event: any) => {
    const date = format(parseISO(event.event_timestamp), 'yyyy-MM-dd')
    if (!acc[date]) acc[date] = []
    acc[date].push(event)
    return acc
  }, {}) || {}

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-3xl font-bold text-gray-900">Historial de Fichajes</h1>
          <p className="mt-1 text-sm text-gray-500">
            Consulta todos tus fichajes y horas trabajadas
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Filtros */}
        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center gap-2 mb-3">
            <Filter className="w-5 h-5 text-gray-400" />
            <h2 className="font-semibold text-gray-900">Filtrar por fecha</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fecha Inicio
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fecha Fin
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        {/* Resumen de horas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center gap-3 mb-2">
              <Clock className="w-8 h-8 text-blue-600" />
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {totalHours.toFixed(1)}h
                </div>
                <div className="text-sm text-gray-600">Horas totales</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center gap-3 mb-2">
              <Clock className="w-8 h-8 text-green-600" />
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {totalOvertime.toFixed(1)}h
                </div>
                <div className="text-sm text-gray-600">Horas extra</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center gap-3 mb-2">
              <Calendar className="w-8 h-8 text-purple-600" />
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {dailyHours?.length || 0}
                </div>
                <div className="text-sm text-gray-600">Días trabajados</div>
              </div>
            </div>
          </div>
        </div>

        {/* Lista de fichajes */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h2 className="font-semibold text-gray-900">Fichajes Detallados</h2>
          </div>

          {isLoading ? (
            <div className="p-8 text-center text-gray-500">Cargando fichajes...</div>
          ) : Object.keys(eventsByDay).length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              No hay fichajes en el rango seleccionado
            </div>
          ) : (
            <div className="divide-y">
              {Object.entries(eventsByDay).map(([date, events]: [string, any]) => {
                const dayHours = dailyHours?.find(h => h.date === date)
                return (
                  <div key={date} className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-gray-400" />
                        <div>
                          <div className="font-semibold text-gray-900">
                            {format(parseISO(date), "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })}
                          </div>
                          {dayHours && (
                            <div className="text-sm text-gray-600 mt-1">
                              Total: {dayHours.total_hours.toFixed(2)}h
                              {dayHours.overtime_hours > 0 && (
                                <span className="ml-2 text-orange-600">
                                  (+{dayHours.overtime_hours.toFixed(2)}h extra)
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {events.map((event: any) => (
                        <div
                          key={event.id}
                          className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className={`px-2 py-1 text-xs font-medium rounded ${
                              event.event_type === 'IN' ? 'bg-green-100 text-green-800' :
                              event.event_type === 'OUT' ? 'bg-red-100 text-red-800' :
                              'bg-blue-100 text-blue-800'
                            }`}>
                              {event.event_type}
                            </span>
                            <Clock className="w-4 h-4 text-gray-400" />
                          </div>
                          <div className="text-lg font-semibold text-gray-900 mb-1">
                            {format(parseISO(event.event_timestamp), 'HH:mm:ss')}
                          </div>
                          {event.location && (
                            <div className="flex items-center gap-1 text-xs text-gray-600">
                              <MapPin className="w-3 h-3" />
                              {event.location.name}
                            </div>
                          )}
                          {event.latitude && event.longitude && (
                            <div className="text-xs text-gray-500 mt-1">
                              GPS: {event.latitude.toFixed(4)}, {event.longitude.toFixed(4)}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
