'use client'

import { useAuth } from '@/lib/auth-context'
import { useRouter, usePathname } from 'next/navigation'
import { useEffect } from 'react'
import Link from 'next/link'
import { 
  LayoutDashboard, 
  Clock, 
  History, 
  Calendar, 
  LogOut,
  User
} from 'lucide-react'

export default function EmployeeLayout({ children }: { children: React.ReactNode }) {
  const { user, role, loading, signOut } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (!loading && (!user || (role !== 'EMPLOYEE' && role !== 'ORG_ADMIN' && role !== 'MANAGER'))) {
      router.push('/login')
    }
  }, [user, role, loading, router])

  const handleSignOut = async () => {
    await signOut()
    router.push('/')
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-gray-500">Cargando...</div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  const navigation = [
    { name: 'Inicio', href: '/employee/dashboard', icon: LayoutDashboard },
    { name: 'Fichar', href: '/employee/clock', icon: Clock },
    { name: 'Historial', href: '/employee/history', icon: History },
    { name: 'Ausencias', href: '/employee/leave', icon: Calendar },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header móvil */}
      <div className="lg:hidden bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-6 h-6 text-blue-600" />
            <span className="font-bold text-gray-900">FichajesApp</span>
          </div>
          <button
            onClick={handleSignOut}
            className="text-red-600 p-2 hover:bg-red-50 rounded-lg"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Sidebar desktop */}
      <div className="hidden lg:block fixed inset-y-0 left-0 w-64 bg-white border-r border-gray-200">
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <Clock className="w-8 h-8 text-blue-600" />
            <div>
              <div className="font-bold text-gray-900">FichajesApp</div>
              <div className="text-xs text-gray-500">Portal Empleado</div>
            </div>
          </div>
        </div>

        {/* Navegación */}
        <nav className="p-4 space-y-1">
          {navigation.map((item) => {
            const Icon = item.icon
            const isActive = pathname?.startsWith(item.href)
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-blue-50 text-blue-700 font-medium'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Icon className="w-5 h-5" />
                {item.name}
              </Link>
            )
          })}
        </nav>

        {/* Usuario */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200 bg-white">
          <div className="mb-3 px-4">
            <div className="flex items-center gap-2 mb-1">
              <User className="w-4 h-4 text-gray-400" />
              <div className="text-sm font-medium text-gray-900">
                {user.email}
              </div>
            </div>
            <div className="text-xs text-gray-500 capitalize">
              Empleado
            </div>
          </div>
          <button
            onClick={handleSignOut}
            className="flex items-center gap-3 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Cerrar Sesión
          </button>
        </div>
      </div>

      {/* Contenido principal */}
      <div className="lg:pl-64">
        {children}
      </div>

      {/* Navegación inferior móvil */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
        <nav className="flex items-center justify-around p-2">
          {navigation.map((item) => {
            const Icon = item.icon
            const isActive = pathname?.startsWith(item.href)
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-colors ${
                  isActive
                    ? 'text-blue-700'
                    : 'text-gray-600'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs">{item.name}</span>
              </Link>
            )
          })}
        </nav>
      </div>
    </div>
  )
}
