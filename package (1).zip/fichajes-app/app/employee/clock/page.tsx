'use client'

import { useState, useEffect } from 'react'
import { useAuth } from '@/lib/auth-context'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { format } from 'date-fns'
import { es } from 'date-fns/locale'
import { Clock, MapPin, CheckCircle, XCircle, Loader2 } from 'lucide-react'

export default function ClockPage() {
  const { user } = useAuth()
  const queryClient = useQueryClient()
  const [currentTime, setCurrentTime] = useState(new Date())
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [locationError, setLocationError] = useState<string | null>(null)

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  // Obtener geolocalización
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          })
          setLocationError(null)
        },
        (error) => {
          setLocationError('No se pudo obtener la ubicación. Asegúrate de permitir el acceso.')
          console.error('Error obteniendo ubicación:', error)
        }
      )
    } else {
      setLocationError('Tu navegador no soporta geolocalización')
    }
  }, [])

  // Obtener datos del empleado
  const { data: employee } = useQuery({
    queryKey: ['employee-profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null
      const { data, error } = await supabase
        .from('employees')
        .select('*, location:locations(*, require_geofence), shift:work_shifts(*)')
        .eq('user_id', user.id)
        .single()
      if (error) throw error
      return data
    },
    enabled: !!user?.id,
  })

  // Último evento
  const { data: lastEvent } = useQuery({
    queryKey: ['last-clock-event', employee?.id],
    queryFn: async () => {
      if (!employee?.id) return null
      const { data, error } = await supabase
        .from('clock_events')
        .select('*')
        .eq('employee_id', employee.id)
        .order('event_timestamp', { ascending: false })
        .limit(1)
        .maybeSingle()
      if (error) throw error
      return data
    },
    enabled: !!employee?.id,
  })

  // Registrar fichaje
  const clockMutation = useMutation({
    mutationFn: async (eventType: 'IN' | 'OUT' | 'BREAK_START' | 'BREAK_END') => {
      if (!employee?.id) throw new Error('No se encontró el empleado')
      
      const eventData = {
        employee_id: employee.id,
        event_type: eventType,
        location_id: employee.default_location_id,
        latitude: location?.lat || null,
        longitude: location?.lng || null,
      }

      // Llamar a Edge Function
      const response = await fetch(
        'https://cfzlqrwezvasadjfjudd.supabase.co/functions/v1/clock-event',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify(eventData),
        }
      )

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error?.message || 'Error al registrar fichaje')
      }

      return await response.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['last-clock-event'] })
      queryClient.invalidateQueries({ queryKey: ['month-stats'] })
      alert('¡Fichaje registrado correctamente!')
    },
    onError: (error: Error) => {
      alert(`Error al fichar: ${error.message}`)
    },
  })

  const handleClock = (eventType: 'IN' | 'OUT' | 'BREAK_START' | 'BREAK_END') => {
    if (employee?.location?.require_geofence && !location) {
      alert('La geolocalización es requerida para fichar en esta ubicación')
      return
    }
    
    if (confirm(`¿Confirmas el fichaje de ${
      eventType === 'IN' ? 'ENTRADA' :
      eventType === 'OUT' ? 'SALIDA' :
      eventType === 'BREAK_START' ? 'INICIO DESCANSO' :
      'FIN DESCANSO'
    }?`)) {
      clockMutation.mutate(eventType)
    }
  }

  const getNextAction = () => {
    if (!lastEvent) return 'IN'
    if (lastEvent.event_type === 'OUT') return 'IN'
    if (lastEvent.event_type === 'IN') return 'OUT'
    if (lastEvent.event_type === 'BREAK_START') return 'BREAK_END'
    return 'BREAK_START'
  }

  const nextAction = getNextAction()

  const getActionButton = (action: string) => {
    switch (action) {
      case 'IN':
        return {
          label: 'Fichar Entrada',
          color: 'bg-green-600 hover:bg-green-700',
          icon: <CheckCircle className="w-6 h-6" />,
        }
      case 'OUT':
        return {
          label: 'Fichar Salida',
          color: 'bg-red-600 hover:bg-red-700',
          icon: <XCircle className="w-6 h-6" />,
        }
      case 'BREAK_START':
        return {
          label: 'Iniciar Descanso',
          color: 'bg-blue-600 hover:bg-blue-700',
          icon: <Clock className="w-6 h-6" />,
        }
      case 'BREAK_END':
        return {
          label: 'Fin Descanso',
          color: 'bg-orange-600 hover:bg-orange-700',
          icon: <Clock className="w-6 h-6" />,
        }
      default:
        return {
          label: 'Fichar',
          color: 'bg-gray-600 hover:bg-gray-700',
          icon: <Clock className="w-6 h-6" />,
        }
    }
  }

  const actionButton = getActionButton(nextAction)

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-3xl font-bold text-gray-900 text-center">Fichar</h1>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Reloj */}
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <div className="text-6xl font-bold text-gray-900 mb-2">
            {format(currentTime, 'HH:mm:ss')}
          </div>
          <div className="text-lg text-gray-600">
            {format(currentTime, "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })}
          </div>
        </div>

        {/* Estado de geolocalización */}
        <div className={`rounded-lg p-4 ${
          location ? 'bg-green-50 border border-green-200' :
          locationError ? 'bg-yellow-50 border border-yellow-200' :
          'bg-blue-50 border border-blue-200'
        }`}>
          <div className="flex items-start gap-3">
            <MapPin className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
              location ? 'text-green-600' :
              locationError ? 'text-yellow-600' :
              'text-blue-600'
            }`} />
            <div>
              <div className={`font-medium ${
                location ? 'text-green-900' :
                locationError ? 'text-yellow-900' :
                'text-blue-900'
              }`}>
                {location ? 'Ubicación detectada' :
                 locationError ? 'Error de ubicación' :
                 'Obteniendo ubicación...'}
              </div>
              {location && (
                <div className="text-sm text-green-700 mt-1">
                  Lat: {location.lat.toFixed(6)}, Lng: {location.lng.toFixed(6)}
                </div>
              )}
              {locationError && (
                <div className="text-sm text-yellow-700 mt-1">{locationError}</div>
              )}
              {employee?.location?.require_geofence && (
                <div className="text-xs text-gray-600 mt-2">
                  ⚠️ La geolocalización es obligatoria para fichar en tu ubicación asignada
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Último fichaje */}
        {lastEvent && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold text-gray-900 mb-2">Último fichaje</h3>
            <div className="flex items-center justify-between">
              <div>
                <span className={`inline-block px-3 py-1 text-sm font-medium rounded ${
                  lastEvent.event_type === 'IN' ? 'bg-green-100 text-green-800' :
                  lastEvent.event_type === 'OUT' ? 'bg-red-100 text-red-800' :
                  'bg-blue-100 text-blue-800'
                }`}>
                  {lastEvent.event_type}
                </span>
              </div>
              <div className="text-sm text-gray-600">
                {format(new Date(lastEvent.event_timestamp), "dd/MM/yyyy HH:mm:ss", { locale: es })}
              </div>
            </div>
          </div>
        )}

        {/* Información de ubicación asignada */}
        {employee?.location && (
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <div className="font-medium text-blue-900">Ubicación asignada</div>
                <div className="text-sm text-blue-700 mt-1">{employee.location.name}</div>
                {employee.location.address && (
                  <div className="text-xs text-blue-600 mt-1">{employee.location.address}</div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Botón principal de fichaje */}
        <button
          onClick={() => handleClock(nextAction as any)}
          disabled={clockMutation.isPending}
          className={`w-full py-6 px-6 ${actionButton.color} text-white rounded-lg text-xl font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3`}
        >
          {clockMutation.isPending ? (
            <>
              <Loader2 className="w-6 h-6 animate-spin" />
              Registrando...
            </>
          ) : (
            <>
              {actionButton.icon}
              {actionButton.label}
            </>
          )}
        </button>

        {/* Botones secundarios */}
        <div className="grid grid-cols-2 gap-4">
          {nextAction !== 'BREAK_START' && (
            <button
              onClick={() => handleClock('BREAK_START')}
              disabled={clockMutation.isPending || lastEvent?.event_type === 'BREAK_START'}
              className="py-3 px-4 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Iniciar Descanso
            </button>
          )}
          {nextAction !== 'BREAK_END' && lastEvent?.event_type === 'BREAK_START' && (
            <button
              onClick={() => handleClock('BREAK_END')}
              disabled={clockMutation.isPending}
              className="py-3 px-4 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Fin Descanso
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
