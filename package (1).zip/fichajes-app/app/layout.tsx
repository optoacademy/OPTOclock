import './globals.css'
import type { Metadata } from 'next'
import { AuthProvider } from '@/lib/auth-context'
import { QueryProvider } from '@/lib/query-provider'
import { PWARegister } from '@/components/pwa-register'

export const metadata: Metadata = {
  title: 'Sistema de Fichaje - TechCorp',
  description: 'Sistema profesional de gestión de fichajes multi-empresa',
  manifest: '/manifest.json',
  themeColor: '#3B82F6',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'FichajesApp',
  },
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <head>
        <link rel="apple-touch-icon" href="/icon-192x192.png" />
      </head>
      <body>
        <QueryProvider>
          <AuthProvider>
            {children}
            <PWARegister />
          </AuthProvider>
        </QueryProvider>
      </body>
    </html>
  )
}
