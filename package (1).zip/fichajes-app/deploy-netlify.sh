#!/bin/bash
# Deploy Script para Netlify

echo "🚀 Iniciando deploy a Netlify..."

# Verificar que estamos en el directorio correcto
if [ ! -f "package.json" ]; then
    echo "❌ Error: No se encuentra package.json"
    echo "   Ejecuta este script desde el directorio /workspace/fichajes-app"
    exit 1
fi

# Instalar dependencias
echo "📦 Instalando dependencias..."
npm install

# Build del proyecto
echo "🔨 Construyendo proyecto..."
npm run build

# Verificar que el build fue exitoso
if [ ! -d ".next" ]; then
    echo "❌ Error: Build falló, directorio .next no encontrado"
    exit 1
fi

echo "✅ Build exitoso!"

# Deploy a Netlify (requiere CLI instalado)
echo "🌐 Desplegando a Netlify..."
netlify deploy --prod --dir=.next

echo "🎉 ¡Deploy completado!"
echo ""
echo "📋 Próximos pasos:"
echo "1. Ve a https://app.netlify.com/sites"
echo "2. Selecciona tu sitio: SaaS Fichaje de Empleados"
echo "3. Ve a Site Settings > Environment Variables"
echo "4. Añade estas variables:"
echo ""
echo "NEXT_PUBLIC_SUPABASE_URL=https://cfzlqrwezvasadjfjudd.supabase.co"
echo "NEXT_PUBLIC_SUPABASE_ANON_KEY=tu_anon_key_aqui"
echo "GOOGLE_MAPS_API_KEY=tu_google_maps_key_aqui"
echo ""
echo "🌐 Tu sitio estará disponible en: https://tu-sitio.netlify.app"
