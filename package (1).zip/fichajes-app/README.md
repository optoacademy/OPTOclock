# Sistema de Fichaje de Empleados Multi-Empresa

Sistema profesional SaaS de gestión de fichajes compatible con normativa laboral española y europea (GDPR, Ley Orgánica 3/2018).

## Características Principales

- **Multi-Tenant**: Aislamiento completo de datos por organización
- **Fichaje Multi-Canal**: Web, móvil, kiosko con PIN, API REST
- **Geofencing**: Validación automática de ubicación GPS
- **Cumplimiento Legal UE/España**: Retención 4 años, descansos obligatorios, exportación firmada
- **PWA Offline**: Funcionamiento sin conexión con sincronización automática
- **Biometría Opcional**: Desactivada por defecto (requiere DPIA)
- **Auditoría Completa**: Trazabilidad inmutable de todos los cambios
- **Reportes Firmados**: Exportación CSV/PDF con hash SHA-256 para inspecciones

## Stack Tecnológico

- **Frontend**: Next.js 14 (App Router) + TypeScript + Tailwind CSS
- **Backend**: Supabase (PostgreSQL + Auth + Edge Functions + Storage + RLS)
- **Base de Datos**: PostgreSQL con Row Level Security (RLS) multi-tenant
- **Autenticación**: Supabase Auth con roles (ORG_ADMIN, MANAGER, EMPLOYEE)
- **PWA**: Service Worker + IndexedDB para modo offline
- **Mapas**: Google Maps API para geofencing
- **Despliegue**: Netlify

## Inicio Rápido (5 pasos)

### 1. Clonar el repositorio

```bash
git clone <repository-url>
cd fichajes-app
```

### 2. Instalar dependencias

```bash
npm install
```

### 3. Configurar variables de entorno

Crear archivo `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://cfzlqrwezvasadjfjudd.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
GOOGLE_MAPS_API_KEY=AIzaSy...
ENCRYPTION_KEY=<32-byte-random-hex>
```

### 4. Aplicar migraciones de base de datos

Las migraciones ya están aplicadas en Supabase. Si necesitas recrearlas:

```bash
# Ver archivos en /supabase/*.sql
# Aplicar manualmente via Supabase Dashboard > SQL Editor
```

### 5. Ejecutar en desarrollo

```bash
npm run dev
```

Abrir [http://localhost:3000](http://localhost:3000)

## Usuarios Demo

### Organización
- **Nombre**: TechCorp España S.L.
- **CIF**: B12345678

### Empleados (Modo Kiosko)
- **EMP001**: Juan García López (PIN: 1234)
- **EMP002**: María Rodríguez Sánchez (PIN: 2345)
- **EMP003**: Carlos Martínez Pérez (PIN: 3456)
- **EMP004**: Ana Fernández Gómez (PIN: 4567)
- **EMP005**: Pedro López Martín (PIN: 5678)

### Admin (crear vía signup)
- Email: admin@techcorp.es
- Password: Admin123!
- Role: ORG_ADMIN

## Estructura del Proyecto

```
fichajes-app/
├── app/                      # Next.js App Router
│   ├── page.tsx             # Página de inicio
│   ├── kiosk/               # Modo kiosko
│   ├── admin/               # Panel admin
│   ├── employee/            # Panel empleado
│   └── api/                 # API routes
├── lib/                     # Utilidades
│   ├── supabase.ts          # Cliente Supabase
│   └── security/            # Validaciones
├── components/              # Componentes React
├── supabase/               # Backend
│   ├── schema.sql          # Esquema DB
│   ├── policies.sql        # RLS policies
│   ├── seed.sql            # Datos demo
│   └── functions/          # Edge Functions
│       ├── clock-event/    # Fichajes
│       └── export-report/  # Exportaciones
├── public/                 # Assets estáticos
├── LEGAL.md               # Cumplimiento legal
├── SECURITY.md            # Medidas de seguridad
├── PRIVACY.md             # Política privacidad
└── DPIA.example.md        # DPIA biometría
```

## Scripts Disponibles

```bash
npm run dev        # Desarrollo (localhost:3000)
npm run build      # Build de producción
npm run start      # Servidor de producción
npm run lint       # Linter
```

## Base de Datos

### Tablas Principales (14)
- `organizations`: Configuración multi-tenant
- `users_profile`: Perfiles de usuario
- `memberships`: Relación usuario-organización
- `employees`: Empleados (pueden no tener usuario)
- `locations`: Ubicaciones con geofencing
- `work_shifts`: Turnos de trabajo
- `clock_events`: Eventos de fichaje (núcleo)
- `leave_requests`: Solicitudes de ausencias
- `incidents`: Incidencias automáticas
- `audit_logs`: Auditoría completa
- `webhooks`: Integraciones
- `holidays`: Festivos
- `representatives`: Representantes legales
- `daily_hours_summary`: Resumen diario materializado

### Políticas RLS
- Empleado: Solo ve sus propios datos
- Manager: Ve datos de su organización
- Admin: Control total de su organización
- Representante: Lectura de datos de trabajadores

## Edge Functions

### 1. clock-event
**URL**: `/functions/v1/clock-event`

Crear eventos de fichaje con validaciones completas.

**Request**:
```json
{
  "employee_id": "uuid",
  "type": "IN|OUT|BREAK_START|BREAK_END",
  "lat": 40.4200,
  "lng": -3.7038,
  "source": "WEB|KIOSK|MOBILE|API",
  "notes": "string (opcional)",
  "pin": "string (solo kiosko)"
}
```

**Validaciones**:
- Secuencia de fichajes válida
- Geofencing (si está habilitado)
- Whitelist de IPs (si está habilitado)
- Detección de llegadas tarde
- Cálculo automático de incidencias

### 2. export-report
**URL**: `/functions/v1/export-report`

Exportar reportes firmados para inspecciones.

**Request**:
```json
{
  "organization_id": "uuid",
  "start_date": "2025-01-01",
  "end_date": "2025-01-31",
  "employee_id": "uuid (opcional)",
  "format": "CSV|JSON"
}
```

**Response**: Archivo CSV/JSON con hash SHA-256

## Cumplimiento Legal

### Retención de Datos (España/UE)
- **Mínimo**: 4 años (Ley Orgánica 3/2018)
- **Implementación**: Soft delete, anonimización post-retención
- **Acceso**: Empleado, representantes, Inspección de Trabajo

### Descansos Obligatorios (UE)
- 11 horas entre jornadas (Directiva 2003/88/CE)
- Pausa si jornada > 6 horas
- 24 horas de descanso semanal
- Máximo 48 horas semanales (promedio)

### Inmutabilidad
- Hash SHA-256 de parte diario por empleado
- Audit logs de todos los cambios
- Exportaciones firmadas

Ver [LEGAL.md](./LEGAL.md) para más detalles.

## Seguridad

- **RLS Multi-Tenant**: Aislamiento estricto por organización
- **Autenticación**: Supabase Auth con JWT
- **Rate Limiting**: Endpoints críticos protegidos
- **Encriptación**: PIN hasheado con bcrypt, datos en tránsito TLS
- **Auditoría**: Logs completos de acciones

Ver [SECURITY.md](./SECURITY.md) para más detalles.

## PWA Offline

El sistema funciona sin conexión:
1. Service Worker captura fichajes offline
2. IndexedDB almacena cola de sincronización
3. Reintentos exponenciales automáticos
4. Marca `offline_cached=true` en eventos

## Tests

```bash
# Unitarios
npm run test:unit

# E2E
npm run test:e2e

# Coverage
npm run test:coverage
```

## Despliegue a Netlify

```bash
# Build
npm run build

# Deploy
netlify deploy --prod --dir=.next
```

## Soporte y Contacto

Para soporte técnico o consultas:
- Email: soporte@techcorp.es
- Documentación: Ver archivos LEGAL.md, SECURITY.md, PRIVACY.md

## Licencia

Propietario - Todos los derechos reservados

## Changelog

### v1.0.0 (2025-10-30)
- Lanzamiento inicial
- Sistema multi-tenant completo
- Cumplimiento legal UE/España
- PWA offline
- Geofencing
- Export firmado
