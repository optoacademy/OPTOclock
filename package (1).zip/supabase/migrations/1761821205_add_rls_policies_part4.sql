-- Migration: add_rls_policies_part4
-- Created at: 1761821205

-- RLS: webhooks
CREATE POLICY "Admins can manage webhooks"
ON webhooks FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- RLS: holidays
CREATE POLICY "Everyone can view holidays"
ON holidays FOR SELECT
TO authenticated, anon
USING (true);

CREATE POLICY "Service role can manage holidays"
ON holidays FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- RLS: representatives
CREATE POLICY "Admins can manage representatives"
ON representatives FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

CREATE POLICY "Users can view own representative status"
ON representatives FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- RLS: daily_hours_summary
CREATE POLICY "Employees can view own hours summary"
ON daily_hours_summary FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = daily_hours_summary.employee_id
          AND employees.user_id = auth.uid()
    )
);

CREATE POLICY "Admins can view org hours summary"
ON daily_hours_summary FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

CREATE POLICY "System can manage hours summary"
ON daily_hours_summary FOR ALL
TO authenticated, anon
USING (auth.role() IN ('authenticated', 'anon', 'service_role'))
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));;