-- Migration: add_rls_policies_part1
-- Created at: 1761821148

-- RLS: organizations
CREATE POLICY "Users can view their organization"
ON organizations FOR SELECT
TO authenticated
USING (id = get_user_organization_id());

CREATE POLICY "Org admins can update their organization"
ON organizations FOR UPDATE
TO authenticated
USING (is_org_admin_or_manager(id))
WITH CHECK (is_org_admin_or_manager(id));

-- RLS: users_profile
CREATE POLICY "Users can view own profile"
ON users_profile FOR SELECT
TO authenticated
USING (id = auth.uid());

CREATE POLICY "Users can update own profile"
ON users_profile FOR UPDATE
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

CREATE POLICY "Users can insert own profile"
ON users_profile FOR INSERT
TO authenticated, anon
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- RLS: memberships
CREATE POLICY "Users can view own memberships"
ON memberships FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Admins can view org memberships"
ON memberships FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

CREATE POLICY "Admins can manage memberships"
ON memberships FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- RLS: employees
CREATE POLICY "Employees can view own profile"
ON employees FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Admins can view org employees"
ON employees FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

CREATE POLICY "Representatives can view employees"
ON employees FOR SELECT
TO authenticated
USING (is_representative(organization_id));

CREATE POLICY "Admins can manage employees"
ON employees FOR ALL
TO authenticated, anon
USING (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
)
WITH CHECK (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
);;