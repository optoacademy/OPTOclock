-- Migration: add_rls_helper_functions
-- Created at: 1761821135

-- Helper: obtener organization_id del usuario actual
CREATE OR REPLACE FUNCTION get_user_organization_id()
RETURNS UUID AS $$
DECLARE
    v_org_id UUID;
BEGIN
    SELECT organization_id INTO v_org_id
    FROM memberships
    WHERE user_id = auth.uid()
      AND is_active = true
    LIMIT 1;
    
    RETURN v_org_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper: verificar si usuario es admin/manager
CREATE OR REPLACE FUNCTION is_org_admin_or_manager(p_org_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM memberships
        WHERE user_id = auth.uid()
          AND organization_id = p_org_id
          AND role IN ('ORG_ADMIN', 'MANAGER')
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper: verificar si usuario es empleado específico
CREATE OR REPLACE FUNCTION is_employee(p_employee_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM employees
        WHERE id = p_employee_id
          AND user_id = auth.uid()
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper: verificar si usuario es representante legal
CREATE OR REPLACE FUNCTION is_representative(p_org_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM representatives
        WHERE user_id = auth.uid()
          AND organization_id = p_org_id
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grants
GRANT EXECUTE ON FUNCTION get_user_organization_id() TO authenticated;
GRANT EXECUTE ON FUNCTION is_org_admin_or_manager(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION is_employee(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION is_representative(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION validate_clock_sequence(UUID, clock_event_type, TIMESTAMPTZ) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION calculate_daily_hash(UUID, DATE) TO authenticated, anon;;