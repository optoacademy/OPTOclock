-- Migration: add_functions_and_triggers
-- Created at: 1761821110

-- Función para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar triggers
CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_profile_updated_at BEFORE UPDATE ON users_profile
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_memberships_updated_at BEFORE UPDATE ON memberships
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON employees
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_locations_updated_at BEFORE UPDATE ON locations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_work_shifts_updated_at BEFORE UPDATE ON work_shifts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_leave_requests_updated_at BEFORE UPDATE ON leave_requests
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_webhooks_updated_at BEFORE UPDATE ON webhooks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Función para calcular hash diario
CREATE OR REPLACE FUNCTION calculate_daily_hash(
    p_employee_id UUID,
    p_work_date DATE
) RETURNS TEXT AS $$
DECLARE
    v_hash TEXT;
BEGIN
    SELECT encode(
        digest(
            string_agg(
                id::text || type::text || timestamp_utc::text,
                '|'
                ORDER BY timestamp_utc
            ),
            'sha256'
        ),
        'hex'
    ) INTO v_hash
    FROM clock_events
    WHERE employee_id = p_employee_id
      AND timestamp_local::date = p_work_date;
    
    RETURN COALESCE(v_hash, '');
END;
$$ LANGUAGE plpgsql;

-- Función para validar secuencia de fichajes
CREATE OR REPLACE FUNCTION validate_clock_sequence(
    p_employee_id UUID,
    p_type clock_event_type,
    p_timestamp TIMESTAMPTZ
) RETURNS BOOLEAN AS $$
DECLARE
    v_last_event clock_event_type;
BEGIN
    SELECT type INTO v_last_event
    FROM clock_events
    WHERE employee_id = p_employee_id
      AND timestamp_utc < p_timestamp
    ORDER BY timestamp_utc DESC
    LIMIT 1;
    
    IF v_last_event IS NULL THEN
        RETURN p_type = 'IN';
    END IF;
    
    IF v_last_event = 'IN' THEN
        RETURN p_type IN ('OUT', 'BREAK_START');
    ELSIF v_last_event = 'OUT' THEN
        RETURN p_type = 'IN';
    ELSIF v_last_event = 'BREAK_START' THEN
        RETURN p_type = 'BREAK_END';
    ELSIF v_last_event = 'BREAK_END' THEN
        RETURN p_type IN ('OUT', 'BREAK_START');
    END IF;
    
    RETURN false;
END;
$$ LANGUAGE plpgsql;;