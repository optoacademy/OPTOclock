-- Migration: add_rls_policies_part2
-- Created at: 1761821164

-- RLS: locations
CREATE POLICY "Users can view org locations"
ON locations FOR SELECT
TO authenticated
USING (organization_id = get_user_organization_id());

CREATE POLICY "Admins can manage locations"
ON locations FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- RLS: work_shifts
CREATE POLICY "Users can view org shifts"
ON work_shifts FOR SELECT
TO authenticated
USING (organization_id = get_user_organization_id());

CREATE POLICY "Admins can manage shifts"
ON work_shifts FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- RLS: clock_events (CRÍTICO)
CREATE POLICY "Employees can view own clock events"
ON clock_events FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = clock_events.employee_id
          AND employees.user_id = auth.uid()
    )
);

CREATE POLICY "Admins can view org clock events"
ON clock_events FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

CREATE POLICY "Representatives can view clock events"
ON clock_events FOR SELECT
TO authenticated
USING (is_representative(organization_id));

CREATE POLICY "Employees can create own clock events"
ON clock_events FOR INSERT
TO authenticated, anon
WITH CHECK (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = clock_events.employee_id
          AND (employees.user_id = auth.uid() OR auth.role() IN ('anon', 'service_role'))
    ) OR
    auth.role() IN ('anon', 'service_role')
);

CREATE POLICY "Admins can manage clock events"
ON clock_events FOR ALL
TO authenticated, anon
USING (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
)
WITH CHECK (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
);;