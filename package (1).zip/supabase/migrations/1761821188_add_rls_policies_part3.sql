-- Migration: add_rls_policies_part3
-- Created at: 1761821188

-- RLS: leave_requests
CREATE POLICY "Employees can view own leave requests"
ON leave_requests FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = leave_requests.employee_id
          AND employees.user_id = auth.uid()
    )
);

CREATE POLICY "Admins can view org leave requests"
ON leave_requests FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

CREATE POLICY "Employees can create leave requests"
ON leave_requests FOR INSERT
TO authenticated
WITH CHECK (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = leave_requests.employee_id
          AND employees.user_id = auth.uid()
    )
);

CREATE POLICY "Admins can manage leave requests"
ON leave_requests FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- RLS: incidents
CREATE POLICY "Admins can view org incidents"
ON incidents FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

CREATE POLICY "Employees can view own incidents"
ON incidents FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = incidents.employee_id
          AND employees.user_id = auth.uid()
    )
);

CREATE POLICY "System can create incidents"
ON incidents FOR INSERT
TO authenticated, anon
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

CREATE POLICY "Admins can manage incidents"
ON incidents FOR UPDATE
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- RLS: audit_logs
CREATE POLICY "Admins can view org audit logs"
ON audit_logs FOR SELECT
TO authenticated
USING (
    organization_id IS NULL OR
    is_org_admin_or_manager(organization_id)
);

CREATE POLICY "System can create audit logs"
ON audit_logs FOR INSERT
TO authenticated, anon
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));;