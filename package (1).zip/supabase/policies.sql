-- ============================================
-- POLÍTICAS RLS MULTI-TENANT ESTRICTAS
-- Cumplimiento: Solo acceso a datos de la propia organización
-- ============================================

-- Helper function: obtener organization_id del usuario actual
CREATE OR REPLACE FUNCTION get_user_organization_id()
RETURNS UUID AS $$
DECLARE
    v_org_id UUID;
BEGIN
    SELECT organization_id INTO v_org_id
    FROM memberships
    WHERE user_id = auth.uid()
      AND is_active = true
    LIMIT 1;
    
    RETURN v_org_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper function: verificar si usuario es admin/manager de una organización
CREATE OR REPLACE FUNCTION is_org_admin_or_manager(p_org_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM memberships
        WHERE user_id = auth.uid()
          AND organization_id = p_org_id
          AND role IN ('ORG_ADMIN', 'MANAGER')
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper function: verificar si usuario es empleado específico
CREATE OR REPLACE FUNCTION is_employee(p_employee_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM employees
        WHERE id = p_employee_id
          AND user_id = auth.uid()
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper function: verificar si usuario es representante legal
CREATE OR REPLACE FUNCTION is_representative(p_org_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM representatives
        WHERE user_id = auth.uid()
          AND organization_id = p_org_id
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- POLÍTICAS: organizations
-- ============================================

-- Admin/Manager pueden ver su organización
CREATE POLICY "Users can view their organization"
ON organizations FOR SELECT
TO authenticated
USING (id = get_user_organization_id());

-- Solo ORG_ADMIN puede actualizar
CREATE POLICY "Org admins can update their organization"
ON organizations FOR UPDATE
TO authenticated
USING (is_org_admin_or_manager(id))
WITH CHECK (is_org_admin_or_manager(id));

-- ============================================
-- POLÍTICAS: users_profile
-- ============================================

-- Usuarios pueden ver su propio perfil
CREATE POLICY "Users can view own profile"
ON users_profile FOR SELECT
TO authenticated
USING (id = auth.uid());

-- Usuarios pueden actualizar su propio perfil
CREATE POLICY "Users can update own profile"
ON users_profile FOR UPDATE
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Permitir INSERT para nuevos usuarios (signup)
CREATE POLICY "Users can insert own profile"
ON users_profile FOR INSERT
TO authenticated, anon
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- ============================================
-- POLÍTICAS: memberships
-- ============================================

-- Usuarios pueden ver sus membresías
CREATE POLICY "Users can view own memberships"
ON memberships FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Admin puede ver todas las membresías de su organización
CREATE POLICY "Admins can view org memberships"
ON memberships FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Admin puede crear/actualizar membresías
CREATE POLICY "Admins can manage memberships"
ON memberships FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: employees
-- ============================================

-- Empleados pueden ver su propio perfil
CREATE POLICY "Employees can view own profile"
ON employees FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Admin/Manager pueden ver todos los empleados de su org
CREATE POLICY "Admins can view org employees"
ON employees FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Representantes pueden ver empleados
CREATE POLICY "Representatives can view employees"
ON employees FOR SELECT
TO authenticated
USING (is_representative(organization_id));

-- Admin/Manager pueden gestionar empleados
CREATE POLICY "Admins can manage employees"
ON employees FOR ALL
TO authenticated, anon
USING (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
)
WITH CHECK (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
);

-- ============================================
-- POLÍTICAS: locations
-- ============================================

-- Usuarios pueden ver ubicaciones de su organización
CREATE POLICY "Users can view org locations"
ON locations FOR SELECT
TO authenticated
USING (organization_id = get_user_organization_id());

-- Admin puede gestionar ubicaciones
CREATE POLICY "Admins can manage locations"
ON locations FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: work_shifts
-- ============================================

-- Usuarios pueden ver turnos de su organización
CREATE POLICY "Users can view org shifts"
ON work_shifts FOR SELECT
TO authenticated
USING (organization_id = get_user_organization_id());

-- Admin puede gestionar turnos
CREATE POLICY "Admins can manage shifts"
ON work_shifts FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: clock_events (CRÍTICO)
-- ============================================

-- Empleados solo ven sus propios fichajes
CREATE POLICY "Employees can view own clock events"
ON clock_events FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = clock_events.employee_id
          AND employees.user_id = auth.uid()
    )
);

-- Admin/Manager ven todos los fichajes de su org
CREATE POLICY "Admins can view org clock events"
ON clock_events FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Representantes pueden ver fichajes
CREATE POLICY "Representatives can view clock events"
ON clock_events FOR SELECT
TO authenticated
USING (is_representative(organization_id));

-- Empleados pueden crear sus propios fichajes
CREATE POLICY "Employees can create own clock events"
ON clock_events FOR INSERT
TO authenticated, anon
WITH CHECK (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = clock_events.employee_id
          AND (employees.user_id = auth.uid() OR auth.role() IN ('anon', 'service_role'))
    ) OR
    auth.role() IN ('anon', 'service_role')
);

-- Admin puede crear/actualizar fichajes (correcciones)
CREATE POLICY "Admins can manage clock events"
ON clock_events FOR ALL
TO authenticated, anon
USING (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
)
WITH CHECK (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
);

-- ============================================
-- POLÍTICAS: leave_requests
-- ============================================

-- Empleados ven sus propias solicitudes
CREATE POLICY "Employees can view own leave requests"
ON leave_requests FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = leave_requests.employee_id
          AND employees.user_id = auth.uid()
    )
);

-- Admin ve todas las solicitudes de su org
CREATE POLICY "Admins can view org leave requests"
ON leave_requests FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Empleados pueden crear sus solicitudes
CREATE POLICY "Employees can create leave requests"
ON leave_requests FOR INSERT
TO authenticated
WITH CHECK (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = leave_requests.employee_id
          AND employees.user_id = auth.uid()
    )
);

-- Admin puede gestionar solicitudes
CREATE POLICY "Admins can manage leave requests"
ON leave_requests FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: incidents
-- ============================================

-- Admin/Manager ven incidencias de su org
CREATE POLICY "Admins can view org incidents"
ON incidents FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Empleados ven sus propias incidencias
CREATE POLICY "Employees can view own incidents"
ON incidents FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = incidents.employee_id
          AND employees.user_id = auth.uid()
    )
);

-- Sistema puede crear incidencias (via edge functions)
CREATE POLICY "System can create incidents"
ON incidents FOR INSERT
TO authenticated, anon
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- Admin puede resolver incidencias
CREATE POLICY "Admins can manage incidents"
ON incidents FOR UPDATE
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: audit_logs
-- ============================================

-- Solo lectura para admin
CREATE POLICY "Admins can view org audit logs"
ON audit_logs FOR SELECT
TO authenticated
USING (
    organization_id IS NULL OR
    is_org_admin_or_manager(organization_id)
);

-- Sistema puede crear logs
CREATE POLICY "System can create audit logs"
ON audit_logs FOR INSERT
TO authenticated, anon
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- ============================================
-- POLÍTICAS: webhooks
-- ============================================

-- Admin puede gestionar webhooks
CREATE POLICY "Admins can manage webhooks"
ON webhooks FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: holidays
-- ============================================

-- Todos pueden leer festivos
CREATE POLICY "Everyone can view holidays"
ON holidays FOR SELECT
TO authenticated, anon
USING (true);

-- Solo admin de sistema puede gestionar (via migration)
CREATE POLICY "Service role can manage holidays"
ON holidays FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- ============================================
-- POLÍTICAS: representatives
-- ============================================

-- Admin puede gestionar representantes
CREATE POLICY "Admins can manage representatives"
ON representatives FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- Usuarios pueden ver si son representantes
CREATE POLICY "Users can view own representative status"
ON representatives FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- ============================================
-- POLÍTICAS: daily_hours_summary
-- ============================================

-- Empleados ven su propio resumen
CREATE POLICY "Employees can view own hours summary"
ON daily_hours_summary FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = daily_hours_summary.employee_id
          AND employees.user_id = auth.uid()
    )
);

-- Admin ve todos los resúmenes de su org
CREATE POLICY "Admins can view org hours summary"
ON daily_hours_summary FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Sistema puede crear/actualizar resúmenes
CREATE POLICY "System can manage hours summary"
ON daily_hours_summary FOR ALL
TO authenticated, anon
USING (auth.role() IN ('authenticated', 'anon', 'service_role'))
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- ============================================
-- GRANTS
-- ============================================

-- Permitir acceso a funciones helper
GRANT EXECUTE ON FUNCTION get_user_organization_id() TO authenticated;
GRANT EXECUTE ON FUNCTION is_org_admin_or_manager(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION is_employee(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION is_representative(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION validate_clock_sequence(UUID, clock_event_type, TIMESTAMPTZ) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION calculate_daily_hash(UUID, DATE) TO authenticated, anon;
