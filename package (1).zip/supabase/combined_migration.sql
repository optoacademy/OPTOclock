-- ============================================
-- Schema completo para SaaS Fichaje Empleados
-- Cumplimiento normativo UE/España
-- ============================================

-- Extensions necesarias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- ENUMS
-- ============================================

CREATE TYPE membership_role AS ENUM ('ORG_ADMIN', 'MANAGER', 'EMPLOYEE');
CREATE TYPE clock_event_type AS ENUM ('IN', 'OUT', 'BREAK_START', 'BREAK_END');
CREATE TYPE clock_event_source AS ENUM ('WEB', 'KIOSK', 'MOBILE', 'API');
CREATE TYPE leave_request_type AS ENUM ('VACATION', 'SICK', 'PERSONAL', 'OTHER');
CREATE TYPE leave_request_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED');
CREATE TYPE incident_kind AS ENUM ('LATE', 'MISSING_OUT', 'OUT_OF_GEOFENCE', 'OUT_OF_IP', 'OVERLAP', 'REST_VIOLATION');
CREATE TYPE webhook_event AS ENUM ('EMPLOYEE_CREATED', 'CLOCK_EVENT_CREATED', 'LEAVE_REQUEST_CREATED', 'INCIDENT_CREATED', 'REPORT_EXPORTED');

-- ============================================
-- TABLAS PRINCIPALES
-- ============================================

-- Organizaciones (multi-tenant)
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    vat_id TEXT UNIQUE NOT NULL,
    settings JSONB DEFAULT '{
        "timezone": "Europe/Madrid",
        "work_hours_per_day": 8,
        "overtime_threshold_hours": 40,
        "late_tolerance_minutes": 15,
        "require_geofence": false,
        "require_photo": false,
        "require_ip_whitelist": false,
        "retention_years": 4
    }'::jsonb,
    biometric_enabled BOOLEAN DEFAULT false,
    api_key TEXT UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex'),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Perfiles de usuario (vinculado a auth.users)
CREATE TABLE users_profile (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    avatar_url TEXT,
    locale TEXT DEFAULT 'es',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Membresías (relación usuario-organización)
CREATE TABLE memberships (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users_profile(id) ON DELETE CASCADE,
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    role membership_role NOT NULL DEFAULT 'EMPLOYEE',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, organization_id)
);

-- Empleados (pueden o no estar vinculados a un usuario)
CREATE TABLE employees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users_profile(id) ON DELETE SET NULL,
    external_code TEXT NOT NULL,
    pin_hash TEXT,
    full_name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    default_location_id UUID,
    default_shift_id UUID,
    hire_date DATE,
    termination_date DATE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, external_code)
);

-- Ubicaciones/Centros de trabajo
CREATE TABLE locations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    address TEXT,
    lat DECIMAL(10, 8),
    lng DECIMAL(11, 8),
    geofence_radius_m INTEGER DEFAULT 100,
    ip_whitelist TEXT[] DEFAULT '{}',
    require_geofence BOOLEAN DEFAULT false,
    require_photo BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Turnos de trabajo
CREATE TABLE work_shifts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    timezone TEXT DEFAULT 'Europe/Madrid',
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    break_minutes_default INTEGER DEFAULT 30,
    days_of_week INTEGER[] DEFAULT '{1,2,3,4,5}',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Eventos de fichaje (núcleo del sistema)
CREATE TABLE clock_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    type clock_event_type NOT NULL,
    timestamp_utc TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    timestamp_local TIMESTAMPTZ NOT NULL,
    source clock_event_source NOT NULL DEFAULT 'WEB',
    lat DECIMAL(10, 8),
    lng DECIMAL(11, 8),
    location_id UUID REFERENCES locations(id),
    photo_url TEXT,
    ip_address INET,
    user_agent TEXT,
    offline_cached BOOLEAN DEFAULT false,
    notes TEXT,
    device_id TEXT,
    daily_hash TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CHECK (type IN ('IN', 'OUT', 'BREAK_START', 'BREAK_END'))
);

-- Solicitudes de ausencias
CREATE TABLE leave_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    type leave_request_type NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    start_utc TIMESTAMPTZ NOT NULL,
    end_utc TIMESTAMPTZ NOT NULL,
    status leave_request_status DEFAULT 'PENDING',
    reason TEXT,
    attachment_url TEXT,
    approved_by UUID REFERENCES users_profile(id),
    approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Incidencias detectadas automáticamente
CREATE TABLE incidents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    kind incident_kind NOT NULL,
    detected_at TIMESTAMPTZ DEFAULT NOW(),
    related_clock_event_id UUID REFERENCES clock_events(id),
    description TEXT,
    resolved BOOLEAN DEFAULT false,
    resolution_notes TEXT,
    resolved_by UUID REFERENCES users_profile(id),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Logs de auditoría (inmutabilidad y trazabilidad)
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    actor_user_id UUID REFERENCES users_profile(id),
    action TEXT NOT NULL,
    entity TEXT NOT NULL,
    entity_id UUID,
    previous JSONB,
    next JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Webhooks por organización
CREATE TABLE webhooks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    event webhook_event NOT NULL,
    url TEXT NOT NULL,
    secret TEXT NOT NULL DEFAULT encode(gen_random_bytes(32), 'hex'),
    is_active BOOLEAN DEFAULT true,
    last_triggered_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Festivos por país/región
CREATE TABLE holidays (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    country TEXT NOT NULL DEFAULT 'ES',
    region TEXT,
    date DATE NOT NULL,
    name TEXT NOT NULL,
    is_national BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(country, region, date)
);

-- Representantes legales de trabajadores
CREATE TABLE representatives (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users_profile(id) ON DELETE CASCADE,
    appointed_at DATE NOT NULL DEFAULT CURRENT_DATE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, user_id)
);

-- Tabla para cálculos de horas (materializada)
CREATE TABLE daily_hours_summary (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    work_date DATE NOT NULL,
    total_hours DECIMAL(5,2) DEFAULT 0,
    break_hours DECIMAL(5,2) DEFAULT 0,
    overtime_hours DECIMAL(5,2) DEFAULT 0,
    is_holiday BOOLEAN DEFAULT false,
    is_weekend BOOLEAN DEFAULT false,
    daily_hash TEXT NOT NULL,
    calculated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(employee_id, work_date)
);

-- ============================================
-- ÍNDICES para optimización
-- ============================================

CREATE INDEX idx_memberships_user_id ON memberships(user_id);
CREATE INDEX idx_memberships_organization_id ON memberships(organization_id);
CREATE INDEX idx_employees_organization_id ON employees(organization_id);
CREATE INDEX idx_employees_user_id ON employees(user_id) WHERE user_id IS NOT NULL;
CREATE INDEX idx_clock_events_employee_id ON clock_events(employee_id);
CREATE INDEX idx_clock_events_organization_id ON clock_events(organization_id);
CREATE INDEX idx_clock_events_timestamp ON clock_events(timestamp_utc DESC);
CREATE INDEX idx_clock_events_date ON clock_events(DATE(timestamp_local));
CREATE INDEX idx_leave_requests_employee_id ON leave_requests(employee_id);
CREATE INDEX idx_leave_requests_status ON leave_requests(status);
CREATE INDEX idx_incidents_employee_id ON incidents(employee_id);
CREATE INDEX idx_incidents_resolved ON incidents(resolved);
CREATE INDEX idx_audit_logs_organization_id ON audit_logs(organization_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at DESC);
CREATE INDEX idx_daily_hours_employee_date ON daily_hours_summary(employee_id, work_date);

-- Índice para búsqueda rápida por external_code (kiosko PIN)
CREATE INDEX idx_employees_external_code ON employees(organization_id, external_code);

-- ============================================
-- FOREIGN KEYS diferidas (sin constraints)
-- ============================================

ALTER TABLE employees ADD CONSTRAINT fk_employees_location 
    FOREIGN KEY (default_location_id) REFERENCES locations(id) ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED;

ALTER TABLE employees ADD CONSTRAINT fk_employees_shift 
    FOREIGN KEY (default_shift_id) REFERENCES work_shifts(id) ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED;

-- ============================================
-- FUNCIONES Y TRIGGERS
-- ============================================

-- Función para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger a tablas relevantes
CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_profile_updated_at BEFORE UPDATE ON users_profile
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_memberships_updated_at BEFORE UPDATE ON memberships
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON employees
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_locations_updated_at BEFORE UPDATE ON locations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_work_shifts_updated_at BEFORE UPDATE ON work_shifts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_leave_requests_updated_at BEFORE UPDATE ON leave_requests
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_webhooks_updated_at BEFORE UPDATE ON webhooks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Función para calcular hash diario del parte de trabajo
CREATE OR REPLACE FUNCTION calculate_daily_hash(
    p_employee_id UUID,
    p_work_date DATE
) RETURNS TEXT AS $$
DECLARE
    v_hash TEXT;
BEGIN
    SELECT encode(
        digest(
            string_agg(
                id::text || type::text || timestamp_utc::text,
                '|'
                ORDER BY timestamp_utc
            ),
            'sha256'
        ),
        'hex'
    ) INTO v_hash
    FROM clock_events
    WHERE employee_id = p_employee_id
      AND DATE(timestamp_local) = p_work_date;
    
    RETURN COALESCE(v_hash, '');
END;
$$ LANGUAGE plpgsql;

-- Función para validar secuencia de fichajes
CREATE OR REPLACE FUNCTION validate_clock_sequence(
    p_employee_id UUID,
    p_type clock_event_type,
    p_timestamp TIMESTAMPTZ
) RETURNS BOOLEAN AS $$
DECLARE
    v_last_event clock_event_type;
BEGIN
    SELECT type INTO v_last_event
    FROM clock_events
    WHERE employee_id = p_employee_id
      AND timestamp_utc < p_timestamp
    ORDER BY timestamp_utc DESC
    LIMIT 1;
    
    -- Lógica de validación de secuencia
    IF v_last_event IS NULL THEN
        RETURN p_type = 'IN';
    END IF;
    
    IF v_last_event = 'IN' THEN
        RETURN p_type IN ('OUT', 'BREAK_START');
    ELSIF v_last_event = 'OUT' THEN
        RETURN p_type = 'IN';
    ELSIF v_last_event = 'BREAK_START' THEN
        RETURN p_type = 'BREAK_END';
    ELSIF v_last_event = 'BREAK_END' THEN
        RETURN p_type IN ('OUT', 'BREAK_START');
    END IF;
    
    RETURN false;
END;
$$ LANGUAGE plpgsql;

-- Comentarios para documentación
COMMENT ON TABLE organizations IS 'Organizaciones multi-tenant con configuración específica';
COMMENT ON TABLE clock_events IS 'Eventos de fichaje - núcleo del sistema. Retención mínima 4 años (normativa española)';
COMMENT ON TABLE incidents IS 'Incidencias detectadas automáticamente según políticas';
COMMENT ON TABLE audit_logs IS 'Trazabilidad completa de cambios para cumplimiento legal';
COMMENT ON TABLE daily_hours_summary IS 'Resumen diario materializado con hash para inmutabilidad';

-- Habilitar RLS en todas las tablas
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE users_profile ENABLE ROW LEVEL SECURITY;
ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE work_shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE clock_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE incidents ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhooks ENABLE ROW LEVEL SECURITY;
ALTER TABLE holidays ENABLE ROW LEVEL SECURITY;
ALTER TABLE representatives ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_hours_summary ENABLE ROW LEVEL SECURITY;
-- ============================================
-- POLÍTICAS RLS MULTI-TENANT ESTRICTAS
-- Cumplimiento: Solo acceso a datos de la propia organización
-- ============================================

-- Helper function: obtener organization_id del usuario actual
CREATE OR REPLACE FUNCTION get_user_organization_id()
RETURNS UUID AS $$
DECLARE
    v_org_id UUID;
BEGIN
    SELECT organization_id INTO v_org_id
    FROM memberships
    WHERE user_id = auth.uid()
      AND is_active = true
    LIMIT 1;
    
    RETURN v_org_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper function: verificar si usuario es admin/manager de una organización
CREATE OR REPLACE FUNCTION is_org_admin_or_manager(p_org_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM memberships
        WHERE user_id = auth.uid()
          AND organization_id = p_org_id
          AND role IN ('ORG_ADMIN', 'MANAGER')
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper function: verificar si usuario es empleado específico
CREATE OR REPLACE FUNCTION is_employee(p_employee_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM employees
        WHERE id = p_employee_id
          AND user_id = auth.uid()
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper function: verificar si usuario es representante legal
CREATE OR REPLACE FUNCTION is_representative(p_org_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM representatives
        WHERE user_id = auth.uid()
          AND organization_id = p_org_id
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- POLÍTICAS: organizations
-- ============================================

-- Admin/Manager pueden ver su organización
CREATE POLICY "Users can view their organization"
ON organizations FOR SELECT
TO authenticated
USING (id = get_user_organization_id());

-- Solo ORG_ADMIN puede actualizar
CREATE POLICY "Org admins can update their organization"
ON organizations FOR UPDATE
TO authenticated
USING (is_org_admin_or_manager(id))
WITH CHECK (is_org_admin_or_manager(id));

-- ============================================
-- POLÍTICAS: users_profile
-- ============================================

-- Usuarios pueden ver su propio perfil
CREATE POLICY "Users can view own profile"
ON users_profile FOR SELECT
TO authenticated
USING (id = auth.uid());

-- Usuarios pueden actualizar su propio perfil
CREATE POLICY "Users can update own profile"
ON users_profile FOR UPDATE
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Permitir INSERT para nuevos usuarios (signup)
CREATE POLICY "Users can insert own profile"
ON users_profile FOR INSERT
TO authenticated, anon
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- ============================================
-- POLÍTICAS: memberships
-- ============================================

-- Usuarios pueden ver sus membresías
CREATE POLICY "Users can view own memberships"
ON memberships FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Admin puede ver todas las membresías de su organización
CREATE POLICY "Admins can view org memberships"
ON memberships FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Admin puede crear/actualizar membresías
CREATE POLICY "Admins can manage memberships"
ON memberships FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: employees
-- ============================================

-- Empleados pueden ver su propio perfil
CREATE POLICY "Employees can view own profile"
ON employees FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Admin/Manager pueden ver todos los empleados de su org
CREATE POLICY "Admins can view org employees"
ON employees FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Representantes pueden ver empleados
CREATE POLICY "Representatives can view employees"
ON employees FOR SELECT
TO authenticated
USING (is_representative(organization_id));

-- Admin/Manager pueden gestionar empleados
CREATE POLICY "Admins can manage employees"
ON employees FOR ALL
TO authenticated, anon
USING (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
)
WITH CHECK (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
);

-- ============================================
-- POLÍTICAS: locations
-- ============================================

-- Usuarios pueden ver ubicaciones de su organización
CREATE POLICY "Users can view org locations"
ON locations FOR SELECT
TO authenticated
USING (organization_id = get_user_organization_id());

-- Admin puede gestionar ubicaciones
CREATE POLICY "Admins can manage locations"
ON locations FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: work_shifts
-- ============================================

-- Usuarios pueden ver turnos de su organización
CREATE POLICY "Users can view org shifts"
ON work_shifts FOR SELECT
TO authenticated
USING (organization_id = get_user_organization_id());

-- Admin puede gestionar turnos
CREATE POLICY "Admins can manage shifts"
ON work_shifts FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: clock_events (CRÍTICO)
-- ============================================

-- Empleados solo ven sus propios fichajes
CREATE POLICY "Employees can view own clock events"
ON clock_events FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = clock_events.employee_id
          AND employees.user_id = auth.uid()
    )
);

-- Admin/Manager ven todos los fichajes de su org
CREATE POLICY "Admins can view org clock events"
ON clock_events FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Representantes pueden ver fichajes
CREATE POLICY "Representatives can view clock events"
ON clock_events FOR SELECT
TO authenticated
USING (is_representative(organization_id));

-- Empleados pueden crear sus propios fichajes
CREATE POLICY "Employees can create own clock events"
ON clock_events FOR INSERT
TO authenticated, anon
WITH CHECK (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = clock_events.employee_id
          AND (employees.user_id = auth.uid() OR auth.role() IN ('anon', 'service_role'))
    ) OR
    auth.role() IN ('anon', 'service_role')
);

-- Admin puede crear/actualizar fichajes (correcciones)
CREATE POLICY "Admins can manage clock events"
ON clock_events FOR ALL
TO authenticated, anon
USING (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
)
WITH CHECK (
    is_org_admin_or_manager(organization_id) OR
    auth.role() IN ('anon', 'service_role')
);

-- ============================================
-- POLÍTICAS: leave_requests
-- ============================================

-- Empleados ven sus propias solicitudes
CREATE POLICY "Employees can view own leave requests"
ON leave_requests FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = leave_requests.employee_id
          AND employees.user_id = auth.uid()
    )
);

-- Admin ve todas las solicitudes de su org
CREATE POLICY "Admins can view org leave requests"
ON leave_requests FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Empleados pueden crear sus solicitudes
CREATE POLICY "Employees can create leave requests"
ON leave_requests FOR INSERT
TO authenticated
WITH CHECK (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = leave_requests.employee_id
          AND employees.user_id = auth.uid()
    )
);

-- Admin puede gestionar solicitudes
CREATE POLICY "Admins can manage leave requests"
ON leave_requests FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: incidents
-- ============================================

-- Admin/Manager ven incidencias de su org
CREATE POLICY "Admins can view org incidents"
ON incidents FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Empleados ven sus propias incidencias
CREATE POLICY "Employees can view own incidents"
ON incidents FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = incidents.employee_id
          AND employees.user_id = auth.uid()
    )
);

-- Sistema puede crear incidencias (via edge functions)
CREATE POLICY "System can create incidents"
ON incidents FOR INSERT
TO authenticated, anon
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- Admin puede resolver incidencias
CREATE POLICY "Admins can manage incidents"
ON incidents FOR UPDATE
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: audit_logs
-- ============================================

-- Solo lectura para admin
CREATE POLICY "Admins can view org audit logs"
ON audit_logs FOR SELECT
TO authenticated
USING (
    organization_id IS NULL OR
    is_org_admin_or_manager(organization_id)
);

-- Sistema puede crear logs
CREATE POLICY "System can create audit logs"
ON audit_logs FOR INSERT
TO authenticated, anon
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- ============================================
-- POLÍTICAS: webhooks
-- ============================================

-- Admin puede gestionar webhooks
CREATE POLICY "Admins can manage webhooks"
ON webhooks FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- ============================================
-- POLÍTICAS: holidays
-- ============================================

-- Todos pueden leer festivos
CREATE POLICY "Everyone can view holidays"
ON holidays FOR SELECT
TO authenticated, anon
USING (true);

-- Solo admin de sistema puede gestionar (via migration)
CREATE POLICY "Service role can manage holidays"
ON holidays FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- ============================================
-- POLÍTICAS: representatives
-- ============================================

-- Admin puede gestionar representantes
CREATE POLICY "Admins can manage representatives"
ON representatives FOR ALL
TO authenticated
USING (is_org_admin_or_manager(organization_id))
WITH CHECK (is_org_admin_or_manager(organization_id));

-- Usuarios pueden ver si son representantes
CREATE POLICY "Users can view own representative status"
ON representatives FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- ============================================
-- POLÍTICAS: daily_hours_summary
-- ============================================

-- Empleados ven su propio resumen
CREATE POLICY "Employees can view own hours summary"
ON daily_hours_summary FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM employees
        WHERE employees.id = daily_hours_summary.employee_id
          AND employees.user_id = auth.uid()
    )
);

-- Admin ve todos los resúmenes de su org
CREATE POLICY "Admins can view org hours summary"
ON daily_hours_summary FOR SELECT
TO authenticated
USING (is_org_admin_or_manager(organization_id));

-- Sistema puede crear/actualizar resúmenes
CREATE POLICY "System can manage hours summary"
ON daily_hours_summary FOR ALL
TO authenticated, anon
USING (auth.role() IN ('authenticated', 'anon', 'service_role'))
WITH CHECK (auth.role() IN ('authenticated', 'anon', 'service_role'));

-- ============================================
-- GRANTS
-- ============================================

-- Permitir acceso a funciones helper
GRANT EXECUTE ON FUNCTION get_user_organization_id() TO authenticated;
GRANT EXECUTE ON FUNCTION is_org_admin_or_manager(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION is_employee(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION is_representative(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION validate_clock_sequence(UUID, clock_event_type, TIMESTAMPTZ) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION calculate_daily_hash(UUID, DATE) TO authenticated, anon;
-- ============================================
-- DATOS SEED para DEMO
-- 1 organización, 1 admin, 1 representante, 5 empleados, 2 ubicaciones, 2 turnos
-- Semana de eventos de ejemplo
-- ============================================

-- Insertar festivos España 2025
INSERT INTO holidays (country, region, date, name, is_national) VALUES
('ES', NULL, '2025-01-01', 'Año Nuevo', true),
('ES', NULL, '2025-01-06', 'Reyes Magos', true),
('ES', NULL, '2025-04-18', 'Viernes Santo', true),
('ES', NULL, '2025-05-01', 'Día del Trabajo', true),
('ES', NULL, '2025-08-15', 'Asunción de la Virgen', true),
('ES', NULL, '2025-10-12', 'Fiesta Nacional de España', true),
('ES', NULL, '2025-11-01', 'Todos los Santos', true),
('ES', NULL, '2025-12-06', 'Día de la Constitución', true),
('ES', NULL, '2025-12-08', 'Inmaculada Concepción', true),
('ES', NULL, '2025-12-25', 'Navidad', true),
('ES', 'Madrid', '2025-05-02', 'Fiesta de la Comunidad de Madrid', false),
('ES', 'Catalunya', '2025-09-11', 'Diada Nacional de Catalunya', false),
('ES', 'Andalucía', '2025-02-28', 'Día de Andalucía', false);

-- Organización demo
INSERT INTO organizations (id, name, vat_id, settings, biometric_enabled) VALUES
(
    'a0000000-0000-0000-0000-000000000001',
    'TechCorp España S.L.',
    'B12345678',
    jsonb_build_object(
        'timezone', 'Europe/Madrid',
        'work_hours_per_day', 8,
        'overtime_threshold_hours', 40,
        'late_tolerance_minutes', 15,
        'require_geofence', true,
        'require_photo', false,
        'require_ip_whitelist', false,
        'retention_years', 4
    ),
    false
);

-- NOTA: Los usuarios se crean automáticamente al hacer signup
-- Estos IDs son ejemplos - en producción se crearían vía auth.users

-- Perfil admin (se debe crear vía signup primero, luego insertar membership)
-- Email: admin@techcorp.es / Password: Admin123!

-- Perfil representante
-- Email: representante@techcorp.es / Password: Rep123!

-- Empleados (5 empleados con PIN)
INSERT INTO employees (id, organization_id, external_code, pin_hash, full_name, email, phone, hire_date, is_active) VALUES
(
    'e0000000-0000-0000-0000-000000000001',
    'a0000000-0000-0000-0000-000000000001',
    'EMP001',
    crypt('1234', gen_salt('bf')),
    'Juan García López',
    'juan.garcia@techcorp.es',
    '+34600111222',
    '2024-01-15',
    true
),
(
    'e0000000-0000-0000-0000-000000000002',
    'a0000000-0000-0000-0000-000000000001',
    'EMP002',
    crypt('2345', gen_salt('bf')),
    'María Rodríguez Sánchez',
    'maria.rodriguez@techcorp.es',
    '+34600222333',
    '2024-02-01',
    true
),
(
    'e0000000-0000-0000-0000-000000000003',
    'a0000000-0000-0000-0000-000000000001',
    'EMP003',
    crypt('3456', gen_salt('bf')),
    'Carlos Martínez Pérez',
    'carlos.martinez@techcorp.es',
    '+34600333444',
    '2024-03-10',
    true
),
(
    'e0000000-0000-0000-0000-000000000004',
    'a0000000-0000-0000-0000-000000000001',
    'EMP004',
    crypt('4567', gen_salt('bf')),
    'Ana Fernández Gómez',
    'ana.fernandez@techcorp.es',
    '+34600444555',
    '2024-04-05',
    true
),
(
    'e0000000-0000-0000-0000-000000000005',
    'a0000000-0000-0000-0000-000000000001',
    'EMP005',
    crypt('5678', gen_salt('bf')),
    'Pedro López Martín',
    'pedro.lopez@techcorp.es',
    '+34600555666',
    '2024-05-20',
    true
);

-- Ubicaciones (2 centros de trabajo)
INSERT INTO locations (id, organization_id, name, address, lat, lng, geofence_radius_m, require_geofence, require_photo) VALUES
(
    'l0000000-0000-0000-0000-000000000001',
    'a0000000-0000-0000-0000-000000000001',
    'Oficina Central Madrid',
    'Calle Gran Vía 28, 28013 Madrid',
    40.4200,
    -3.7038,
    150,
    true,
    false
),
(
    'l0000000-0000-0000-0000-000000000002',
    'a0000000-0000-0000-0000-000000000001',
    'Centro Logístico Getafe',
    'Polígono Industrial Los Olivos, 28904 Getafe',
    40.3055,
    -3.7321,
    200,
    true,
    true
);

-- Turnos de trabajo (2 turnos)
INSERT INTO work_shifts (id, organization_id, name, timezone, start_time, end_time, break_minutes_default, days_of_week) VALUES
(
    's0000000-0000-0000-0000-000000000001',
    'a0000000-0000-0000-0000-000000000001',
    'Turno Mañana',
    'Europe/Madrid',
    '09:00:00',
    '17:00:00',
    30,
    ARRAY[1,2,3,4,5]
),
(
    's0000000-0000-0000-0000-000000000002',
    'a0000000-0000-0000-0000-000000000001',
    'Turno Tarde',
    'Europe/Madrid',
    '14:00:00',
    '22:00:00',
    30,
    ARRAY[1,2,3,4,5]
);

-- Asignar ubicación y turno por defecto a empleados
UPDATE employees SET 
    default_location_id = 'l0000000-0000-0000-0000-000000000001',
    default_shift_id = 's0000000-0000-0000-0000-000000000001'
WHERE id IN ('e0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002', 'e0000000-0000-0000-0000-000000000003');

UPDATE employees SET 
    default_location_id = 'l0000000-0000-0000-0000-000000000002',
    default_shift_id = 's0000000-0000-0000-0000-000000000002'
WHERE id IN ('e0000000-0000-0000-0000-000000000004', 'e0000000-0000-0000-0000-000000000005');

-- Eventos de fichaje de ejemplo (semana del 21-25 octubre 2025)
-- Empleado 1 - Semana completa normal
INSERT INTO clock_events (organization_id, employee_id, type, timestamp_utc, timestamp_local, source, lat, lng, location_id) VALUES
-- Lunes
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'IN', '2025-10-21 07:55:00+00', '2025-10-21 09:55:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_START', '2025-10-21 12:00:00+00', '2025-10-21 14:00:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_END', '2025-10-21 12:30:00+00', '2025-10-21 14:30:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'OUT', '2025-10-21 15:00:00+00', '2025-10-21 17:00:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
-- Martes
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'IN', '2025-10-22 07:58:00+00', '2025-10-22 09:58:00+02', 'MOBILE', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_START', '2025-10-22 12:00:00+00', '2025-10-22 14:00:00+02', 'MOBILE', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_END', '2025-10-22 12:30:00+00', '2025-10-22 14:30:00+02', 'MOBILE', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'OUT', '2025-10-22 15:05:00+00', '2025-10-22 17:05:00+02', 'MOBILE', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
-- Miércoles
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'IN', '2025-10-23 08:00:00+00', '2025-10-23 10:00:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_START', '2025-10-23 12:00:00+00', '2025-10-23 14:00:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_END', '2025-10-23 12:30:00+00', '2025-10-23 14:30:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'OUT', '2025-10-23 15:02:00+00', '2025-10-23 17:02:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
-- Jueves
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'IN', '2025-10-24 07:54:00+00', '2025-10-24 09:54:00+02', 'KIOSK', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_START', '2025-10-24 12:00:00+00', '2025-10-24 14:00:00+02', 'KIOSK', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_END', '2025-10-24 12:30:00+00', '2025-10-24 14:30:00+02', 'KIOSK', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'OUT', '2025-10-24 15:10:00+00', '2025-10-24 17:10:00+02', 'KIOSK', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
-- Viernes
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'IN', '2025-10-25 08:02:00+00', '2025-10-25 10:02:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_START', '2025-10-25 12:00:00+00', '2025-10-25 14:00:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_END', '2025-10-25 12:30:00+00', '2025-10-25 14:30:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'OUT', '2025-10-25 14:58:00+00', '2025-10-25 16:58:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001');

-- Empleado 2 - Con una llegada tarde (incidencia)
INSERT INTO clock_events (organization_id, employee_id, type, timestamp_utc, timestamp_local, source, lat, lng, location_id) VALUES
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002', 'IN', '2025-10-21 08:20:00+00', '2025-10-21 10:20:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002', 'OUT', '2025-10-21 15:10:00+00', '2025-10-21 17:10:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001');

-- Incidencia de llegada tarde
INSERT INTO incidents (organization_id, employee_id, kind, detected_at, description) VALUES
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002', 'LATE', '2025-10-21 08:20:00+00', 'Llegada 20 minutos tarde (tolerancia: 15 min)');

-- Solicitud de ausencia de ejemplo
INSERT INTO leave_requests (organization_id, employee_id, type, start_date, end_date, start_utc, end_utc, status, reason) VALUES
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000003', 'VACATION', '2025-11-10', '2025-11-15', '2025-11-10 00:00:00+00', '2025-11-15 23:59:59+00', 'APPROVED', 'Vacaciones programadas');

-- Comentario sobre usuarios
COMMENT ON TABLE employees IS 'USUARIOS DEMO:
Admin: admin@techcorp.es / Admin123!
Representante: representante@techcorp.es / Rep123!
Empleados con PIN:
- EMP001: Juan García (PIN: 1234)
- EMP002: María Rodríguez (PIN: 2345)
- EMP003: Carlos Martínez (PIN: 3456)
- EMP004: Ana Fernández (PIN: 4567)
- EMP005: Pedro López (PIN: 5678)

NOTA: Los usuarios admin y representante se deben crear manualmente vía signup,
luego insertar sus memberships correspondientes.';
