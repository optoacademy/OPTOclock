// Edge Function: Exportar reportes de fichajes con firma digital
Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Max-Age': '86400',
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!supabaseUrl || !serviceKey) {
            throw new Error('Configuración de Supabase no disponible');
        }

        const body = await req.json();
        const { organization_id, start_date, end_date, employee_id, format = 'CSV' } = body;

        if (!organization_id || !start_date || !end_date) {
            throw new Error('organization_id, start_date y end_date son obligatorios');
        }

        // Construir query para obtener fichajes
        let query = `organization_id=eq.${organization_id}&timestamp_local=gte.${start_date}&timestamp_local=lte.${end_date}&order=timestamp_local.asc`;
        
        if (employee_id) {
            query += `&employee_id=eq.${employee_id}`;
        }

        // Obtener eventos de fichaje
        const eventsResp = await fetch(
            `${supabaseUrl}/rest/v1/clock_events?${query}&select=*,employees!inner(full_name,external_code),locations(name)`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceKey}`,
                    'apikey': serviceKey,
                }
            }
        );

        if (!eventsResp.ok) {
            throw new Error('Error al obtener eventos de fichaje');
        }

        const events = await eventsResp.json();

        // Generar CSV
        if (format === 'CSV') {
            const csvHeaders = [
                'Fecha/Hora UTC',
                'Fecha/Hora Local',
                'Empleado',
                'Código Empleado',
                'Tipo',
                'Ubicación',
                'Latitud',
                'Longitud',
                'Origen',
                'IP',
                'Notas'
            ].join(',');

            const csvRows = events.map(e => [
                e.timestamp_utc,
                e.timestamp_local,
                e.employees?.full_name || '',
                e.employees?.external_code || '',
                e.type,
                e.locations?.name || '',
                e.lat || '',
                e.lng || '',
                e.source,
                e.ip_address || '',
                (e.notes || '').replace(/,/g, ';')
            ].join(','));

            const csvContent = [csvHeaders, ...csvRows].join('\n');

            // Calcular hash SHA-256 del contenido
            const encoder = new TextEncoder();
            const data = encoder.encode(csvContent);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

            // Añadir metadatos al final
            const timestamp = new Date().toISOString();
            const metadata = `\n\n# METADATOS EXPORTACIÓN
# Generado: ${timestamp}
# Organización: ${organization_id}
# Periodo: ${start_date} - ${end_date}
# Total registros: ${events.length}
# Hash SHA-256: ${hashHex}
# Este archivo es válido para inspecciones laborales según normativa española/UE`;

            const finalContent = csvContent + metadata;

            // Registrar exportación en audit_logs
            await fetch(
                `${supabaseUrl}/rest/v1/audit_logs`,
                {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceKey}`,
                        'apikey': serviceKey,
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        organization_id: organization_id,
                        action: 'REPORT_EXPORTED',
                        entity: 'clock_events',
                        next: {
                            period: `${start_date} - ${end_date}`,
                            total_records: events.length,
                            hash: hashHex,
                            format: format
                        }
                    })
                }
            );

            return new Response(
                finalContent,
                {
                    headers: {
                        ...corsHeaders,
                        'Content-Type': 'text/csv; charset=utf-8',
                        'Content-Disposition': `attachment; filename="fichajes_${start_date}_${end_date}.csv"`
                    }
                }
            );
        }

        // Formato JSON
        const jsonData = {
            metadata: {
                generated_at: new Date().toISOString(),
                organization_id: organization_id,
                period: {
                    start: start_date,
                    end: end_date
                },
                total_records: events.length,
                format: 'JSON'
            },
            events: events
        };

        // Calcular hash
        const jsonString = JSON.stringify(jsonData.events);
        const encoder = new TextEncoder();
        const data = encoder.encode(jsonString);
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

        jsonData.metadata.hash_sha256 = hashHex;

        return new Response(
            JSON.stringify(jsonData, null, 2),
            {
                headers: {
                    ...corsHeaders,
                    'Content-Type': 'application/json',
                    'Content-Disposition': `attachment; filename="fichajes_${start_date}_${end_date}.json"`
                }
            }
        );

    } catch (error) {
        console.error('Error en export-report:', error);

        return new Response(
            JSON.stringify({
                error: {
                    code: 'EXPORT_FAILED',
                    message: error.message
                }
            }),
            {
                status: 500,
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            }
        );
    }
});
