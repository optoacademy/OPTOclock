// Edge Function: Crear evento de fichaje con validaciones completas
Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Max-Age': '86400',
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!supabaseUrl || !serviceKey) {
            throw new Error('Configuración de Supabase no disponible');
        }

        const authHeader = req.headers.get('authorization');
        const body = await req.json();
        const { employee_id, type, lat, lng, source = 'WEB', notes, pin } = body;

        if (!employee_id || !type) {
            throw new Error('employee_id y type son obligatorios');
        }

        // Validar tipo
        if (!['IN', 'OUT', 'BREAK_START', 'BREAK_END'].includes(type)) {
            throw new Error('Tipo de evento inválido');
        }

        // Obtener datos del empleado
        const empResp = await fetch(
            `${supabaseUrl}/rest/v1/employees?id=eq.${employee_id}&select=*,default_location_id,organization_id,organizations!inner(settings)`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceKey}`,
                    'apikey': serviceKey,
                }
            }
        );

        if (!empResp.ok) {
            throw new Error('Empleado no encontrado');
        }

        const employees = await empResp.json();
        if (!employees || employees.length === 0) {
            throw new Error('Empleado no encontrado');
        }

        const employee = employees[0];
        const orgSettings = employee.organizations?.settings || {};

        // Validar PIN si se proporciona (modo kiosko)
        if (pin) {
            const pinCheck = await fetch(
                `${supabaseUrl}/rest/v1/rpc/crypt`,
                {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceKey}`,
                        'apikey': serviceKey,
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ password: pin, salt: employee.pin_hash })
                }
            );

            if (!pinCheck.ok || !(await pinCheck.json())) {
                return new Response(
                    JSON.stringify({ error: { code: 'INVALID_PIN', message: 'PIN incorrecto' } }),
                    { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
                );
            }
        }

        // Obtener la ubicación predeterminada si existe
        let location = null;
        if (employee.default_location_id) {
            const locResp = await fetch(
                `${supabaseUrl}/rest/v1/locations?id=eq.${employee.default_location_id}`,
                {
                    headers: {
                        'Authorization': `Bearer ${serviceKey}`,
                        'apikey': serviceKey,
                    }
                }
            );

            if (locResp.ok) {
                const locs = await locResp.json();
                location = locs[0] || null;
            }
        }

        // Validar geofencing si está habilitado
        if (orgSettings.require_geofence && location && location.require_geofence) {
            if (!lat || !lng) {
                return new Response(
                    JSON.stringify({ 
                        error: { 
                            code: 'GEOFENCE_REQUIRED', 
                            message: 'Se requiere geolocalización para fichar en esta ubicación' 
                        } 
                    }),
                    { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
                );
            }

            // Calcular distancia (fórmula de Haversine simplificada)
            const R = 6371000; // Radio de la Tierra en metros
            const lat1 = location.lat * Math.PI / 180;
            const lat2 = lat * Math.PI / 180;
            const deltaLat = (lat - location.lat) * Math.PI / 180;
            const deltaLng = (lng - location.lng) * Math.PI / 180;

            const a = Math.sin(deltaLat/2) * Math.sin(deltaLat/2) +
                     Math.cos(lat1) * Math.cos(lat2) *
                     Math.sin(deltaLng/2) * Math.sin(deltaLng/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            const distance = R * c;

            if (distance > location.geofence_radius_m) {
                // Crear incidencia
                await fetch(
                    `${supabaseUrl}/rest/v1/incidents`,
                    {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${serviceKey}`,
                            'apikey': serviceKey,
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            organization_id: employee.organization_id,
                            employee_id: employee_id,
                            kind: 'OUT_OF_GEOFENCE',
                            description: `Fichaje fuera de geovalla. Distancia: ${Math.round(distance)}m (máximo: ${location.geofence_radius_m}m)`
                        })
                    }
                );

                return new Response(
                    JSON.stringify({ 
                        error: { 
                            code: 'OUT_OF_GEOFENCE', 
                            message: `Estás fuera del área permitida (${Math.round(distance)}m de distancia)` 
                        } 
                    }),
                    { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
                );
            }
        }

        // Validar IP si está habilitado
        const clientIP = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip');
        if (orgSettings.require_ip_whitelist && location && location.ip_whitelist && location.ip_whitelist.length > 0) {
            if (!clientIP || !location.ip_whitelist.includes(clientIP)) {
                return new Response(
                    JSON.stringify({ 
                        error: { 
                            code: 'IP_NOT_ALLOWED', 
                            message: 'Tu IP no está autorizada para fichar' 
                        } 
                    }),
                    { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
                );
            }
        }

        // Validar secuencia de fichajes
        const now = new Date().toISOString();
        const seqCheck = await fetch(
            `${supabaseUrl}/rest/v1/rpc/validate_clock_sequence`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceKey}`,
                    'apikey': serviceKey,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    p_employee_id: employee_id,
                    p_type: type,
                    p_timestamp: now
                })
            }
        );

        const isValid = await seqCheck.json();
        if (!isValid) {
            return new Response(
                JSON.stringify({ 
                    error: { 
                        code: 'INVALID_SEQUENCE', 
                        message: 'Secuencia de fichaje inválida. Verifica tu último fichaje.' 
                    } 
                }),
                { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        // Detectar llegada tarde para fichajes IN
        if (type === 'IN' && employee.default_shift_id) {
            const shiftResp = await fetch(
                `${supabaseUrl}/rest/v1/work_shifts?id=eq.${employee.default_shift_id}`,
                {
                    headers: {
                        'Authorization': `Bearer ${serviceKey}`,
                        'apikey': serviceKey,
                    }
                }
            );

            if (shiftResp.ok) {
                const shifts = await shiftResp.json();
                const shift = shifts[0];
                
                if (shift) {
                    const nowDate = new Date();
                    const shiftStart = new Date(nowDate.toDateString() + ' ' + shift.start_time);
                    const tolerance = orgSettings.late_tolerance_minutes || 15;
                    const lateMinutes = (nowDate.getTime() - shiftStart.getTime()) / 60000;

                    if (lateMinutes > tolerance) {
                        await fetch(
                            `${supabaseUrl}/rest/v1/incidents`,
                            {
                                method: 'POST',
                                headers: {
                                    'Authorization': `Bearer ${serviceKey}`,
                                    'apikey': serviceKey,
                                    'Content-Type': 'application/json',
                                },
                                body: JSON.stringify({
                                    organization_id: employee.organization_id,
                                    employee_id: employee_id,
                                    kind: 'LATE',
                                    description: `Llegada tarde: ${Math.round(lateMinutes)} minutos (tolerancia: ${tolerance} min)`
                                })
                            }
                        );
                    }
                }
            }
        }

        // Crear el evento de fichaje
        const clockEvent = {
            organization_id: employee.organization_id,
            employee_id: employee_id,
            type: type,
            timestamp_utc: now,
            timestamp_local: now,
            source: source,
            lat: lat || null,
            lng: lng || null,
            location_id: employee.default_location_id || null,
            ip_address: clientIP || null,
            user_agent: req.headers.get('user-agent') || null,
            notes: notes || null,
            offline_cached: false
        };

        const eventResp = await fetch(
            `${supabaseUrl}/rest/v1/clock_events`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceKey}`,
                    'apikey': serviceKey,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=representation'
                },
                body: JSON.stringify(clockEvent)
            }
        );

        if (!eventResp.ok) {
            const errorText = await eventResp.text();
            throw new Error(`Error al crear evento: ${errorText}`);
        }

        const createdEvent = await eventResp.json();

        // Registrar en audit_logs
        await fetch(
            `${supabaseUrl}/rest/v1/audit_logs`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceKey}`,
                    'apikey': serviceKey,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    organization_id: employee.organization_id,
                    action: 'CLOCK_EVENT_CREATED',
                    entity: 'clock_events',
                    entity_id: createdEvent[0].id,
                    next: createdEvent[0],
                    ip_address: clientIP,
                    user_agent: req.headers.get('user-agent')
                })
            }
        );

        return new Response(
            JSON.stringify({ 
                data: createdEvent[0],
                message: `Fichaje ${type} registrado correctamente`
            }),
            {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            }
        );

    } catch (error) {
        console.error('Error en clock-event:', error);

        return new Response(
            JSON.stringify({
                error: {
                    code: 'CLOCK_EVENT_FAILED',
                    message: error.message
                }
            }),
            {
                status: 500,
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            }
        );
    }
});
