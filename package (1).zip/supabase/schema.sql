-- ============================================
-- Schema completo para SaaS Fichaje Empleados
-- Cumplimiento normativo UE/España
-- ============================================

-- Extensions necesarias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- ENUMS
-- ============================================

CREATE TYPE membership_role AS ENUM ('ORG_ADMIN', 'MANAGER', 'EMPLOYEE');
CREATE TYPE clock_event_type AS ENUM ('IN', 'OUT', 'BREAK_START', 'BREAK_END');
CREATE TYPE clock_event_source AS ENUM ('WEB', 'KIOSK', 'MOBILE', 'API');
CREATE TYPE leave_request_type AS ENUM ('VACATION', 'SICK', 'PERSONAL', 'OTHER');
CREATE TYPE leave_request_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED');
CREATE TYPE incident_kind AS ENUM ('LATE', 'MISSING_OUT', 'OUT_OF_GEOFENCE', 'OUT_OF_IP', 'OVERLAP', 'REST_VIOLATION');
CREATE TYPE webhook_event AS ENUM ('EMPLOYEE_CREATED', 'CLOCK_EVENT_CREATED', 'LEAVE_REQUEST_CREATED', 'INCIDENT_CREATED', 'REPORT_EXPORTED');

-- ============================================
-- TABLAS PRINCIPALES
-- ============================================

-- Organizaciones (multi-tenant)
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    vat_id TEXT UNIQUE NOT NULL,
    settings JSONB DEFAULT '{
        "timezone": "Europe/Madrid",
        "work_hours_per_day": 8,
        "overtime_threshold_hours": 40,
        "late_tolerance_minutes": 15,
        "require_geofence": false,
        "require_photo": false,
        "require_ip_whitelist": false,
        "retention_years": 4
    }'::jsonb,
    biometric_enabled BOOLEAN DEFAULT false,
    api_key TEXT UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex'),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Perfiles de usuario (vinculado a auth.users)
CREATE TABLE users_profile (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    avatar_url TEXT,
    locale TEXT DEFAULT 'es',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Membresías (relación usuario-organización)
CREATE TABLE memberships (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users_profile(id) ON DELETE CASCADE,
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    role membership_role NOT NULL DEFAULT 'EMPLOYEE',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, organization_id)
);

-- Empleados (pueden o no estar vinculados a un usuario)
CREATE TABLE employees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users_profile(id) ON DELETE SET NULL,
    external_code TEXT NOT NULL,
    pin_hash TEXT,
    full_name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    default_location_id UUID,
    default_shift_id UUID,
    hire_date DATE,
    termination_date DATE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, external_code)
);

-- Ubicaciones/Centros de trabajo
CREATE TABLE locations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    address TEXT,
    lat DECIMAL(10, 8),
    lng DECIMAL(11, 8),
    geofence_radius_m INTEGER DEFAULT 100,
    ip_whitelist TEXT[] DEFAULT '{}',
    require_geofence BOOLEAN DEFAULT false,
    require_photo BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Turnos de trabajo
CREATE TABLE work_shifts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    timezone TEXT DEFAULT 'Europe/Madrid',
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    break_minutes_default INTEGER DEFAULT 30,
    days_of_week INTEGER[] DEFAULT '{1,2,3,4,5}',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Eventos de fichaje (núcleo del sistema)
CREATE TABLE clock_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    type clock_event_type NOT NULL,
    timestamp_utc TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    timestamp_local TIMESTAMPTZ NOT NULL,
    source clock_event_source NOT NULL DEFAULT 'WEB',
    lat DECIMAL(10, 8),
    lng DECIMAL(11, 8),
    location_id UUID REFERENCES locations(id),
    photo_url TEXT,
    ip_address INET,
    user_agent TEXT,
    offline_cached BOOLEAN DEFAULT false,
    notes TEXT,
    device_id TEXT,
    daily_hash TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CHECK (type IN ('IN', 'OUT', 'BREAK_START', 'BREAK_END'))
);

-- Solicitudes de ausencias
CREATE TABLE leave_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    type leave_request_type NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    start_utc TIMESTAMPTZ NOT NULL,
    end_utc TIMESTAMPTZ NOT NULL,
    status leave_request_status DEFAULT 'PENDING',
    reason TEXT,
    attachment_url TEXT,
    approved_by UUID REFERENCES users_profile(id),
    approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Incidencias detectadas automáticamente
CREATE TABLE incidents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    kind incident_kind NOT NULL,
    detected_at TIMESTAMPTZ DEFAULT NOW(),
    related_clock_event_id UUID REFERENCES clock_events(id),
    description TEXT,
    resolved BOOLEAN DEFAULT false,
    resolution_notes TEXT,
    resolved_by UUID REFERENCES users_profile(id),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Logs de auditoría (inmutabilidad y trazabilidad)
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    actor_user_id UUID REFERENCES users_profile(id),
    action TEXT NOT NULL,
    entity TEXT NOT NULL,
    entity_id UUID,
    previous JSONB,
    next JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Webhooks por organización
CREATE TABLE webhooks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    event webhook_event NOT NULL,
    url TEXT NOT NULL,
    secret TEXT NOT NULL DEFAULT encode(gen_random_bytes(32), 'hex'),
    is_active BOOLEAN DEFAULT true,
    last_triggered_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Festivos por país/región
CREATE TABLE holidays (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    country TEXT NOT NULL DEFAULT 'ES',
    region TEXT,
    date DATE NOT NULL,
    name TEXT NOT NULL,
    is_national BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(country, region, date)
);

-- Representantes legales de trabajadores
CREATE TABLE representatives (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users_profile(id) ON DELETE CASCADE,
    appointed_at DATE NOT NULL DEFAULT CURRENT_DATE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(organization_id, user_id)
);

-- Tabla para cálculos de horas (materializada)
CREATE TABLE daily_hours_summary (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    work_date DATE NOT NULL,
    total_hours DECIMAL(5,2) DEFAULT 0,
    break_hours DECIMAL(5,2) DEFAULT 0,
    overtime_hours DECIMAL(5,2) DEFAULT 0,
    is_holiday BOOLEAN DEFAULT false,
    is_weekend BOOLEAN DEFAULT false,
    daily_hash TEXT NOT NULL,
    calculated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(employee_id, work_date)
);

-- ============================================
-- ÍNDICES para optimización
-- ============================================

CREATE INDEX idx_memberships_user_id ON memberships(user_id);
CREATE INDEX idx_memberships_organization_id ON memberships(organization_id);
CREATE INDEX idx_employees_organization_id ON employees(organization_id);
CREATE INDEX idx_employees_user_id ON employees(user_id) WHERE user_id IS NOT NULL;
CREATE INDEX idx_clock_events_employee_id ON clock_events(employee_id);
CREATE INDEX idx_clock_events_organization_id ON clock_events(organization_id);
CREATE INDEX idx_clock_events_timestamp ON clock_events(timestamp_utc DESC);
CREATE INDEX idx_clock_events_date ON clock_events(DATE(timestamp_local));
CREATE INDEX idx_leave_requests_employee_id ON leave_requests(employee_id);
CREATE INDEX idx_leave_requests_status ON leave_requests(status);
CREATE INDEX idx_incidents_employee_id ON incidents(employee_id);
CREATE INDEX idx_incidents_resolved ON incidents(resolved);
CREATE INDEX idx_audit_logs_organization_id ON audit_logs(organization_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at DESC);
CREATE INDEX idx_daily_hours_employee_date ON daily_hours_summary(employee_id, work_date);

-- Índice para búsqueda rápida por external_code (kiosko PIN)
CREATE INDEX idx_employees_external_code ON employees(organization_id, external_code);

-- ============================================
-- FOREIGN KEYS diferidas (sin constraints)
-- ============================================

ALTER TABLE employees ADD CONSTRAINT fk_employees_location 
    FOREIGN KEY (default_location_id) REFERENCES locations(id) ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED;

ALTER TABLE employees ADD CONSTRAINT fk_employees_shift 
    FOREIGN KEY (default_shift_id) REFERENCES work_shifts(id) ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED;

-- ============================================
-- FUNCIONES Y TRIGGERS
-- ============================================

-- Función para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger a tablas relevantes
CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_profile_updated_at BEFORE UPDATE ON users_profile
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_memberships_updated_at BEFORE UPDATE ON memberships
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON employees
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_locations_updated_at BEFORE UPDATE ON locations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_work_shifts_updated_at BEFORE UPDATE ON work_shifts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_leave_requests_updated_at BEFORE UPDATE ON leave_requests
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_webhooks_updated_at BEFORE UPDATE ON webhooks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Función para calcular hash diario del parte de trabajo
CREATE OR REPLACE FUNCTION calculate_daily_hash(
    p_employee_id UUID,
    p_work_date DATE
) RETURNS TEXT AS $$
DECLARE
    v_hash TEXT;
BEGIN
    SELECT encode(
        digest(
            string_agg(
                id::text || type::text || timestamp_utc::text,
                '|'
                ORDER BY timestamp_utc
            ),
            'sha256'
        ),
        'hex'
    ) INTO v_hash
    FROM clock_events
    WHERE employee_id = p_employee_id
      AND DATE(timestamp_local) = p_work_date;
    
    RETURN COALESCE(v_hash, '');
END;
$$ LANGUAGE plpgsql;

-- Función para validar secuencia de fichajes
CREATE OR REPLACE FUNCTION validate_clock_sequence(
    p_employee_id UUID,
    p_type clock_event_type,
    p_timestamp TIMESTAMPTZ
) RETURNS BOOLEAN AS $$
DECLARE
    v_last_event clock_event_type;
BEGIN
    SELECT type INTO v_last_event
    FROM clock_events
    WHERE employee_id = p_employee_id
      AND timestamp_utc < p_timestamp
    ORDER BY timestamp_utc DESC
    LIMIT 1;
    
    -- Lógica de validación de secuencia
    IF v_last_event IS NULL THEN
        RETURN p_type = 'IN';
    END IF;
    
    IF v_last_event = 'IN' THEN
        RETURN p_type IN ('OUT', 'BREAK_START');
    ELSIF v_last_event = 'OUT' THEN
        RETURN p_type = 'IN';
    ELSIF v_last_event = 'BREAK_START' THEN
        RETURN p_type = 'BREAK_END';
    ELSIF v_last_event = 'BREAK_END' THEN
        RETURN p_type IN ('OUT', 'BREAK_START');
    END IF;
    
    RETURN false;
END;
$$ LANGUAGE plpgsql;

-- Comentarios para documentación
COMMENT ON TABLE organizations IS 'Organizaciones multi-tenant con configuración específica';
COMMENT ON TABLE clock_events IS 'Eventos de fichaje - núcleo del sistema. Retención mínima 4 años (normativa española)';
COMMENT ON TABLE incidents IS 'Incidencias detectadas automáticamente según políticas';
COMMENT ON TABLE audit_logs IS 'Trazabilidad completa de cambios para cumplimiento legal';
COMMENT ON TABLE daily_hours_summary IS 'Resumen diario materializado con hash para inmutabilidad';

-- Habilitar RLS en todas las tablas
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE users_profile ENABLE ROW LEVEL SECURITY;
ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE work_shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE clock_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE incidents ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhooks ENABLE ROW LEVEL SECURITY;
ALTER TABLE holidays ENABLE ROW LEVEL SECURITY;
ALTER TABLE representatives ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_hours_summary ENABLE ROW LEVEL SECURITY;
