-- ============================================
-- DATOS SEED para DEMO
-- 1 organización, 1 admin, 1 representante, 5 empleados, 2 ubicaciones, 2 turnos
-- Semana de eventos de ejemplo
-- ============================================

-- Insertar festivos España 2025
INSERT INTO holidays (country, region, date, name, is_national) VALUES
('ES', NULL, '2025-01-01', 'Año Nuevo', true),
('ES', NULL, '2025-01-06', 'Reyes Magos', true),
('ES', NULL, '2025-04-18', 'Viernes Santo', true),
('ES', NULL, '2025-05-01', 'Día del Trabajo', true),
('ES', NULL, '2025-08-15', 'Asunción de la Virgen', true),
('ES', NULL, '2025-10-12', 'Fiesta Nacional de España', true),
('ES', NULL, '2025-11-01', 'Todos los Santos', true),
('ES', NULL, '2025-12-06', 'Día de la Constitución', true),
('ES', NULL, '2025-12-08', 'Inmaculada Concepción', true),
('ES', NULL, '2025-12-25', 'Navidad', true),
('ES', 'Madrid', '2025-05-02', 'Fiesta de la Comunidad de Madrid', false),
('ES', 'Catalunya', '2025-09-11', 'Diada Nacional de Catalunya', false),
('ES', 'Andalucía', '2025-02-28', 'Día de Andalucía', false);

-- Organización demo
INSERT INTO organizations (id, name, vat_id, settings, biometric_enabled) VALUES
(
    'a0000000-0000-0000-0000-000000000001',
    'TechCorp España S.L.',
    'B12345678',
    jsonb_build_object(
        'timezone', 'Europe/Madrid',
        'work_hours_per_day', 8,
        'overtime_threshold_hours', 40,
        'late_tolerance_minutes', 15,
        'require_geofence', true,
        'require_photo', false,
        'require_ip_whitelist', false,
        'retention_years', 4
    ),
    false
);

-- NOTA: Los usuarios se crean automáticamente al hacer signup
-- Estos IDs son ejemplos - en producción se crearían vía auth.users

-- Perfil admin (se debe crear vía signup primero, luego insertar membership)
-- Email: admin@techcorp.es / Password: Admin123!

-- Perfil representante
-- Email: representante@techcorp.es / Password: Rep123!

-- Empleados (5 empleados con PIN)
INSERT INTO employees (id, organization_id, external_code, pin_hash, full_name, email, phone, hire_date, is_active) VALUES
(
    'e0000000-0000-0000-0000-000000000001',
    'a0000000-0000-0000-0000-000000000001',
    'EMP001',
    crypt('1234', gen_salt('bf')),
    'Juan García López',
    'juan.garcia@techcorp.es',
    '+34600111222',
    '2024-01-15',
    true
),
(
    'e0000000-0000-0000-0000-000000000002',
    'a0000000-0000-0000-0000-000000000001',
    'EMP002',
    crypt('2345', gen_salt('bf')),
    'María Rodríguez Sánchez',
    'maria.rodriguez@techcorp.es',
    '+34600222333',
    '2024-02-01',
    true
),
(
    'e0000000-0000-0000-0000-000000000003',
    'a0000000-0000-0000-0000-000000000001',
    'EMP003',
    crypt('3456', gen_salt('bf')),
    'Carlos Martínez Pérez',
    'carlos.martinez@techcorp.es',
    '+34600333444',
    '2024-03-10',
    true
),
(
    'e0000000-0000-0000-0000-000000000004',
    'a0000000-0000-0000-0000-000000000001',
    'EMP004',
    crypt('4567', gen_salt('bf')),
    'Ana Fernández Gómez',
    'ana.fernandez@techcorp.es',
    '+34600444555',
    '2024-04-05',
    true
),
(
    'e0000000-0000-0000-0000-000000000005',
    'a0000000-0000-0000-0000-000000000001',
    'EMP005',
    crypt('5678', gen_salt('bf')),
    'Pedro López Martín',
    'pedro.lopez@techcorp.es',
    '+34600555666',
    '2024-05-20',
    true
);

-- Ubicaciones (2 centros de trabajo)
INSERT INTO locations (id, organization_id, name, address, lat, lng, geofence_radius_m, require_geofence, require_photo) VALUES
(
    'l0000000-0000-0000-0000-000000000001',
    'a0000000-0000-0000-0000-000000000001',
    'Oficina Central Madrid',
    'Calle Gran Vía 28, 28013 Madrid',
    40.4200,
    -3.7038,
    150,
    true,
    false
),
(
    'l0000000-0000-0000-0000-000000000002',
    'a0000000-0000-0000-0000-000000000001',
    'Centro Logístico Getafe',
    'Polígono Industrial Los Olivos, 28904 Getafe',
    40.3055,
    -3.7321,
    200,
    true,
    true
);

-- Turnos de trabajo (2 turnos)
INSERT INTO work_shifts (id, organization_id, name, timezone, start_time, end_time, break_minutes_default, days_of_week) VALUES
(
    's0000000-0000-0000-0000-000000000001',
    'a0000000-0000-0000-0000-000000000001',
    'Turno Mañana',
    'Europe/Madrid',
    '09:00:00',
    '17:00:00',
    30,
    ARRAY[1,2,3,4,5]
),
(
    's0000000-0000-0000-0000-000000000002',
    'a0000000-0000-0000-0000-000000000001',
    'Turno Tarde',
    'Europe/Madrid',
    '14:00:00',
    '22:00:00',
    30,
    ARRAY[1,2,3,4,5]
);

-- Asignar ubicación y turno por defecto a empleados
UPDATE employees SET 
    default_location_id = 'l0000000-0000-0000-0000-000000000001',
    default_shift_id = 's0000000-0000-0000-0000-000000000001'
WHERE id IN ('e0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002', 'e0000000-0000-0000-0000-000000000003');

UPDATE employees SET 
    default_location_id = 'l0000000-0000-0000-0000-000000000002',
    default_shift_id = 's0000000-0000-0000-0000-000000000002'
WHERE id IN ('e0000000-0000-0000-0000-000000000004', 'e0000000-0000-0000-0000-000000000005');

-- Eventos de fichaje de ejemplo (semana del 21-25 octubre 2025)
-- Empleado 1 - Semana completa normal
INSERT INTO clock_events (organization_id, employee_id, type, timestamp_utc, timestamp_local, source, lat, lng, location_id) VALUES
-- Lunes
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'IN', '2025-10-21 07:55:00+00', '2025-10-21 09:55:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_START', '2025-10-21 12:00:00+00', '2025-10-21 14:00:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_END', '2025-10-21 12:30:00+00', '2025-10-21 14:30:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'OUT', '2025-10-21 15:00:00+00', '2025-10-21 17:00:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
-- Martes
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'IN', '2025-10-22 07:58:00+00', '2025-10-22 09:58:00+02', 'MOBILE', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_START', '2025-10-22 12:00:00+00', '2025-10-22 14:00:00+02', 'MOBILE', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_END', '2025-10-22 12:30:00+00', '2025-10-22 14:30:00+02', 'MOBILE', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'OUT', '2025-10-22 15:05:00+00', '2025-10-22 17:05:00+02', 'MOBILE', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
-- Miércoles
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'IN', '2025-10-23 08:00:00+00', '2025-10-23 10:00:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_START', '2025-10-23 12:00:00+00', '2025-10-23 14:00:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_END', '2025-10-23 12:30:00+00', '2025-10-23 14:30:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'OUT', '2025-10-23 15:02:00+00', '2025-10-23 17:02:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
-- Jueves
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'IN', '2025-10-24 07:54:00+00', '2025-10-24 09:54:00+02', 'KIOSK', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_START', '2025-10-24 12:00:00+00', '2025-10-24 14:00:00+02', 'KIOSK', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_END', '2025-10-24 12:30:00+00', '2025-10-24 14:30:00+02', 'KIOSK', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'OUT', '2025-10-24 15:10:00+00', '2025-10-24 17:10:00+02', 'KIOSK', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
-- Viernes
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'IN', '2025-10-25 08:02:00+00', '2025-10-25 10:02:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_START', '2025-10-25 12:00:00+00', '2025-10-25 14:00:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'BREAK_END', '2025-10-25 12:30:00+00', '2025-10-25 14:30:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'OUT', '2025-10-25 14:58:00+00', '2025-10-25 16:58:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001');

-- Empleado 2 - Con una llegada tarde (incidencia)
INSERT INTO clock_events (organization_id, employee_id, type, timestamp_utc, timestamp_local, source, lat, lng, location_id) VALUES
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002', 'IN', '2025-10-21 08:20:00+00', '2025-10-21 10:20:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001'),
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002', 'OUT', '2025-10-21 15:10:00+00', '2025-10-21 17:10:00+02', 'WEB', 40.4200, -3.7038, 'l0000000-0000-0000-0000-000000000001');

-- Incidencia de llegada tarde
INSERT INTO incidents (organization_id, employee_id, kind, detected_at, description) VALUES
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002', 'LATE', '2025-10-21 08:20:00+00', 'Llegada 20 minutos tarde (tolerancia: 15 min)');

-- Solicitud de ausencia de ejemplo
INSERT INTO leave_requests (organization_id, employee_id, type, start_date, end_date, start_utc, end_utc, status, reason) VALUES
('a0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000003', 'VACATION', '2025-11-10', '2025-11-15', '2025-11-10 00:00:00+00', '2025-11-15 23:59:59+00', 'APPROVED', 'Vacaciones programadas');

-- Comentario sobre usuarios
COMMENT ON TABLE employees IS 'USUARIOS DEMO:
Admin: admin@techcorp.es / Admin123!
Representante: representante@techcorp.es / Rep123!
Empleados con PIN:
- EMP001: Juan García (PIN: 1234)
- EMP002: María Rodríguez (PIN: 2345)
- EMP003: Carlos Martínez (PIN: 3456)
- EMP004: Ana Fernández (PIN: 4567)
- EMP005: Pedro López (PIN: 5678)

NOTA: Los usuarios admin y representante se deben crear manualmente vía signup,
luego insertar sus memberships correspondientes.';
